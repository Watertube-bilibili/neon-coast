import * as THREE from './vendor/three.module.js';
import {G9_DISPLAY_ART} from './assets/g9/g9-display-art.js';
// These are original decorative map/media layouts, not a navigation/media API.
// A detailed player car receives the existing per-instance live speed cluster.
export function createG9DisplayTexture(kind,lowResolution=false){
 if(typeof document==='undefined')return null;
 const scale=lowResolution?.5:1;
 let canvas,ctx;try{canvas=document.createElement('canvas');canvas.width=768*scale;canvas.height=320*scale;ctx=canvas.getContext('2d');}catch{return null;}if(!ctx)return null;
 ctx.scale(scale,scale);ctx.textBaseline='top';ctx.lineJoin='round';ctx.lineCap='round';
 for(const [op,color,...a] of G9_DISPLAY_ART[kind]){
  ctx.fillStyle=color;ctx.strokeStyle=color;
  if(op==='rect')ctx.fillRect(...a);
  else if(op==='ellipse'){ctx.beginPath();ctx.ellipse(a[0]+a[2]/2,a[1]+a[3]/2,a[2]/2,a[3]/2,0,0,Math.PI*2);ctx.fill();}
  else if(op==='line'||op==='polygon'){
   const pts=op==='line'?a[1]:a[0];ctx.beginPath();ctx.moveTo(...pts[0]);for(const p of pts.slice(1))ctx.lineTo(...p);
   if(op==='line'){ctx.lineWidth=a[0];ctx.stroke();}else{ctx.closePath();ctx.fill();}
  }else if(op==='text'){ctx.font=`${a[4]?'600':'400'} ${a[2]}px sans-serif`;ctx.fillText(a[3],a[0],a[1]);}
 }
 const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;
 texture.minFilter=THREE.LinearFilter;texture.magFilter=THREE.LinearFilter;texture.generateMipmaps=false;
 texture.name='G9 '+kind+' original display art';return texture;
}
