import {SAVE_KEY} from './storage-keys.js';
import {validateSave} from './save-validation.js';
import {BETA_VERSION,BETA_PATH,createBetaSlot,activeBetaSlot} from './beta-save-slots.js';
import {BETA_ENTRY_ENABLED} from './beta-entry-config.js';
export const BETA_ACK_KEY='neon-coast-beta-announcement-read';
export function betaEntryDismissed(storage){try{return storage.getItem(BETA_ACK_KEY)===BETA_VERSION;}catch{return false;}}
export function installBetaEntry({document,window,storage,locks=window.navigator?.locks,sourceKey=SAVE_KEY,navigate=url=>window.location.assign(url),createSlot=createBetaSlot,readActive=activeBetaSlot}={}){
 if(!BETA_ENTRY_ENABLED||document.getElementById('neon-beta-entry'))return null;
 const root=document.createElement('section');root.id='neon-beta-entry';root.setAttribute('aria-label','2.0 测试版入口');
 const toggle=document.createElement('button');toggle.className='beta-entry-toggle';toggle.textContent='2.0 BETA';toggle.type='button';
 const panel=document.createElement('div');panel.className='beta-entry-panel';panel.hidden=betaEntryDismissed(storage);
 const title=document.createElement('strong');title.textContent='2.0 开发候选版';
 const note=document.createElement('p');note.textContent='一键复制存档体验。标准版和已有测试进度都会保留。';
 const status=document.createElement('p');status.className='beta-entry-status';status.setAttribute('role','status');status.setAttribute('aria-live','polite');
 const actions=document.createElement('div');actions.className='beta-entry-actions';
 const button=(text,action)=>{const b=document.createElement('button');b.type='button';b.textContent=text;b.onclick=action;actions.append(b);return b;};
 let busy=false,generation=0,firstSnapshot;
 const acknowledge=()=>{try{storage.setItem(BETA_ACK_KEY,BETA_VERSION);return true;}catch{return false;}};
 const collapse=()=>{generation++;panel.hidden=true;toggle.setAttribute('aria-expanded','false');if(!acknowledge())status.textContent='浏览器未能记住关闭状态，下次可能再次显示。';};
 const setBusy=value=>{busy=value;copy.disabled=fresh.disabled=resume.disabled=cancel.disabled=value;};
 const enter=async mode=>{if(busy)return;setBusy(true);const token=++generation;status.textContent='正在校验并准备独立测试存档…';
  try{const entry=mode==='continue'?await readActive(storage,validateSave):await createSlot(storage,{mode,sourceKey,sourceRaw:mode==='copy'&&window.game?.snapshot?(firstSnapshot??=JSON.stringify(window.game.snapshot())):undefined,validateSave,locks});if(token!==generation)return;if(!entry)throw Error('还没有测试版进度，请选择复制或新存档。');acknowledge();navigate(entry.url);}
  catch(error){if(token===generation)status.textContent=error.message||'未能进入测试版，已有存档已保留。';}
  finally{if(token===generation)setBusy(false);}
 };
 const copy=button('复制存档进入',()=>enter('copy'));
 const fresh=button('新存档进入',()=>enter('fresh'));
 const resume=button('继续测试进度',()=>enter('continue'));resume.hidden=true;
 const cancel=button('暂不',()=>{if(!busy)collapse();});
 const manage=document.createElement('a');manage.href=BETA_PATH+'?manage=1';manage.textContent='管理测试存档';
 panel.append(title,note,actions,status,manage);root.append(toggle,panel);document.body.append(root);
 const refresh=async()=>{try{resume.hidden=!(await readActive(storage,validateSave));}catch{resume.hidden=true;}};
 toggle.onclick=()=>{panel.hidden=!panel.hidden;toggle.setAttribute('aria-expanded',String(!panel.hidden));if(!panel.hidden)refresh();else acknowledge();};
 toggle.setAttribute('aria-expanded',String(!panel.hidden));
 root.addEventListener('keydown',event=>event.stopPropagation()); // Keyup still reaches Game so held driving keys cannot stick.
 window.addEventListener('pageshow',()=>{generation++;firstSnapshot=undefined;setBusy(false);panel.hidden=betaEntryDismissed(storage);toggle.setAttribute('aria-expanded',String(!panel.hidden));refresh();});
 window.addEventListener('pagehide',()=>{generation++;});
 refresh();return{root,panel,toggle,copy,fresh,resume,cancel,status};
}
if(typeof window!=='undefined'&&BETA_ENTRY_ENABLED){
 const ready=()=>{if(!window.game||!document.getElementById('loading')?.hidden){setTimeout(ready,700);return;}try{installBetaEntry({document,window,storage:localStorage});}catch{}};ready();
}
