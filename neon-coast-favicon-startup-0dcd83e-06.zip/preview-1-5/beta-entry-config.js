// Enable only in the atomic standard + /beta deployment.
export const BETA_ENTRY_ENABLED=true;
