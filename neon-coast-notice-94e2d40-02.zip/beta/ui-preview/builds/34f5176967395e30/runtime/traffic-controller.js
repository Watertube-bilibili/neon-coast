import {PilotController} from './pilot.js';
import {trafficAvoidance} from './population-stream.js';
import {vehicleLongitudinalForces} from './vehicle-physics.js';

const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const distance=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z);
const wrap=a=>Math.atan2(Math.sin(a),Math.cos(a));
const hold=()=>({throttle:0,steer:0,brake:1,brakeSource:'pilot',electronicBrake:1});

function makeRoute(vehicle){
 const start=((vehicle.index??0)%vehicle.path.length+vehicle.path.length)%vehicle.path.length;
 const route=Array.from({length:vehicle.path.length*3},(_,i)=>vehicle.path[(start+i)%vehicle.path.length]);
 const geometry=new PilotController({vehicle});geometry.setRoute(route);
 return vehicle.trafficRoute={source:vehicle.path,start,geometry,lastSteer:vehicle.steer??0,acceleration:0,lastPosition:{x:vehicle.pos.x,z:vehicle.pos.z}};
}

/** NPC road geometry is public engine data, independent of the player's camera.
 * Follow the same junction-sized fillets as Pilot, rather than aiming at the
 * next block's corner while still travelling along the previous road. Every
 * command is applied by the ordinary bounded steering, grip and collision model.
 */
export function trafficControls(game,vehicle,dt=1/60){
 const v=vehicle;
 if(!Array.isArray(v.path)||v.path.length<2||v.condition<=0)return hold();
 let state=v.trafficRoute;
 if(!state||state.source!==v.path||distance(state.lastPosition,v.pos)>25)state=makeRoute(v);
 let p=state.geometry;
 let projected=p.project(v.pos,Math.max(0,p.segment-3));
 p.progress=Math.max(p.progress,projected.s);p.segment=projected.index;
 v.index=(state.start+p.path[Math.min(p.segment+1,p.path.length-1)].routeIndex)%v.path.length;
 // Rebuild only the forward corridor; the actual car pose and momentum remain.
 if(p.path.at(-1).s-p.progress<80){state=makeRoute(v);p=state.geometry;projected=p.project(v.pos);}
 state.lastPosition={x:v.pos.x,z:v.pos.z};
 if(v.wait>0){v.wait=Math.max(0,v.wait-dt);return hold();}
 const speed=Math.max(0,v.speed),lookahead=clamp(3.5+speed*.42,3.5,8);
 const aim=p.at(p.progress+lookahead),rear={x:v.pos.x+Math.sin(v.yaw)*v.rearAxle,z:v.pos.z+Math.cos(v.yaw)*v.rearAxle};
 const angle=wrap(Math.atan2(-(aim.x-rear.x),-(aim.z-rear.z))-v.yaw);
 const steer=clamp(Math.atan2(2*v.wheelBase*Math.sin(angle),Math.max(2.5,distance(aim,rear))),-v.maxSteer,v.maxSteer);
 state.lastSteer+=clamp(steer-state.lastSteer,-1.35*dt,1.35*dt);
 let target=Math.min(v.cruise??9,12);
 for(let i=p.segment;i<p.path.length&&p.path[i].s<p.progress+Math.max(36,speed*4);i++){
  const q=p.path[i],corner=Math.sqrt(2.5/Math.max(.001,q.curvature));
  target=Math.min(target,Math.sqrt(corner*corner+2*2.5*Math.max(0,q.s-p.progress-3)));
 }
 if(Math.abs(angle)>.75)target=Math.min(target,3);
 if(projected.distance>2.5)target=Math.min(target,4);
 if(projected.distance>9)target=0;
 const crossing=p.crossings.find(e=>e.s>p.progress-22);
 if(crossing){
  const until=crossing.s-p.progress,green=game.signalGreen?.(crossing)!==false;
  if(p.crossingCommit&&p.crossingCommit!==crossing.key)p.crossingCommit=null;
  if(!p.crossingCommit&&green&&until<22&&until>-22)p.crossingCommit=crossing.key;
  if(p.crossingCommit!==crossing.key&&!green&&until>-22)target=Math.min(target,Math.sqrt(2*2.5*Math.max(0,until-19)));
 }
 const avoid=trafficAvoidance(game,v,target);target=Math.min(target,avoid.targetSpeed);
 const request=clamp((target-speed)*1.65,-4.5,2.5);
 state.acceleration+=clamp(request-state.acceleration,-7*dt,3*dt);
 const forces=vehicleLongitudinalForces(v),a=state.acceleration+forces.dragDeceleration;
 let throttle=clamp(a/Math.max(1,v.model.power),0,1),brake=a<0?clamp(-a/forces.serviceBrakeDeceleration,0,.9):0;
 brake=Math.max(brake,avoid.brake);
 if(target<.2&&speed<.6){throttle=0;brake=Math.max(.4,brake);}
 if(brake>0)throttle=0;
 return{throttle,steer:state.lastSteer,brake,brakeSource:'pilot',electronicBrake:brake};
}
