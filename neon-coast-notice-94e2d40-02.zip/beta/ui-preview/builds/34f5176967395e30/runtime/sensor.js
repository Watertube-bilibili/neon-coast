import * as THREE from './vendor/three.module.js';

const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
// Both passes are rendered through the real front camera. The semantic pass
// uses ENGINE LABELS, not neural RGB inference. Depth testing and the camera
// frustum determine which labelled pixels are visible. A tiny depth readback
// measures the visible surfaces, just as a simulated depth camera would; it
// cannot recover an occluded object. Entity positions and
// traffic lists are never used to detect, locate, or track other road users.
export class VisionSensor {
 constructor(renderer,scene,canvas){
  this.renderer=renderer;this.scene=scene;this.canvas=canvas;this.ctx=canvas.getContext('2d');
  this.w=128;this.h=72;this.camera=new THREE.PerspectiveCamera(82,this.w/this.h,.15,90);
  this.rgbTarget=new THREE.WebGLRenderTarget(this.w,this.h,{depthBuffer:true});
  this.semanticTarget=new THREE.WebGLRenderTarget(this.w,this.h,{depthBuffer:true});
  this.semanticTarget.depthTexture=new THREE.DepthTexture(this.w,this.h,THREE.UnsignedIntType);
  this.depthTarget=new THREE.WebGLRenderTarget(this.w,this.h,{depthBuffer:false});
  this.depthPixels=new Uint8Array(this.w*this.h*4);this.depthPoint=new THREE.Vector3();
  this.depthScene=new THREE.Scene();this.depthCamera=new THREE.OrthographicCamera(-1,1,1,-1,0,1);
  this.depthQuad=new THREE.Mesh(new THREE.PlaneGeometry(2,2),new THREE.ShaderMaterial({
   uniforms:{depthMap:{value:this.semanticTarget.depthTexture}},depthTest:false,depthWrite:false,
   vertexShader:'varying vec2 uvDepth; void main(){uvDepth=uv; gl_Position=vec4(position.xy,0.,1.);}',
   fragmentShader:'uniform sampler2D depthMap; varying vec2 uvDepth; void main(){float n=floor(texture2D(depthMap,uvDepth).r*16777215.0+0.5); gl_FragColor=vec4(floor(n/65536.0),mod(floor(n/256.0),256.0),mod(n,256.0),255.0)/255.0;}'
  }));this.depthScene.add(this.depthQuad);
  this.rgb=new Uint8Array(this.w*this.h*4);this.pixels=new Uint8Array(this.w*this.h*4);
  this.classes=new Uint8Array(this.w*this.h);
  this.materials=[0x000000,0x00aa50,0xffffff,0xff0000,0xffff00,0x2233ff].map(color=>new THREE.MeshBasicMaterial({color,side:THREE.DoubleSide,toneMapped:false}));
  // Keep ordinary and instanced shader variants on separate palettes.
  this.instancedMaterials=this.materials.map(m=>m.clone());
  this.data={confidence:0,laneOffset:0,obstacle:90,pedestrians:0,cars:0,boxes:[],tracks:[],road:[],staticObstacles:[],timestamp:0,frames:0,source:'semantic-camera'};
  this.ray=new THREE.Raycaster();this.plane=new THREE.Plane(new THREE.Vector3(0,1,0),0);this.point=new THREE.Vector3();
  this.trackMemory=[];this.nextTrackId=1;this.previousPose=null;this.depthValid=false;
 }
 capture(car,hidden=[],time=0){
  const r=this.renderer,front=new THREE.Vector3(0,1.43,-2.5).applyAxisAngle(new THREE.Vector3(0,1,0),car.yaw).add(car.pos);
  this.camera.position.copy(front);this.camera.lookAt(front.x-Math.sin(car.yaw)*30,front.y-1.2,front.z-Math.cos(car.yaw)*30);
  this.camera.updateMatrixWorld(true);
  const visibility=[...new Set(hidden)].map(o=>[o,o.visible]);visibility.forEach(([o])=>o.visible=false);
  const state={background:this.scene.background,fog:this.scene.fog,target:r.getRenderTarget(),face:r.getActiveCubeFace(),mip:r.getActiveMipmapLevel(),tone:r.toneMapping,autoClear:r.autoClear,viewport:r.getViewport(new THREE.Vector4()),scissor:r.getScissor(new THREE.Vector4()),scissorTest:r.getScissorTest(),shadowUpdate:r.shadowMap.autoUpdate,xr:r.xr.enabled};
  const changed=[];
  try{
   r.xr.enabled=false;r.shadowMap.autoUpdate=false;r.autoClear=true;
   r.setRenderTarget(this.rgbTarget);r.setScissorTest(false);r.render(this.scene,this.camera);
   r.readRenderTargetPixels(this.rgbTarget,0,0,this.w,this.h,this.rgb);
   this.scene.traverse(o=>{if(o.isMesh){
    changed.push([o,o.material,o.instanceColor]);const palette=o.isInstancedMesh?this.instancedMaterials:this.materials;o.material=palette[o.userData.semantic??0]??palette[0];
    // Instance colours also multiply MeshBasicMaterial, independently of its
    // vertexColors flag. Remove them only for this pass to preserve class IDs.
    // Three.js switches the USE_INSTANCING_COLOR shader variant automatically.
    if(o.isInstancedMesh)o.instanceColor=null;
   }});
   this.scene.background=new THREE.Color(0x000000);this.scene.fog=null;r.toneMapping=THREE.NoToneMapping;
   r.setRenderTarget(this.semanticTarget);r.setScissorTest(false);r.render(this.scene,this.camera);
   r.readRenderTargetPixels(this.semanticTarget,0,0,this.w,this.h,this.pixels);
   r.setRenderTarget(this.depthTarget);r.render(this.depthScene,this.depthCamera);
   r.readRenderTargetPixels(this.depthTarget,0,0,this.w,this.h,this.depthPixels);this.depthValid=true;
  }finally{
   changed.forEach(([o,m,color])=>{o.material=m;if(o.isInstancedMesh)o.instanceColor=color});visibility.forEach(([o,v])=>o.visible=v);
   this.scene.background=state.background;this.scene.fog=state.fog;r.toneMapping=state.tone;r.autoClear=state.autoClear;
   r.shadowMap.autoUpdate=state.shadowUpdate;r.xr.enabled=state.xr;
   r.setRenderTarget(state.target,state.face,state.mip);r.setViewport(state.viewport);r.setScissor(state.scissor);r.setScissorTest(state.scissorTest);
  }
  this.analyze(car,time);this.draw();return this.data;
 }
 classify(x,y){
  const idx=((this.h-1-y)*this.w+x)*4,r=this.pixels[idx],g=this.pixels[idx+1],b=this.pixels[idx+2];
  if(r>150&&g<90&&b<90)return 3;if(r>150&&g>150&&b<90)return 4;
  if(g>70&&r<100&&b<130)return 1;if(b>120&&r<120&&g<130)return 5;
  if(r>150&&g>150&&b>150)return 2;return 0;
 }
 ground(x,y,car){
  this.ray.setFromCamera(new THREE.Vector2(2*x/this.w-1,1-2*y/this.h),this.camera);
  // Horizon/above-horizon components must not become fictitious 90 m cars.
  if(this.ray.ray.direction.y>=-.008||!this.ray.ray.intersectPlane(this.plane,this.point))return null;
  const dx=this.point.x-car.pos.x,dz=this.point.z-car.pos.z;
  const distance=-dx*Math.sin(car.yaw)-dz*Math.cos(car.yaw),lateral=dx*Math.cos(car.yaw)-dz*Math.sin(car.yaw);
  if(!Number.isFinite(distance)||!Number.isFinite(lateral)||distance<.5||distance>85||Math.abs(lateral)>55)return null;
  return{distance,lateral,worldX:this.point.x,worldZ:this.point.z};
 }
 components(){
  const seen=new Uint8Array(this.w*this.h),found=[];
  for(let y=0;y<this.h;y++)for(let x=0;x<this.w;x++){
   const cls=this.classes[y*this.w+x],idx=y*this.w+x;
   if((cls!==3&&cls!==4)||seen[idx])continue;
   const stack=[idx];let minX=x,maxX=x,minY=y,maxY=y,count=0;seen[idx]=1;
   while(stack.length){
    const p=stack.pop(),px=p%this.w,py=(p/this.w)|0;count++;
    minX=Math.min(minX,px);maxX=Math.max(maxX,px);minY=Math.min(minY,py);maxY=Math.max(maxY,py);
    for(const q of [p-1,p+1,p-this.w,p+this.w]){
     if(q<0||q>=seen.length||seen[q])continue;const qx=q%this.w;
     if(Math.abs(qx-px)>1||this.classes[q]!==cls)continue;seen[q]=1;stack.push(q);
    }
   }
   if(count>=2)found.push({cls,minX,maxX,minY,maxY,count});
  }
  // Join small disconnected tyre/body or leg/body fragments only when their
  // image boxes almost touch. Nearby separate vehicles remain separate.
  for(let i=0;i<found.length;i++)for(let j=found.length-1;j>i;j--){
   const a=found[i],b=found[j];if(a.cls!==b.cls)continue;
   const xOverlap=Math.min(a.maxX,b.maxX)-Math.max(a.minX,b.minX)+1;
   const yOverlap=Math.min(a.maxY,b.maxY)-Math.max(a.minY,b.minY)+1;
   const xGap=Math.max(a.minX,b.minX)-Math.min(a.maxX,b.maxX)-1;
   const yGap=Math.max(a.minY,b.minY)-Math.min(a.maxY,b.maxY)-1;
   if((xOverlap>0&&yGap<=2)||(yOverlap>1&&xGap<=1&&Math.min(a.count,b.count)<8)){
    a.minX=Math.min(a.minX,b.minX);a.maxX=Math.max(a.maxX,b.maxX);a.minY=Math.min(a.minY,b.minY);a.maxY=Math.max(a.maxY,b.maxY);a.count+=b.count;found.splice(j,1);
   }
  }
  return found.filter(b=>b.count>=3);
 }
 depthSample(x,y,car){
  if(!this.depthValid)return null;
  const offset=((this.h-1-y)*this.w+x)*4,p=this.depthPixels;
  const depth=(p[offset]*65536+p[offset+1]*256+p[offset+2])/16777215;
  if(depth<=0||depth>=.99999)return null;
  const point=this.depthPoint.set(2*(x+.5)/this.w-1,1-2*(y+.5)/this.h,2*depth-1).unproject(this.camera);
  const dx=point.x-car.pos.x,dz=point.z-car.pos.z,distance=-dx*Math.sin(car.yaw)-dz*Math.cos(car.yaw),lateral=dx*Math.cos(car.yaw)-dz*Math.sin(car.yaw);
  if(distance<.4||distance>85||Math.abs(lateral)>55)return null;
  return{distance,lateral,worldX:point.x,worldZ:point.z,height:point.y-car.pos.y};
 }
 observedSurface(box,car){
  // Use only visible labelled depth pixels, preferring the lower body. This
  // avoids integer-row ground projection jitter and compensates ego motion.
  const samples=[],startY=Math.max(box.minY,box.maxY-Math.max(2,Math.round((box.maxY-box.minY)*.4)));
  for(let y=startY;y<=box.maxY;y++)for(let x=box.minX;x<=box.maxX;x++){
   if(this.classes[y*this.w+x]!==box.cls)continue;
   const p=this.depthSample(x,y,car);if(p&&p.height<2.6&&p.height>-.3)samples.push(p);
  }
  if(!samples.length)return this.ground((box.minX+box.maxX+1)/2,box.maxY+1,car);
  const median=key=>{const values=samples.map(p=>p[key]).sort((a,b)=>a-b),i=Math.floor(values.length/2);return values.length%2?values[i]:(values[i-1]+values[i])/2};
  const worldX=median('worldX'),worldZ=median('worldZ'),dx=worldX-car.pos.x,dz=worldZ-car.pos.z;
  return{worldX,worldZ,distance:-dx*Math.sin(car.yaw)-dz*Math.cos(car.yaw),lateral:dx*Math.cos(car.yaw)-dz*Math.sin(car.yaw)};
 }
 staticSurfaces(car){
  // Class 5 includes walls, poles, grass and trees. Depth pixels separate
  // car-height visible surfaces from flat terrain and overhead leaves.
  // Keep compact metric cells so a long roadside wall never becomes a wide
  // fictitious box stretching across the travel corridor.
  const cells=new Map();
  for(let y=0;y<this.h;y++)for(let x=0;x<this.w;x++){
   if(this.classes[y*this.w+x]!==5)continue;
   const p=this.depthSample(x,y,car);if(!p||p.height<.26||p.height>1.85)continue;
   const key=Math.floor(p.distance/2)+':'+Math.floor(p.lateral/1.2);
   let cell=cells.get(key);if(!cell){cell={distance:p.distance,left:p.lateral,right:p.lateral,count:0,minY:y,maxY:y};cells.set(key,cell)}
   cell.distance=Math.min(cell.distance,p.distance);cell.left=Math.min(cell.left,p.lateral);cell.right=Math.max(cell.right,p.lateral);cell.count++;cell.minY=Math.min(cell.minY,y);cell.maxY=Math.max(cell.maxY,y);
  }
  return [...cells.values()].filter(c=>c.count>=2&&(c.maxY-c.minY>=1||c.right-c.left>.65)).map(c=>({distance:c.distance,lateral:(c.left+c.right)/2,width:Math.max(.25,c.right-c.left+.18),confidence:clamp(.45+c.count*.04,.45,.95)})).sort((a,b)=>a.distance-b.distance).slice(0,100);
 }
 updateTracks(detections,car,time){
  const pose=this.previousPose,dt=pose?time-pose.time:0,travel=pose?Math.hypot(car.pos.x-pose.x,car.pos.z-pose.z):0;
  const yawChange=pose?Math.atan2(Math.sin(car.yaw-pose.yaw),Math.cos(car.yaw-pose.yaw)):0;
  const discontinuity=!pose||dt<=0||dt>.65||travel>Math.max(6,dt*68)||Math.abs(yawChange)>Math.max(.8,dt*3.5);
  if(discontinuity)this.trackMemory=[];
  const egoVx=discontinuity?-Math.sin(car.yaw)*(car.speed??0):(car.pos.x-pose.x)/dt;
  const egoVz=discontinuity?-Math.cos(car.yaw)*(car.speed??0):(car.pos.z-pose.z)/dt;
  const egoForward=-egoVx*Math.sin(car.yaw)-egoVz*Math.cos(car.yaw);
  this.previousPose={x:car.pos.x,z:car.pos.z,yaw:car.yaw,time};
  const memory=this.trackMemory.filter(t=>time-t.lastSeen<=.32),used=new Set(),tracks=[];
  // Solve the best pairings globally so object iteration order cannot steal a
  // neighbouring track when two objects overlap or cross in the camera.
  const pairs=[];
  for(let i=0;i<detections.length;i++)for(const t of memory){
   const d=detections[i];if(t.cls!==d.cls)continue;
   const elapsed=time-t.lastSeen,predX=t.worldX+t.vx*elapsed,predZ=t.worldZ+t.vz*elapsed;
   const separation=Math.hypot(d.worldX-predX,d.worldZ-predZ),gate=Math.min(8,1+d.distance*.045+elapsed*(d.cls===4?5:16));
   if(separation<gate)pairs.push({i,t,score:separation/gate});
  }
  pairs.sort((a,b)=>a.score-b.score);const matches=new Map();
  for(const pair of pairs)if(!matches.has(pair.i)&&!used.has(pair.t.id)){matches.set(pair.i,pair.t);used.add(pair.t.id)}
  for(let i=0;i<detections.length;i++){
   const d=detections[i],best=matches.get(i),continuous=best?.visible&&time-best.lastSeen<=.24;
   const observations=continuous?best.observations+1:1;
   const history=continuous?[...best.history.filter(p=>time-p.time<=.8),{x:d.worldX,z:d.worldZ,time}]:[{x:d.worldX,z:d.worldZ,time}];
   let vx=0,vz=0,motionConfidence=0,motionValid=false;
   const span=time-history[0].time;
   if(history.length>=3&&span>=.18){
    const mean=history.reduce((a,p)=>({x:a.x+p.x/history.length,z:a.z+p.z/history.length,time:a.time+p.time/history.length}),{x:0,z:0,time:0});
    let denominator=0,nx=0,nz=0;
    for(const p of history){const t=p.time-mean.time;denominator+=t*t;nx+=t*(p.x-mean.x);nz+=t*(p.z-mean.z)}
    const limit=d.cls===4?5.5:50;vx=nx/Math.max(denominator,.0001);vz=nz/Math.max(denominator,.0001);
    const speed=Math.hypot(vx,vz);if(speed>limit){vx*=limit/speed;vz*=limit/speed}
    const gain=best?.motionValid?1-Math.exp(-(time-best.lastSeen)/.22):1;
    vx=(best?.vx??0)+(vx-(best?.vx??0))*gain;vz=(best?.vz??0)+(vz-(best?.vz??0))*gain;
    if(Math.hypot(vx,vz)<.22){vx=0;vz=0}
    const residual=history.reduce((sum,p)=>sum+Math.hypot(p.x-mean.x-vx*(p.time-mean.time),p.z-mean.z-vz*(p.time-mean.time)),0)/history.length;
    motionConfidence=clamp(span/.55,0,1)*clamp(1-residual/2.5,0,1)*d.confidence;motionValid=motionConfidence>.15;
   }
   const t={id:best?.id??this.nextTrackId++,cls:d.cls,worldX:d.worldX,worldZ:d.worldZ,width:d.width,length:d.cls===4?.6:clamp(d.width*2.25,3.5,5.6),confidence:d.confidence,lastSeen:time,age:0,visible:true,vx,vz,motionConfidence,motionValid,observations,history};
   tracks.push(t);d.trackId=t.id;
  }
  for(const t of memory)if(!used.has(t.id))tracks.push({...t,visible:false,age:Math.max(0,time-t.lastSeen),motionValid:false,motionConfidence:0,vx:0,vz:0});
  this.trackMemory=tracks;
  return tracks.map(t=>{
   const dx=t.worldX-car.pos.x,dz=t.worldZ-car.pos.z,distance=-dx*Math.sin(car.yaw)-dz*Math.cos(car.yaw);
   const forwardSpeed=-t.vx*Math.sin(car.yaw)-t.vz*Math.cos(car.yaw),lateralSpeed=t.vx*Math.cos(car.yaw)-t.vz*Math.sin(car.yaw),closingSpeed=egoForward-forwardSpeed;
   return{id:t.id,cls:t.cls,distance,lateral:dx*Math.cos(car.yaw)-dz*Math.sin(car.yaw),worldX:t.worldX,worldZ:t.worldZ,vx:t.vx,vz:t.vz,forwardSpeed,lateralSpeed,closingSpeed,ttc:closingSpeed>.15?Math.max(0,distance-2.6)/closingSpeed:Infinity,width:t.width,length:t.length,confidence:t.confidence*(t.visible?1:Math.max(0,1-t.age/.32)),motionConfidence:t.motionConfidence,motionValid:t.motionValid,observations:t.observations,lastSeen:t.lastSeen,age:t.age,visible:t.visible};
  }).filter(t=>t.distance>.5&&t.distance<85&&Math.abs(t.lateral)<55);
 }
 analyze(car,time){
  for(let y=0;y<this.h;y++)for(let x=0;x<this.w;x++)this.classes[y*this.w+x]=this.classify(x,y);
  let roads=0,total=0,center=0,weight=0;const road=[];
  for(let y=40;y<69;y+=3){
   let sum=0,n=0;for(let x=12;x<116;x+=2){const cls=this.classes[y*this.w+x];total++;if(cls===1||cls===2){roads++;sum+=x;n++}}
   if(n>2){center+=((sum/n-64)/64)*(y-37);weight+=y-37}
  }
  // Road silhouette samples, not invented lane detections. Choose the visible
  // contiguous road interval closest to the vehicle centre in each image row.
  for(const y of [38,41,45,50,57,66]){
   const runs=[];let start=-1;
   for(let x=0;x<=this.w;x++){
    const cls=x<this.w?this.classes[y*this.w+x]:0,isRoad=cls===1||cls===2;
    if(isRoad&&start<0)start=x;
    if(!isRoad&&start>=0){if(x-start>=5)runs.push([start,x-1]);start=-1}
   }
   runs.sort((a,b)=>Math.abs((a[0]+a[1])/2-64)-Math.abs((b[0]+b[1])/2-64));
   if(!runs.length)continue;const [left,right]=runs[0],a=this.ground(left+.5,y+.5,car),b=this.ground(right+.5,y+.5,car);
   if(a&&b)road.push({distance:(a.distance+b.distance)/2,left:a.lateral,right:b.lateral,confidence:clamp((right-left)/20,.15,1)});
  }
  const detections=[];
  for(const box of this.components()){
   const ground=this.observedSurface(box,car);if(!ground)continue;
   const a=this.ground(box.minX,box.maxY+1,car),b=this.ground(box.maxX+1,box.maxY+1,car);
   const observedWidth=a&&b?Math.abs(b.lateral-a.lateral):box.cls===4?.55:1.85;
   const confidence=clamp(.3+Math.sqrt(box.count)/28,.3,.98)*(box.minX===0||box.maxX===this.w-1?.65:1);
   detections.push({...box,...ground,width:clamp(observedWidth,box.cls===4?.3:1.35,box.cls===4?1:3.1),confidence});
  }
  const tracks=this.updateTracks(detections,car,time),staticObstacles=this.staticSurfaces(car);
  const inPath=tracks.filter(d=>d.visible&&Math.abs(d.lateral)<1.15+d.width/2);
  const nearest=Math.min(90,...inPath.map(d=>d.distance),...staticObstacles.filter(d=>Math.abs(d.lateral)<1.15+d.width/2).map(d=>d.distance));
  this.data={confidence:Math.min(1,roads/Math.max(1,total)*1.45),laneOffset:weight?center/weight:0,obstacle:nearest,pedestrians:detections.filter(d=>d.cls===4).length,cars:detections.filter(d=>d.cls===3).length,boxes:detections,tracks,road,staticObstacles,timestamp:time,frames:this.data.frames+1,source:'semantic-camera'};
 }
 draw(){
  const c=this.ctx,w=this.w,h=this.h,im=c.createImageData(w,h);
  for(let y=0;y<h;y++){const from=(h-1-y)*w*4,to=y*w*4;im.data.set(this.rgb.subarray(from,from+w*4),to)}
  const temp=this.temp??(this.temp=document.createElement('canvas'));temp.width=w;temp.height=h;temp.getContext('2d').putImageData(im,0,0);
  c.drawImage(temp,0,0,this.canvas.width,this.canvas.height);const sx=this.canvas.width/w,sy=this.canvas.height/h;
  for(const b of this.data.boxes){
   c.strokeStyle=b.cls===4?'#ffce65':'#9fe9d0';c.lineWidth=1;c.strokeRect(b.minX*sx,b.minY*sy,(b.maxX-b.minX+1)*sx,(b.maxY-b.minY+1)*sy);
   c.font='9px monospace';c.fillStyle=c.strokeStyle;c.fillText((b.cls===4?'PERSON':'VEHICLE')+' '+b.distance.toFixed(0)+'m',b.minX*sx,Math.max(9,b.minY*sy-3));
  }
 }
 reset(){
  this.trackMemory=[];this.previousPose=null;this.depthValid=false;this.data={confidence:0,laneOffset:0,obstacle:90,pedestrians:0,cars:0,boxes:[],tracks:[],road:[],staticObstacles:[],timestamp:0,frames:0,source:'semantic-camera'};
  this.pixels.fill(0);this.rgb.fill(0);this.classes.fill(0);this.ctx.clearRect(0,0,this.canvas.width,this.canvas.height);
 }
 dispose(){this.rgbTarget.dispose();this.semanticTarget.dispose();this.depthTarget.dispose();this.depthQuad.geometry.dispose();this.depthQuad.material.dispose();this.materials.forEach(m=>m.dispose());this.instancedMaterials.forEach(m=>m.dispose());this.trackMemory=[]}
}
