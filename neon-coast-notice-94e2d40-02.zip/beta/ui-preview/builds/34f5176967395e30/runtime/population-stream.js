import {repairAxleFault} from './axle-fault.js';
import {GRID, WORLD_LIMIT, WORLD_MIN_X,groundHeight,roadEdgeAllowed} from './streaming-world.js';
import {resetVehiclePose} from './render-motion.js';
import {resetVehicleDynamics} from './vehicle-physics.js';
import {repairBrakeFault} from './brake-fault.js';
import {repairVehicleDamage} from './vehicle-damage.js';

// A fixed pool follows the player. World extent never changes the actor budget.
export const TRAFFIC_BUDGETS=Object.freeze({low:24,medium:34,high:44});
const MODELS=['s','m','estate','x','coupe','vela','nomad','aria'];
const COLORS=[0xf0d6a1,0x6c8d89,0xe1ddd0,0x536674,0xc68c77,0x859bc1];
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const distance=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z);
export const trafficBudget=quality=>TRAFFIC_BUDGETS[quality]??TRAFFIC_BUDGETS.medium;
// Device-aware caps may shrink the ordinary pool, but never park the player's
// car, a private parked car, an active taxi or a protected mission vehicle.
export const gameTrafficBudget=game=>Number.isInteger(game.performanceProfile?.trafficBudget)
 ?clamp(game.performanceProfile.trafficBudget,16,44):trafficBudget(game.quality);
export const activeTraffic=c=>!c.populationDormant&&c.root?.visible!==false;

export function ensurePopulationPool(game){
 const budget=gameTrafficBudget(game),pool=game.traffic.filter(c=>!c.parked&&!c.isRobotaxi&&!c.populationProtected);
 if(typeof game.makeVehicle==='function')while(pool.length<budget){
  const i=pool.length,c=game.makeVehicle(MODELS[i%MODELS.length],game.position.x,game.position.z,0,true,COLORS[i%COLORS.length]);
  Object.assign(c,{id:'local-'+i,cruise:7+i%5,wait:0,path:[],index:0,populationInitialized:false,populationDormant:true});
  c.root.visible=false;game.traffic.push(c);pool.push(c);
 }
 pool.forEach((c,i)=>{c.populationInitialized??=false;c.populationDormant=i>=budget;if(c.populationDormant){c.root.visible=false;c.speed=0;}});
 return budget;
}

function candidates(p,seed){
 const cellX=Math.round(p.x/GRID),cellZ=Math.round(p.z/GRID),result=[];
 // Mid-block positions avoid spawning at junctions. Loop roads are right-hand lanes.
 for(let ring=1;ring<=4;ring++)for(let dx=-ring;dx<=ring;dx++)for(let dz=-ring;dz<=ring;dz++){
  if(Math.max(Math.abs(dx),Math.abs(dz))!==ring)continue;
  const x=clamp((cellX+dx)*GRID,-240,WORLD_LIMIT-GRID),z=clamp((cellZ+dz)*GRID,-WORLD_LIMIT+GRID,WORLD_LIMIT-GRID);
  const nodes=[{x,z},{x:x+GRID,z},{x:x+GRID,z:z+GRID},{x,z:z+GRID}];
  if(nodes.some((a,j)=>!roadEdgeAllowed(a,nodes[(j+1)%4])))continue;
  if(x===-80&&(z===0||z===80))continue; // Original showroom closes the -80..0 / z80 link.
  const path=[{x:x+4.5,z:z+GRID-4.5},{x:x+4.5,z:z+4.5},{x:x+GRID-4.5,z:z+4.5},{x:x+GRID-4.5,z:z+GRID-4.5}];
  for(let j=0;j<4;j++){const side=(j+seed)%4,a=path[side],b=path[(side+1)%4],fraction=.28+((seed+j)%3)*.22;
   result.push({path,index:(side+1)%4,x:a.x+(b.x-a.x)*fraction,z:a.z+(b.z-a.z)*fraction,yaw:Math.atan2(-(b.x-a.x),-(b.z-a.z))});}
 }
 return result.sort((a,b)=>Math.abs(distance(a,p)-110-(seed%4)*24)-Math.abs(distance(b,p)-110-(seed%4)*24));
}
function freeSpawn(game,p,ignore){
 if(distance(p,game.position)<35)return false;
 if(game.world?.colliders?.some(b=>Math.abs(p.x-b.x)<b.w+2&&Math.abs(p.z-b.z)<b.d+3))return false;
 const vehicles=[game.vehicle,...game.traffic,...(game.police??[])];
 if(vehicles.some(c=>c&&c!==ignore&&activeTraffic(c)&&distance(c.pos,p)<13))return false;
 return !(game.pedestrians??[]).some(a=>distance(a.root.position,p)<5);
}

export function streamPopulation(game,force=false){
 const p=game.position;
 if(!force&&game.time-(game.populationStreamTime??-10)<1)return;
 game.populationStreamTime=game.time;
 const budget=ensurePopulationPool(game);let active=0,relocated=0;
 for(let i=0;i<game.traffic.length;i++){
  const c=game.traffic[i],d=distance(c.pos,p);
  if(c.isRobotaxi||c.populationProtected){c.root.visible=d<720;continue;}
  if(c.parked){c.root.visible=d<650;continue;}
  if(c.populationDormant)continue;
  active++;
  if(c.populationInitialized!==false&&c.path?.length&&d<310){c.root.visible=true;c.populationInitialized=true;continue;}
  const spawn=candidates(p,i).find(q=>freeSpawn(game,q,c));
  if(!spawn){c.root.visible=false;c.populationInitialized=false;continue;}
  c.path=spawn.path;c.index=spawn.index;c.pos.set(spawn.x,groundHeight(spawn.x,spawn.z),spawn.z);c.yaw=spawn.yaw;
  c.root.rotation.y=c.yaw;c.speed=0;c.steer=0;c.bodyRoll=0;c.yawRate=0;c.lateralSpeed=0;c.slipVelocityX=0;c.slipVelocityZ=0;c.wait=.25+(i%4)*.15;
  // A pooled mesh represents a new road user at its new spawn. Never carry a
  // previous NPC's crash, flat battery, brake lifecycle or contact cooldown
  // into that identity. Parked/personal/taxi vehicles are excluded above.
  c.condition=100;c.battery=100;c.propulsionDisabled=false;c.travelDistance=0;if(game.newVehicleInstanceId)c.instanceId=game.newVehicleInstanceId();
  delete c.lastDamageTime;delete c.collisionDamage;delete c.trafficRoute;
  repairBrakeFault(c);repairAxleFault(c);repairVehicleDamage(c);
  resetVehicleDynamics(c);resetVehiclePose(c);c.populationInitialized=true;c.root.visible=true;relocated++;
 }
 for(let i=0;i<(game.pedestrians?.length??0);i++){
  const actor=game.pedestrians[i];if(distance(actor.root.position,p)<390)continue;
  const sidewalks=candidates(p,i).filter(q=>Math.abs(Math.cos(q.yaw))>.5).map(q=>{const x=Math.round(q.x/GRID)*GRID;return{x:x+Math.sign(q.x-x)*16,z:q.z};});
  const slot=sidewalks.find(q=>!game.world?.colliders?.some(b=>Math.abs(q.x-b.x)<b.w+.6&&Math.abs(q.z-b.z)<b.d+.6));
  if(!slot)continue;const{x,z}=slot;
  actor.origin={x,z};actor.root.position.set(x,groundHeight(x,z),z);actor.root.rotation.z=0;actor.crossing=false;actor.target=null;actor.knocked=0;actor.nextCross=10+i;actor.dir=i%2?1:-1;
 }

 game.populationStats={budget,active,relocated,pool:game.traffic.filter(c=>!c.parked&&!c.isRobotaxi&&!c.populationProtected).length};
 game._trafficSpatialIndex=null;
}

// Local NPC safety logic uses engine geometry, never pretends to be camera perception.
function spatialIndex(game){
 if(game._trafficSpatialIndex?.time===game.time)return game._trafficSpatialIndex;
 const cells=new Map(),seen=new Set();
 for(const c of [game.vehicle,...(game.traffic??[]),...(game.police??[])])if(c&&!seen.has(c)&&activeTraffic(c)){
  seen.add(c);const key=Math.floor(c.pos.x/24)+','+Math.floor(c.pos.z/24);if(!cells.has(key))cells.set(key,[]);cells.get(key).push(c);
 }
 return game._trafficSpatialIndex={time:game.time,cells};
}
export function trafficAvoidance(game,vehicle,desiredSpeed=vehicle.cruise??10){
 const v=vehicle,speed=Math.max(0,v.speed),fx=-Math.sin(v.yaw),fz=-Math.cos(v.yaw),rx=Math.cos(v.yaw),rz=-Math.sin(v.yaw),range=Math.min(72,Math.max(20,speed*2.6+10));
 let targetSpeed=desiredSpeed,nearestDistance=Infinity,blocked=false,emergency=false;
 const consider=(p,width,length,otherSpeed=0,pedestrian=false)=>{
  const dx=p.x-v.pos.x,dz=p.z-v.pos.z,forward=dx*fx+dz*fz,lateral=Math.abs(dx*rx+dz*rz);
  if(forward<-1||forward>range||lateral>(v.halfWidth??1)+width*.5+.55)return;
  const gap=forward-(v.wheelBase??2.8)*.5-1.2-length*.5;
  nearestDistance=Math.min(nearestDistance,gap);blocked=true;
  const desiredGap=pedestrian?4:3.5+speed*1.25,cap=Math.max(0,Math.min(otherSpeed+(gap-desiredGap)*.75,Math.sqrt(otherSpeed*otherSpeed+2*2.7*Math.max(0,gap-3))));
  targetSpeed=Math.min(targetSpeed,cap);if(gap<2.4||speed-otherSpeed>1&&gap/(speed-otherSpeed)<.9)emergency=true;
 };
 const index=spatialIndex(game),cx=Math.floor(v.pos.x/24),cz=Math.floor(v.pos.z/24),rings=Math.ceil(range/24);
 for(let x=cx-rings;x<=cx+rings;x++)for(let z=cz-rings;z<=cz+rings;z++)for(const other of index.cells.get(x+','+z)??[]){
  if(other===v||Math.abs((other.pos.y??0)-(v.pos.y??0))>3)continue;
  const aligned=Math.max(0,Math.cos(other.yaw-v.yaw));
  consider(other.pos,(other.halfWidth??1)*2,(other.wheelBase??2.8)+2.2,Math.max(0,other.speed)*aligned);
  // Crossing traffic must be yielded to before its centre enters our lane.
  if(Math.abs(Math.sin(other.yaw-v.yaw))>.65&&distance(other.pos,v.pos)<24){const t=clamp(distance(other.pos,v.pos)/Math.max(3,speed),.3,1.4);consider({x:other.pos.x-Math.sin(other.yaw)*other.speed*t,z:other.pos.z-Math.cos(other.yaw)*other.speed*t},2.2,4.5,0);}
 }
 for(const actor of game.pedestrians??[]){if(actor.knocked||actor.root.visible===false)continue;consider(actor.root.position,.8,.8,0,true);if(actor.crossing&&actor.target){const dx=actor.target.x-actor.root.position.x;consider({x:actor.root.position.x+Math.sign(dx)*actor.speed*1.2,z:actor.root.position.z},.8,.8,0,true);}}
 if(!game.inCar&&!game.robotaxi?.passenger&&!game.roboTaxi?.passenger&&game.playerPos)consider(game.playerPos,.8,.8,0,true);
 return{targetSpeed,brake:emergency?1:clamp((speed-targetSpeed)*.28,0,.85),nearestDistance,blocked,emergency};
}
