// User-requested reference build. Geometry is authored in Blender; no imported
// manufacturer mesh. Numeric prices/dynamics/range below are GAME BALANCING,
// not Tesla specifications. See model-source/roadster/README.md for sources.
export const ROADSTER_BRAND={id:'tesla',name:'TESLA',tagline:'Roadster · 三种驾驶配置',color:'#dce3ea'};
const base={previewImage:'./assets/roadster-preview.jpg',brand:'tesla',category:'电动跑车',color:0xe4e8ed,mass:1940,tireGrip:11.8,range:480};
export const ROADSTER_MODELS=[
 {...base,id:'roadster',name:'TESLA ROADSTER Performance',trim:'PERFORMANCE · 双座',desc:'Blender 自建银白楔形车身 · 双座内饰、上掀车门与可动尾翼（游戏性能设定，价格为游戏币）',price:155000,power:21,max:67,roadsterTrim:'performance'},
 {...base,id:'roadster_thrust',name:'TESLA ROADSTER Thrust',trim:'THRUST · 双座推进',desc:'双座赛道配置 · 后部冷气推进器、主动尾翼与手动推进（游戏性能设定，价格为游戏币）',price:195000,power:24,max:73,roadsterTrim:'thrust'},
 {...base,id:'roadster_rocket',name:'TESLA ROADSTER Rocket',trim:'ROCKET · 单座邀请体验',desc:'邀请体验 · 免费解锁 · 单座空中配置 · 周向姿态喷口、空中模式与车身矫正（游戏玩法，非真实操作说明）',price:0,availability:'invitation',power:24,max:73,roadsterTrim:'rocket'}
];
export const isRoadsterModel=id=>ROADSTER_MODELS.some(m=>m.id===(typeof id==='string'?id:id?.id));
