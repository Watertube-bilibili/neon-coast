// One route source for every navigation display. Taxi routes belong to the ride;
// they must not replace or borrow the player's saved navigation destination.
export function activeRouteView(game){
 const ride=game.robotaxi;
 if(ride?.active&&ride.taxi&&ride.driver?.geometry){
  const path=ride.driver.geometry,approach=!ride.passenger;
  return{kind:'taxi',owner:ride.driver,points:path.path,index:Math.min(path.path.length,Math.max(0,path.segment+1)),origin:ride.taxi.pos,
   destination:approach?{...ride.pickup,name:'接车点'}:ride.destination,
   remaining:Number.isFinite(ride.driver.remaining)?ride.driver.remaining:Math.max(0,(path.path.at(-1)?.s??0)-path.progress),
   label:approach?'Robo Taxi · 前来接你':'Robo Taxi · '+(ride.destination?.name??'接送目的地'),color:approach?'#55ddff':'#f2c36b'};
 }
 return{kind:'navigation',owner:game.route,points:game.route??[],index:game.routeIndex??0,origin:game.position,destination:game.destination,remaining:null,label:game.destination?.name??'',color:'#c4f580'};
}
