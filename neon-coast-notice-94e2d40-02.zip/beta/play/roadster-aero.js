/** Visible transforms reconstructed from Tesla's 2026-10-16 film.
 * Distances/timing are game approximation, not measured production specifications.
 * No chassis, contact, suspension, collision, mass or flight-force changes.
 */
export const ROADSTER_AERO_MODES=Object.freeze(['road','highDownforce','lowDrag']);
export const ROADSTER_AERO_LABELS=Object.freeze({road:'公路模式',highDownforce:'高下压力模式',lowDrag:'低风阻模式'});
export const ROADSTER_AERO_POSES=Object.freeze({
 road:Object.freeze({lift:0,rear:0,pitch:0,hood:0,side:0}),
 highDownforce:Object.freeze({lift:.34,rear:.18,pitch:.55,hood:.34,side:.62}),
 // Film only shows the rear during Low-Drag: retain previously opened fronts.
 lowDrag:Object.freeze({lift:.30,rear:.18,pitch:.035,hood:.34,side:.62})
});
const smooth=(a,b,x)=>{const t=Math.max(0,Math.min(1,(x-a)/(b-a)));return t*t*(3-2*t);};
const sane=(n,d=0)=>Number.isFinite(n)?n:d;
export function roadsterAeroMode(v){const m=v?.roadsterRequest?.aeroMode;return ROADSTER_AERO_MODES.includes(m)?m:'road';}
export function setRoadsterAeroMode(v,mode){if(!['roadster','roadster_thrust','roadster_rocket'].includes(v?.model?.id)||!ROADSTER_AERO_MODES.includes(mode))return false;v.roadsterRequest??={air:false,wingMode:'auto'};v.roadsterRequest.aeroMode=mode;return true;}
export function cycleRoadsterAero(v){const mode=ROADSTER_AERO_MODES[(ROADSTER_AERO_MODES.indexOf(roadsterAeroMode(v))+1)%3];return setRoadsterAeroMode(v,mode)?mode:null;}
export function updateRoadsterAero(v,dt){
 const rig=v.roadsterRig;if(!rig?.hoodAero)return false;
 const target=ROADSTER_AERO_POSES[roadsterAeroMode(v)],pose=v.roadsterAeroVisual??={...ROADSTER_AERO_POSES.road},alpha=1-Math.exp(-3.4*Math.max(0,Math.min(.1,sane(dt))));
 for(const key of Object.keys(target)){pose[key]=sane(pose[key])+(target[key]-sane(pose[key]))*alpha;if(Math.abs(target[key]-pose[key])<1e-6)pose[key]=target[key];}
 for(const node of [rig.wingLift,rig.wingPitch,rig.hoodAero,...(rig.sideAero??[]),...(rig.wingSupports??[])])if(node){node.userData??={};node.userData.aeroRest??={x:node.position.x,y:node.position.y,z:node.position.z,rx:node.rotation.x,ry:node.rotation.y,sy:node.scale.y};}
 // Clear the deep downturned tips before sliding aft or pitching; reverse on stow.
 const rearTravel=pose.rear*smooth(.26,.30,pose.lift),wingPitch=pose.pitch*smooth(.26,.30,pose.lift);
 const lift=rig.wingLift,pitch=rig.wingPitch;
 if(lift){const r=lift.userData.aeroRest;lift.position.y=r.y+pose.lift;lift.position.z=r.z+rearTravel;}
 if(pitch)pitch.rotation.x=pitch.userData.aeroRest.rx-wingPitch;
 rig.hoodAero.rotation.x=rig.hoodAero.userData.aeroRest.rx-pose.hood;
 for(let i=0;i<(rig.sideAero??[]).length;i++){const node=rig.sideAero[i];if(node)node.rotation.y=node.userData.aeroRest.ry+(i===0?-1:1)*pose.side;}
 for(const node of rig.wingSupports??[])if(node){const r=node.userData.aeroRest,h=Math.max(.04,(lift?.userData.aeroRest.y??r.y+.19)-r.y);node.scale.y=r.sy*Math.hypot(h+pose.lift,rearTravel)/h;node.rotation.x=r.rx+Math.atan2(rearTravel,h+pose.lift);}
 v.roadsterWingVisual=pose.lift/.34;
 return true;
}
