import {QUALITY_PREFERENCE_KEY} from './storage-keys.js';
// Quality is a presentation/population budget, never a physics or safety switch.
// Existing low/medium/high save values remain valid across phones and desktops.
export {QUALITY_PREFERENCE_KEY} from './storage-keys.js';
export const QUALITY_LEVELS=Object.freeze(['low','medium','high']);
const clamp=(value,min,max)=>Math.max(min,Math.min(max,value));
const valid=q=>QUALITY_LEVELS.includes(q);
const finite=(value,fallback)=>Number.isFinite(value)?value:fallback;

export function isMobilePerformanceDevice(env=globalThis){
 if(typeof env.mobile==='boolean')return env.mobile;
 let coarse=false;try{coarse=!!env.matchMedia?.('(pointer: coarse)').matches;}catch{}
 const width=finite(env.innerWidth,1920),height=finite(env.innerHeight,1080);
 return coarse||finite(env.navigator?.maxTouchPoints,0)>0&&Math.min(width,height)<=1024;
}
export const defaultQuality=(env=globalThis)=>isMobilePerformanceDevice(env)?'low':'medium';
export function restoreQualityPreference(storage,env=globalThis){
 try{const q=storage?.getItem(QUALITY_PREFERENCE_KEY);if(valid(q))return q;}catch{}
 return defaultQuality(env);
}
export function saveQualityPreference(storage,q){
 if(!valid(q))return false;
 try{storage?.setItem(QUALITY_PREFERENCE_KEY,q);return !!storage;}catch{return false;}
}

export function getPerformanceProfile(quality,env=globalThis){
 const mobile=isMobilePerformanceDevice(env),q=valid(quality)?quality:defaultQuality(env);
 const index=QUALITY_LEVELS.indexOf(q),pixelCap=(mobile?[1,1.25,1.5]:[1,1.5,2])[index];
 return Object.freeze({quality:q,mobile,pixelRatio:clamp(finite(env.devicePixelRatio,1),.5,pixelCap),
  shadows:index>0,shadowMapSize:(mobile?[0,768,1024]:[0,1024,1536])[index],
  trafficBudget:(mobile?[16,24,32]:[24,34,44])[index],sensorInterval:q==='low'?.18:.1});
}
