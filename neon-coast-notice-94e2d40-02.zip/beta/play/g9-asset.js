import {registerVehicleAsset} from './vehicle-asset-registry.js';

// Only this explicit request imports the geometry payload. Merely opening the
// game, reading the catalog or displaying the authored thumbnail does not.
export function createG9AssetStore(importAsset=()=>import('./assets/g9/g9-mesh-data.js')){
 let data=null,pending=null,error=null,attempts=0;
 return {
  ready:()=>!!data,
  data:()=>data,
  status:()=>({state:data?'ready':pending?'loading':error?'error':'idle',error:error?.message??null,attempts}),
  load(onProgress){
   if(data)return Promise.resolve(true);
   if(pending)return pending;
   attempts++;error=null;const progress=value=>{try{onProgress?.(value);}catch{ /* UI callbacks cannot invalidate loaded geometry. */ }};progress({loaded:0,total:1});
   pending=Promise.resolve().then(importAsset).then(module=>{
    const next=module.G9_MESH_DATA;
    if(!next?.simple?.meshes?.length||!next?.simple?.nodes?.length||!next?.detailed?.meshes?.length||!next?.detailed?.nodes?.length)throw new Error('G9 geometry payload is incomplete');
    data=next;progress({loaded:1,total:1});return true;
   }).catch(reason=>{error=reason instanceof Error?reason:new Error(String(reason));return false;}).finally(()=>{pending=null;});
   return pending;
  }
 };
}
const store=createG9AssetStore();
export const g9AssetReady=store.ready,g9AssetData=store.data,g9AssetStatus=store.status,loadG9Asset=store.load;
registerVehicleAsset(['g9'],{ready:g9AssetReady,load:loadG9Asset});
