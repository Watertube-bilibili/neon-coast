import {planRoute,nearestRoad,isRoadIntersection,groundHeight,roadEdgeAllowed,WORLD_LIMIT,WORLD_MIN_X} from './streaming-world.js';
import {taxiStop} from './robotaxi.js';
import {PilotController} from './pilot.js';
import {getVehicleCollider,boxContact} from './vehicle-dynamics.js';
import {safeVehicleExit} from './ground-contact.js';
import {setVehicleInteriorView,disposeVehicleInstruments} from './vehicle-instruments.js';
import {disposeVehicleDamage} from './vehicle-damage.js';
import {resetVehiclePose} from './render-motion.js';

export const AUTONOMY_TEST_JOB=Object.freeze({type:'autonomy-test',title:'自动驾驶测试员',reward:2600,modelId:'s',vehicleName:'VOLT 路测工作车',description:'公司配车 · 真实道路路测 · 模拟感知降级接管 · 驶回交车'});
const distance=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z);
const point=p=>({x:p.x,y:p.y??0,z:p.z});
const finite=p=>p&&Number.isFinite(p.x)&&Number.isFinite(p.z)&&p.x>WORLD_MIN_X+3&&p.x<WORLD_LIMIT-10&&Math.abs(p.z)<WORLD_LIMIT-10;
const clamp=(v,min,max)=>Math.max(min,Math.min(max,v));
const HOLD=Object.freeze({throttle:0,steer:0,brake:1,brakeSource:'pilot',electronicBrake:1,handbrake:false});
const PHASE_LABELS={idle:'待接单',outbound:'自动驾驶路测',takeover:'模拟感知降级 · 请手动接管',returning:'接管测试通过 · 返回交车',stopping:'正在安全停车',completed:'测试完成',cancelled:'工作已取消',failed:'测试未通过'};
const AUTO_METRES=60,MANUAL_METRES=8,STOP_SECONDS=1.0;

function segmentDistance(p,a,b){const dx=b.x-a.x,dz=b.z-a.z,d=dx*dx+dz*dz,t=d?clamp(((p.x-a.x)*dx+(p.z-a.z)*dz)/d,0,1):0;return Math.hypot(p.x-a.x-dx*t,p.z-a.z-dz*t);}
function routeLength(origin,route){let total=0,previous=origin;for(const p of route){total+=distance(previous,p);previous=p;}return total;}
function yawTo(a,b){return Math.atan2(-(b.x-a.x),-(b.z-a.z));}
function makeLeg(origin,route,target){
 const geometry=new PilotController({vehicle:{pos:origin,steer:0},destination:target});geometry.setRoute(route);
 const path=geometry.path.map(p=>({...p})),gates=[];let last=0;
 for(const p of path)if(p.s-last>=11){gates.push({...p});last=p.s;}
 if(!gates.length||distance(gates.at(-1),path.at(-1))>.05)gates.push({...path.at(-1)});
 return{origin:point(origin),route:route.map(point),target:{...target},path,gates,next:0,progress:0,total:path.at(-1)?.s??0,travel:0};
}

/** Company-car mission state only. The normal Game driving/integrate path owns
 * all motion, contacts and braking (including an authoritative engine backend).
 * A work-car spawn is the sole vehicle placement performed by this service. */
export class AutonomyTestJobService{
 constructor(game,options={}){this.g=game;this.options=options;this.planner=options.planRoute??planRoute;this.phase='idle';this.workVehicle=null;this.originalVehicle=null;this.context=null;this.leg=null;this.paid=false;this.notice='';}
 get active(){return ['outbound','takeover','returning','stopping'].includes(this.phase);}
 get status(){
  const leg=this.leg,progress=this.phase==='returning'?50+50*(leg?.progress??0)/Math.max(1,leg?.total??1):50*(leg?.progress??0)/Math.max(1,leg?.total??1);
  return{type:AUTONOMY_TEST_JOB.type,active:this.active,phase:this.phase,label:PHASE_LABELS[this.phase],detail:this.notice||this.instruction,vehicleName:AUTONOMY_TEST_JOB.vehicleName,reward:AUTONOMY_TEST_JOB.reward,progress:this.phase==='completed'?100:Math.round(clamp(progress,0,100)),distance:Math.round(this.totalDistance??0),remaining:Math.ceil(Math.max(0,(leg?.total??0)-(leg?.progress??0))),checkpointsPassed:leg?.next??0,checkpoints:leg?.gates.length??0,automaticDistance:Math.floor(this.autoDistance??0),manualDistance:Math.floor(this.manualDistance??0),manualTakeover:!!this.takeoverConfirmed,manualBrake:!!this.manualBraked,canCancel:this.active,paid:this.paid,simulator:true};
 }
 get instruction(){
  if(this.phase==='outbound')return '开启 Pilot，沿指定道路完成至少 60 米自动驾驶；随后有模拟接管测试。';
  if(this.phase==='takeover')return this.takeoverConfirmed?'手动沿导航驶入测试停车点，使用脚刹停稳 1 秒。':'游戏演练：模拟感知降级。按方向/刹车接管，在前方停车点手动刹停；真实 AEB 保持工作。';
  if(this.phase==='returning')return '沿导航返回公司交车点，停稳 1 秒领取报酬。可手动驾驶或使用 Pilot。';
  if(this.phase==='stopping')return '工作车正在制动，停稳且车门旁安全后归还车辆。';
  return PHASE_LABELS[this.phase];
 }
 result(ok,reason=''){return{ok,reason,phase:this.phase};}
 change(phase,notice=''){this.phase=phase;this.notice=notice;this.options.onChange?.(this.status);this.g.ui?.updateMission?.();this.g.ui?.updatePilot?.();}
 notify(text){this.g.ui?.toast?.(text);}
 route(from,to,yaw){
  try{const route=this.planner(from,to,[],yaw);if(!Array.isArray(route)||!route.length||route.length>256||route.some(p=>!finite(p))||distance(route.at(-1),to)>1)return null;
   // The assignment must consist of connected public-road segments. In
   // particular, a straight shortcut across blocks cannot become a job route.
   let previous=from;for(const p of route){const length=distance(previous,p);for(let n=0;n<=Math.ceil(length/4);n++){const t=n/Math.max(1,Math.ceil(length/4)),q={x:previous.x+(p.x-previous.x)*t,z:previous.z+(p.z-previous.z)*t},r=nearestRoad(q),vertical=Math.abs(q.x-r.x)<Math.abs(q.z-r.z);if(Math.min(Math.abs(q.x-r.x),Math.abs(q.z-r.z))>11)return null;const a=vertical?{x:r.x,z:Math.floor(q.z/80)*80}:{x:Math.floor(q.x/80)*80,z:r.z},b=vertical?{x:a.x,z:a.z+80}:{x:a.x+80,z:a.z};if(!roadEdgeAllowed(a,b))return null;}previous=p;}
   return route.map(point);
  }catch{return null;}
 }
 routeClearOfParkedVehicles(from,route,target){
  const g=this.g,parked=[...new Set([g.vehicle,g.personalVehicle,...(g.traffic??[]),...(g.police??[])])]
   .filter(v=>v&&!v.populationDormant&&v.root?.visible!==false&&(v===g.vehicle||v.parked||Math.abs(v.speed??0)<.5))
   .map(v=>{const b=getVehicleCollider(v);const halfWidth=b.halfWidth+.45,halfLength=b.halfLength+.45;return{...b,halfWidth,halfLength,radius:Math.hypot(halfWidth,halfLength)};});
  if(!parked.length)return true;
  // Use the same smoothed path Pilot will follow. A safe spawn by itself does
  // not guarantee a safe lane merge past the car the player just parked.
  const path=makeLeg(from,route,target).path;let previous=from;
  for(const end of path){const length=distance(previous,end);if(length<1e-6)continue;const yaw=yawTo(previous,end),steps=Math.max(1,Math.ceil(length/.75));
   for(let i=0;i<=steps;i++){const t=i/steps,pos={x:previous.x+(end.x-previous.x)*t,z:previous.z+(end.z-previous.z)*t},body=getVehicleCollider({pos,yaw,halfWidth:1.3,halfLength:3.2});
    if(parked.some(other=>Math.hypot(other.x-body.x,other.z-body.z)<other.halfLength+other.halfWidth+5&&boxContact(body,other)))return false;
   }previous=end;
  }
  return true;
 }
 clearAt(p){
  if(!finite(p)||isRoadIntersection(p,21))return false;
  const proxy={pos:p,yaw:p.yaw,halfWidth:1.3,halfLength:3.2},body=getVehicleCollider(proxy),g=this.g;
  if((g.world?.colliders??[]).some(b=>boxContact(body,getVehicleCollider({pos:b,yaw:b.yaw??0,halfWidth:b.w+.5,halfLength:b.d+.5}))))return false;
  if([...new Set([g.vehicle,g.personalVehicle,...(g.traffic??[]),...(g.police??[])])].some(v=>v&&!v.populationDormant&&distance(v.pos,p)<10))return false;
  if((g.pedestrians??[]).some(a=>a.root?.visible!==false&&distance(a.root.position,p)<5))return false;
  return !!safeVehicleExit(g,proxy);
 }
 assignment(){
  const g=this.g,origin=g.position??g.playerPos??g.vehicle.pos;
  for(const side of [1,-1]){
   const anchor=taxiStop(origin,side);if(!anchor)continue;
   for(const offset of [14,-14,26,-26,38,-38,52,-52]){
    const start={...anchor,x:anchor.x-Math.sin(anchor.yaw)*offset,z:anchor.z-Math.cos(anchor.yaw)*offset};
    if(distance(start,origin)>75||!this.clearAt(start))continue;
    for(const turn of [1,-1]){
     const raw={x:start.x-Math.sin(start.yaw)*240+Math.cos(start.yaw)*160*turn,z:start.z-Math.cos(start.yaw)*240-Math.sin(start.yaw)*160*turn},stop=taxiStop(raw);
     if(!stop||!finite(stop)||isRoadIntersection(stop,20))continue;
     const target={...stop,name:'模拟接管 · 测试停车点'},outbound=this.route(start,target,start.yaw);
     if(!outbound||routeLength(start,outbound)<200||routeLength(start,outbound)>1800||!this.routeClearOfParkedVehicles(start,outbound,target))continue;
     const endYaw=yawTo(outbound.at(-2)??start,target),depot={...start,name:'公司交车点'},back=this.route(target,depot,endYaw);
     if(back&&routeLength(target,back)>=120&&routeLength(target,back)<=1800&&this.routeClearOfParkedVehicles(target,back,depot))return{start,target,depot,outbound,back};
    }
   }
  }
  return null;
 }
 start(){
  const g=this.g;
  if(this.active||g.job)return this.result(false,'请先完成或取消当前工作');
  if(g.flight?.active||g.aircraft?.active||g.robotaxi?.active||g.robotaxi?.passenger||g.transition)return this.result(false,'请先结束乘车或飞行行程');
  if(!g.vehicle||Math.abs(g.vehicle.speed??0)>.35)return this.result(false,'请先将当前车辆停稳，再领取工作车');
  const plan=this.assignment();if(!plan)return this.result(false,'附近没有安全、连通的路测路线，请移到其他公共道路旁');
  const original=g.vehicle,context={destination:g.destination?{...g.destination}:null,route:(g.route??[]).map(p=>({...p})),routeIndex:g.routeIndex??0,blockedRoads:(g.blockedRoads??[]).map(p=>({...p})),personalVehicle:g.personalVehicle??null,parked:original.parked,protected:original.populationProtected,inTraffic:(g.traffic??[]).includes(original),rootVisible:original.root?.visible,inCar:g.inCar,player:point(g.playerPos??original.pos),playerYaw:g.playerYaw};
  // simple=true and isGarageVehicle=false prevent same-model saved damage,
  // battery or fault state from being restored into the temporary fleet car.
  let work;
  try{work=g.makeVehicle(AUTONOMY_TEST_JOB.modelId,plan.start.x,plan.start.z,plan.start.yaw,true,0x8de0d1,{isGarageVehicle:false});g.promoteVehicle?.(work);}catch(error){if(work)this.remove(work);return this.result(false,'工作车暂时无法准备，请稍后重试');}
  Object.assign(work,{isGarageVehicle:false,isAutonomyWorkCar:true,populationProtected:true,populationDormant:false,parked:false,condition:100,battery:100});
  work.root.userData.autonomyWorkCar=true;work.root.name='VOLT · 自动驾驶测试工作车';
  g.rememberBrakeFault?.();this.context=context;this.originalVehicle=original;this.workVehicle=work;this.plan=plan;this.paid=false;this.autoDistance=0;this.manualDistance=0;this.totalDistance=0;this.takeoverConfirmed=false;this.manualBraked=false;this.stopHold=0;this.offRouteTime=0;this.outcome=null;this.cancelReason='';this.outboundPassed=false;this.returnPassed=false;
  original.parked=true;original.populationProtected=true;if(!context.inTraffic)g.traffic.push(original);g.personalVehicle=original;setVehicleInteriorView(original,false);g.vehicle=work;g.nearestCar=work;g.inCar=true;g.autopilot=false;g.resetControls?.();g.pilot?.reset?.();g.sensor?.reset?.();g.assistTelemetry=null;if(g.person?.root)g.person.root.visible=false;if(g.gun)g.gun.visible=false;resetVehiclePose(work);
  g.job={...AUTONOMY_TEST_JOB,stage:0,stages:[{...plan.target,name:'Pilot 自动驾驶路测'},{...plan.target},{...plan.depot}],started:g.time??0,hold:0};
  this.setLeg(plan.outbound,plan.target);this.last={...point(work.pos),speed:work.speed??0};this.change('outbound');g.ui?.closePhone?.();g.ui?.closeModal?.();g.ui?.updateAll?.();this.notify('已领取 VOLT 路测工作车 · 开启 Pilot 开始测试');g.save?.(false);return this.result(true);
 }
 setLeg(route,target){
  const g=this.g;this.leg=makeLeg(this.workVehicle.pos,route,target);this.stopHold=0;this.offRouteTime=0;g.destination={...target};g.route=route.map(point);g.routeIndex=0;g.pilot?.setRoute?.(g.route);g.updateRoutePresentation?.(true);g.ui?.updateMission?.();
 }
 noteManualTakeover(){
  if(this.phase!=='takeover'||this.g.vehicle!==this.workVehicle||!this.g.inCar||Math.abs(this.workVehicle.speed)<.75)return false;
  this.takeoverConfirmed=true;this.notice='已记录手动接管 · 继续手动行驶至少 8 米，再用脚刹在测试点停稳';this.g.ui?.updateMission?.();return true;
 }
 filterControls(input){return this.active&&this.phase==='stopping'?{...HOLD}:input;}
 cancel(reason='已取消路测工作'){if(!this.active)return this.result(false,'没有正在进行的路测工作');this.beginStop('cancelled',reason);if(Math.abs(this.workVehicle?.speed??0)<.25)this.finish();return this.result(true);}
 beginStop(outcome,reason){if(this.phase==='stopping')return;this.outcome=outcome;this.cancelReason=reason;this.g.autopilot=false;this.g.pilot?.reset?.();this.g.resetControls?.();this.change('stopping',reason+' · 停稳后归还工作车');this.notify(this.notice);}
 fail(reason){this.beginStop('failed',reason);}
 update(dt,input={}){
  if(!this.active||!this.workVehicle)return;
  const g=this.g,v=this.workVehicle;
  if(g.vehicle!==v||!g.inCar){this.fail('已离开工作车，路测作废');this.reset('failed');return;}
  if(this.phase==='stopping'){if(Math.abs(v.speed)<.25)this.finish();return;}
  if(!Number.isFinite(dt)||dt<=0||dt>.25)return;
  const previous=this.last,current={...point(v.pos),speed:v.speed},moved=distance(previous,current);this.last=current;
  const speed=Math.max(Math.abs(previous.speed??0),Math.abs(v.speed??0)),maxMovement=Math.min(120,speed+2)*dt+.22;
  if(!finite(current)||!Number.isFinite(v.speed)||moved>maxMovement){this.fail('检测到非连续移动，测试无效');return;}
  if(v.condition<=0){this.fail('工作车已损坏，测试结束');return;}
  const leg=this.leg;let onRoute=Infinity;
  for(let i=0;i<leg.path.length-1;i++)onRoute=Math.min(onRoute,segmentDistance(current,leg.path[i],leg.path[i+1]));
  this.offRouteTime=onRoute>12?this.offRouteTime+dt:0;
  if(this.offRouteTime>3){this.fail('持续偏离指定道路，测试无效');return;}
  if(onRoute>12){this.stopHold=0;return;}
  if(moved>.001){
   leg.travel+=moved;this.totalDistance+=moved;
   // Consume gates strictly in order and only when the physical movement
   // segment passes them. A button, timer, remote endpoint or loop cannot
   // advance route progress. A corner missed on this leg must be revisited.
   while(leg.next<leg.gates.length&&segmentDistance(leg.gates[leg.next],previous,current)<(leg.next===leg.gates.length-1?4:5.2)){
    const gate=leg.gates[leg.next];if(gate.s>leg.travel+7)break;leg.progress=gate.s;leg.next++;
   }
   if(g.autopilot&&this.phase==='outbound')this.autoDistance+=moved;
   if(!g.autopilot&&this.phase==='takeover'&&this.takeoverConfirmed)this.manualDistance+=moved;
  }
  if(this.phase==='outbound'&&leg.total-leg.progress<=75){
   if(this.autoDistance<AUTO_METRES){this.fail('本次未完成 60 米 Pilot 自动驾驶，请重新接单');return;}
   g.job.stage=1;this.change('takeover');this.notify(this.instruction);
  }
  const pedalRequest=Number(input.brake)>.15||(Number(input.throttle)<-.15&&previous.speed>1.2);
  const manualBrake=!g.autopilot&&this.takeoverConfirmed&&input.brakeSource!=='pilot'&&input.brakeSource!=='aeb'&&pedalRequest;
  if(this.phase==='takeover'&&manualBrake&&Math.abs(v.speed)>.35)this.manualBraked=true;
  const atEnd=leg.next===leg.gates.length&&distance(v.pos,leg.target)<5&&Math.abs(v.speed)<.35;
  const qualifies=this.phase==='returning'||(this.phase==='takeover'&&this.takeoverConfirmed&&this.manualBraked&&this.manualDistance>=MANUAL_METRES&&this.autoDistance>=AUTO_METRES&&!g.autopilot);
  this.stopHold=atEnd&&qualifies?this.stopHold+dt:0;
  if(this.stopHold<STOP_SECONDS)return;
  if(this.phase==='takeover'){
   const back=this.route(v.pos,this.plan.depot,v.yaw);if(!back){this.fail('交车路线暂时不可用，本次没有结算');return;}
   this.outboundPassed=true;g.job.stage=2;g.autopilot=false;g.resetControls?.();this.setLeg(back,this.plan.depot);this.last={...point(v.pos),speed:v.speed};this.change('returning');this.notify('接管测试通过 · 沿导航返回交车，停稳后结算');
  }else if(this.phase==='returning'){
   this.returnPassed=true;this.beginStop('completed','全部测试通过');this.finish();
  }
 }
 restoreNavigation(){
  const g=this.g,c=this.context;g.destination=c.destination?{...c.destination}:null;g.route=c.route.map(p=>({...p}));g.routeIndex=c.routeIndex;g.blockedRoads=c.blockedRoads.map(p=>({...p}));
  // A local exit can be far from the parked personal car. Re-plan the saved
  // personal destination from the avatar, rather than present a stale origin.
  if(g.destination)g.replan?.();else g.updateRoutePresentation?.(true);
 }
 finish({force=false,phase=null}={}){
  if(!this.originalVehicle||!this.workVehicle)return false;
  const g=this.g,v=this.workVehicle,original=this.originalVehicle,c=this.context;
  if(!force&&Math.abs(v.speed)>.25)return false;
  const exit=safeVehicleExit(g,v);
  if(!exit&&!force){this.notice='车门旁空间不足 · 请等待安全下车位置';return false;}
  const save=this.saveContext(),outcome=phase??this.outcome??'cancelled',eligible=outcome==='completed'&&this.outboundPassed&&this.returnPassed&&!this.paid;
  setVehicleInteriorView(v,false);g.vehicle=original;g.personalVehicle=c.personalVehicle;g.nearestCar=original;g.inCar=false;g.autopilot=false;original.parked=c.parked;original.populationProtected=c.protected;if(original.root)original.root.visible=c.rootVisible??true;if(!c.inTraffic)g.traffic=g.traffic.filter(car=>car!==original);
  g.playerPos.copy(exit?.worldPosition??save.player);g.playerYaw=v.yaw;g.playerPos.y=g.walkingHeight?.(g.playerPos.x,g.playerPos.z)??groundHeight(g.playerPos.x,g.playerPos.z)+.012;
  if(g.person?.root){g.person.root.position.copy(g.playerPos);g.person.root.rotation.set(0,g.playerYaw,0);g.person.root.visible=true;g.person.root.scale.setScalar(1);}
  g.resetControls?.();g.pilot?.reset?.();g.sensor?.reset?.();g.assistTelemetry=null;if(g.job?.type===AUTONOMY_TEST_JOB.type)g.job=null;this.restoreNavigation();this.remove(v);this.workVehicle=null;this.originalVehicle=null;this.context=null;
  this.change(outcome,this.cancelReason);if(eligible){this.paid=true;g.addMoney?.(AUTONOMY_TEST_JOB.reward,AUTONOMY_TEST_JOB.title+'报酬');g.jobsCompleted=(g.jobsCompleted??0)+1;this.notify('路测完成！+$'+AUTONOMY_TEST_JOB.reward.toLocaleString()+' · 工作车已归还');}
  else if(!force)this.notify(this.cancelReason+' · 工作车已归还，个人导航已恢复');
  g.ui?.updateAll?.();if(!force)g.save?.(false);return true;
 }
 saveContext(){
  if(!this.originalVehicle)return null;
  const g=this.g,exit=safeVehicleExit(g,this.workVehicle),originalExit=!exit?safeVehicleExit(g,this.originalVehicle):null;
  return{vehicle:this.originalVehicle,inCar:false,player:point(exit?.worldPosition??originalExit?.worldPosition??this.context.player),playerYaw:this.workVehicle.yaw,destination:this.context.destination?{...this.context.destination}:null,job:null};
 }
 remove(vehicle){if(this.g.removeVehicle){this.g.removeVehicle(vehicle);return;}disposeVehicleInstruments(vehicle);disposeVehicleDamage(vehicle);this.g.scene?.remove?.(vehicle.root);this.g.traffic=(this.g.traffic??[]).filter(v=>v!==vehicle);this.g._trafficSpatialIndex=null;}
 reset(phase='idle'){
  // Load/respawn never settle an unfinished contract and never serialize the
  // company car. No accrued stage or reward token survives a reload.
  if(this.originalVehicle){this.outcome='cancelled';this.finish({force:true,phase});}
  else if(this.workVehicle){this.remove(this.workVehicle);this.workVehicle=null;}
  this.outboundPassed=false;this.returnPassed=false;this.leg=null;this.change(phase);
 }
}
