import * as THREE from './vendor/three.module.js';
import {createG9DisplayTexture} from './g9-displays.js';
import {G9_MATERIALS} from './assets/g9/g9-materials.js';
import {g9AssetData} from './g9-asset.js';

// Reference-inspired original Blender model. Numbers below tune gameplay; they
// are not manufacturer performance claims. Stable ID is used by owned-car saves.
export const G9_MODEL=Object.freeze({
  id:'g9',brand:'xiangjie',name:'享界 G9',trim:'WILDERNESS LUXURY · 2+3',category:'豪华越野',
  desc:'硬派豪华 SUV · 方正车身、双圆环灯、尾门储物箱与三联屏座舱',
  price:128000,power:14.8,max:47,range:520,color:0x17483e,mass:2944,tireGrip:9.3,
  reference:'https://hima.auto/xiangjie/g9/',previewImage:new URL('./assets/g9/preview.jpg',import.meta.url).href
});
export const G9_COLLISION_BOUNDS=Object.freeze({minX:-1.2875,maxX:1.2875,minY:0,maxY:1.963,minZ:-2.7065,maxZ:2.838});
export function g9DetailLevel(simple=false,deviceMemory=globalThis.navigator?.deviceMemory){return simple||(Number.isFinite(deviceMemory)&&deviceMemory<=4)?'simple':'detailed';}
const geometryCache=new Map(),materialCache=new Map();
function unpack(encoded,kind,scale=1){
 const bytes=Uint8Array.from(atob(encoded),c=>c.charCodeAt(0)),view=new DataView(bytes.buffer);
 const count=bytes.length/2,result=kind==='index'?new Uint16Array(count):new Float32Array(count);
 for(let i=0;i<count;i++)result[i]=(kind==='index'?view.getUint16(i*2,true):view.getInt16(i*2,true))/scale;
 return result;
}
function geometry(detail,index,source){
 const key=detail+':'+index;
 if(!geometryCache.has(key)){
  const g=new THREE.BufferGeometry();
  g.setAttribute('position',new THREE.BufferAttribute(unpack(source.p,'position',10000),3));
  g.setAttribute('normal',new THREE.BufferAttribute(unpack(source.n,'normal',32767),3));
  g.setIndex(new THREE.BufferAttribute(unpack(source.i,'index'),1));g.computeBoundingBox();g.computeBoundingSphere();
  if(source.material.startsWith('display_')){
   // Shared live instruments bind flipY=false; static G9 canvases use the same UV convention.
   const p=g.attributes.position,uv=new Float32Array(p.count*2),b=g.boundingBox;
   for(let j=0;j<p.count;j++){uv[j*2]=(p.getX(j)-b.min.x)/(b.max.x-b.min.x);uv[j*2+1]=1-(p.getY(j)-b.min.y)/(b.max.y-b.min.y);}
   g.setAttribute('uv',new THREE.BufferAttribute(uv,2));
  }
  geometryCache.set(key,g);
 }
 return geometryCache.get(key);
}
function material(name,color,detail){
 const key=name+':'+(name==='paint'?color:'shared')+(name.startsWith('display_')?':'+(typeof document==='undefined'?'headless':'canvas')+':'+detail:'');
 if(!materialCache.has(key)){
  const p={...G9_MATERIALS[name],side:THREE.DoubleSide};
  const displayKind=p.displayKind;delete p.displayKind;
  if(name==='paint')p.color=color;
  const displayTexture=displayKind?createG9DisplayTexture(displayKind,detail==='simple'):null;
  const m=displayKind?new THREE.MeshBasicMaterial({map:displayTexture,color:displayTexture?0xffffff:0x10262b,toneMapped:false,side:THREE.DoubleSide}):new THREE.MeshPhysicalMaterial(p);m.name=name==='paint'?'Paint 1 G9':`G9 ${name}`;
  // Do not cache a failed canvas allocation: a later car can retry successfully.
  if(!displayKind||displayTexture||typeof document==='undefined')materialCache.set(key,m);
  else return m;
 }
 return materialCache.get(key);
}
export function createG9Car(simple=false,colorOverride=null,model=G9_MODEL){
 const source=g9AssetData();if(!source)return null;
 const detail=g9DetailLevel(simple),data=source[detail],nodes=new Map(),surfaces={};
 for(const n of data.nodes){const group=new THREE.Group();group.name=n.name;group.position.fromArray(n.position);nodes.set(n.name,group);if(n.parent)nodes.get(n.parent).add(group);}
 for(const [index,s]of data.meshes.entries()){
  const mesh=new THREE.Mesh(geometry(detail,index,s),material(s.material,colorOverride??model.color,detail));
  mesh.name=`g9-${s.part}-${s.parent}-${s.material}`;mesh.userData.semantic=3;
  if(s.material.startsWith('display_')){const role={display_cluster:'cluster',display_map:'center',display_media:'passenger'}[s.material];surfaces[role]=mesh;mesh.userData.displayAnchor=role;mesh.userData.infotainmentProfile='xiangjie-g9';}
  mesh.castShadow=!s.material.includes('glass');mesh.receiveShadow=true;nodes.get(s.parent).add(mesh);
 }
 const root=nodes.get('G9'),chassis=nodes.get('chassis');
 root.userData.model=model.id;root.userData.design='blender-reference-g9-2026';root.userData.bodyStyle='offroad';root.userData.detail=detail;
 root.userData.cabin={rows:2,seats:5,layout:'2+3',seatRows:[-.22,1.02],roofHeight:1.897,theme:'olive-gray-panoramic-three-screen'};
 root.userData.reference=G9_MODEL.reference;
 const wheels=[['FL',-1,true],['RL',-1,false],['FR',1,true],['RR',1,false]].map(([name,side,front])=>({pivot:nodes.get('wheel_'+name),spin:nodes.get('spin_'+name),side,front,radius:.42}));
 const doors=[{pivot:nodes.get('door_L'),side:-1},{pivot:nodes.get('door_R'),side:1}];
 return{root,chassis,wheels,doors,model,steeringWheel:nodes.get('steering'),
  collisionBounds:{...G9_COLLISION_BOUNDS},
  // Live instruments replace the authored surface, never a floating extra panel.
  instrumentMesh:surfaces.cluster,infotainmentProfile:'xiangjie-g9',infotainmentSurfaces:surfaces,
  assetQualityNote:!simple&&detail==='simple'?'低内存精简细节':null,
  wheelBase:3.16,rearAxle:1.59,track:1.78,maxSteer:.57,lateralGrip:model.tireGrip,
  driverCamera:new THREE.Vector3(-.47,1.55,-.15),driverPosition:new THREE.Vector3(-.47,.38,-.22),
  exitPosition:new THREE.Vector3(-1.93,0,-.25),instrumentPosition:new THREE.Vector3(-.51,1.23,-.948),instrumentSize:[.43,.214],instrumentTilt:0,
  pedalMount:new THREE.Vector3(-.47,.43,-.96),height:1.97,halfWidth:1.025,
  dimensions:{length:5.54,width:2.05,height:1.97},entryOpening:{front:-1.31,rear:.14,sill:.35,roof:1.897},
  mass:model.mass,driverViewPitch:.12,driverFov:66,asset:'Original Blender geometry / Xiangjie G9 reference'
 };
}
