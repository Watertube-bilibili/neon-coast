// Fictional Y9 gameplay easter egg. Not a simulation or claim about any real car.
// Only sustained, sharp, rapid alternating turns at road speed build stress.
export const Y9_AXLE=Object.freeze({model:'y9',minSpeed:14,sharpInput:.32,minLateral:2.2,hold:.12,window:1.15,perReversal:.24,cooling:.035,limpSpeed:3,powerScale:.18,drag:1.6});
const HEALTHY_AXLE=Object.freeze({broken:false,side:0,powerScale:1,maxSpeed:Infinity,drag:0,steeringScale:1});
export function createAxleFault(){return{broken:false,stress:0,side:0,lastSign:0,candidateSign:0,holdTime:0,sinceTurn:0,justBroke:false,justWarned:false};}
export function isValidAxleFaultSave(f){
 return !!f&&typeof f==='object'&&!Array.isArray(f)&&typeof f.broken==='boolean'
  &&Number.isFinite(f.stress)&&f.stress>=0&&f.stress<=1
  &&[-1,0,1].includes(f.side)&&[-1,0,1].includes(f.lastSign)&&[-1,0,1].includes(f.candidateSign)
  &&Number.isFinite(f.holdTime)&&f.holdTime>=0&&f.holdTime<=Y9_AXLE.hold
  &&Number.isFinite(f.sinceTurn)&&f.sinceTurn>=0&&f.sinceTurn<=Y9_AXLE.window
  &&(f.broken?(f.side!==0&&f.stress===1):(f.side===0&&f.stress<1));
}
export function restoreAxleFault(saved){return isValidAxleFaultSave(saved)?{...createAxleFault(),...saved,justBroke:false,justWarned:false}:createAxleFault();}
export function serializeAxleFault(v){
 if(v.model.id!==Y9_AXLE.model)return undefined;
 const {broken,stress,side,lastSign,candidateSign,holdTime,sinceTurn}=v.axleFault??=createAxleFault();
 return{broken,stress,side,lastSign,candidateSign,holdTime,sinceTurn};
}
export function axleFaultEffects(v){
 return v.model.id===Y9_AXLE.model&&v.axleFault?.broken
  ?{broken:true,side:v.axleFault.side,powerScale:Y9_AXLE.powerScale,maxSpeed:Y9_AXLE.limpSpeed,drag:Y9_AXLE.drag,steeringScale:.45}
  :HEALTHY_AXLE;
}
export function stepAxleFault(v,input,dt){
 if(v.model.id!==Y9_AXLE.model)return;
 const f=v.axleFault??=createAxleFault();f.justBroke=false;f.justWarned=false;
 if(f.broken||!Number.isFinite(dt)||dt<=0)return;
 dt=Math.min(dt,.1);
 const oldStress=f.stress;
 f.sinceTurn=Math.min(Y9_AXLE.window,f.sinceTurn+dt);
 f.stress=Math.max(0,f.stress-Y9_AXLE.cooling*dt);
 if(f.sinceTurn>=Y9_AXLE.window){f.stress=0;f.lastSign=0;}
 const command=Number.isFinite(input.steer)?input.steer:0;
 const lateral=Math.abs(v.speed*v.speed*Math.tan(v.steer??0)/Math.max(1,v.wheelBase));
 const sign=Math.sign(command);
 const qualifies=Math.abs(v.speed)>=Y9_AXLE.minSpeed&&Math.abs(command)>=Y9_AXLE.sharpInput
  &&v.grounded!==false&&lateral>=Y9_AXLE.minLateral&&Math.sign(v.steer)===sign;
 if(!qualifies){f.candidateSign=0;f.holdTime=0;return;}
 if(sign!==f.candidateSign){f.candidateSign=sign;f.holdTime=0;}
 f.holdTime=Math.min(Y9_AXLE.hold,f.holdTime+dt);
 if(f.holdTime+1e-9<Y9_AXLE.hold||sign===f.lastSign)return;
 if(f.lastSign===-sign)f.stress=Math.min(1,f.stress+Y9_AXLE.perReversal);
 f.lastSign=sign;f.sinceTurn=0;
 f.justWarned=oldStress<.5&&f.stress>=.5;
 if(f.stress>=1){f.broken=true;f.side=sign>0?1:-1;f.justBroke=true;}
}
export function updateAxleFaultVisuals(v){
 if(v.model.id!==Y9_AXLE.model)return;
 const fault=axleFaultEffects(v);
 for(const w of v.wheels??[]){
  // Only object transforms change. Cached geometry/materials remain pristine.
  w.axleRestPosition??=w.pivot.position.clone();
  w.pivot.position.copy(w.axleRestPosition);w.pivot.rotation.z=0;w.axleToeOffset=0;
  if(fault.broken&&w.front&&w.side===fault.side){
   w.axleToeOffset=w.side*.24;w.pivot.rotation.y+=w.axleToeOffset;w.pivot.rotation.z=w.side*.42;
   w.pivot.position.x+=w.side*.09;w.pivot.position.y+=.055;
  }
 }
 if(fault.broken)v.chassis.rotation.z+=fault.side*.025;
}
export function repairAxleFault(v){
 v.axleFault=createAxleFault();if(v.model.id===Y9_AXLE.model&&v.chassis)v.chassis.rotation.z=v.bodyRoll??0;
 for(const w of v.wheels??[]){if(w.axleRestPosition)w.pivot.position.copy(w.axleRestPosition);w.pivot.rotation.y-=w.axleToeOffset??0;w.axleToeOffset=0;w.pivot.rotation.z=0;}
}
