import {activeRouteView} from './route-view.js';
import {updateAssistStatus} from './assist-status.js';
import {FOLLOW_GAP_PRESETS} from './assist-settings.js';
import * as THREE from './vendor/three.module.js';
import {createVehicleEnvironment} from './vehicle-environment.js';
import {createCar} from './world.js';

const clamp = THREE.MathUtils.clamp;
const svg = (body) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${body}</svg>`;
const ICON = {
  wheel: svg('<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="2.2"/><path d="m4 8 6 3m10-3-6 3m-2 3v7"/>'),
  screen: svg('<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8m-4-4v4m-4-8 4-2 4 2"/>'),
  camera: svg('<rect x="3" y="6" width="14" height="13" rx="2"/><path d="m17 10 4-3v11l-4-3M7 3h6"/>'),
  nav: svg('<path d="m12 3 8 18-8-5-8 5 8-18Z"/>'),
  close: svg('<path d="m6 6 12 12M6 18 18 6"/>'),
  reset: svg('<path d="M4 11a8 8 0 1 1 2.3 6.6M4 4v7h7"/>'),
  expand: svg('<path d="M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5"/>'),
  battery: svg('<rect x="2" y="7" width="18" height="10" rx="2"/><path d="M22 10v4M5 10v4m4-4v4m4-4v4m4-4v4"/>'),
};

/** A separate, small WebGL display. Obstacles only come from camera detections. */
export class VehicleCockpit {
  constructor(game) {
    this.g = game;
    this._open = false;
    this.slots = [];
    this.models = new Map();
    this.lastSensorFrame = -1;
    this.frameElapsed = 0;
    this.motionElapsed = 0;
    this.hudElapsed = 1;
    this.ownedResources = [];
    this.panel = document.createElement('section');
    this.panel.id = 'vehicle-cockpit';
    this.panel.className = 'vehicle-cockpit';
    this.panel.setAttribute('aria-label', 'VOLT 车机与驾驶可视化');
    this.panel.hidden = true;
    this.panel.innerHTML = `
      <header class="vc-header"><div class="vc-brand" role="button" tabindex="0" aria-label="移动车机，使用方向键调整，Shift 加方向键快速移动，Home 重置" title="拖动标题栏移动 · 方向键调整 · Home 重置"><span class="vc-volt">Ⅴ</span><strong>VOLT<span>OS</span></strong><i></i><span class="vc-model">VOLT S</span></div><div class="vc-header-actions"><span class="vc-clock">18:42</span><button class="vc-reset" type="button" aria-label="重置车机位置" title="重置车机位置">${ICON.reset}</button><button class="vc-expand" type="button" aria-label="展开车机" title="展开车机">${ICON.expand}</button><button class="vc-close" type="button" aria-label="关闭车机" title="收起车机 · U">${ICON.close}</button></div></header>
      <div class="vc-body"><aside class="vc-instruments"><div class="vc-gear">P <span>R N D</span></div><strong class="vc-speed">0</strong><span class="vc-unit">KM/H</span><div class="vc-wheel">${ICON.wheel}</div><div class="vc-energy">${ICON.battery}<span>98%</span></div><span class="vc-range">412 km</span></aside><div class="vc-visual"><div class="vc-navigation"><span class="vc-nav-icon">${ICON.nav}</span><div><strong class="vc-destination">自由驾驶</strong><span class="vc-distance">选择目的地，探索城市</span></div></div><div class="vc-webgl" aria-label="来自车载摄像头检测的三维车辆和行人"></div><div class="vc-scene-label"><span class="vc-perception-dot"></span><span class="vc-scene-state">等待车载摄像头</span><span class="vc-count">0 辆 · 0 人</span></div><div class="vc-warning" hidden></div><span class="vc-offline" hidden>请进入车辆</span></div></div>
      <footer class="vc-footer"><button class="vc-pilot" type="button" aria-label="切换 VOLT Pilot 辅助驾驶">${ICON.wheel}<span>VOLT Pilot</span><i></i></button><button class="vc-camera" type="button" aria-label="开关车载摄像头画面">${ICON.camera}<span>摄像头</span></button><button class="vc-nav" type="button" aria-label="选择导航目的地">${ICON.nav}<span>导航</span></button><button class="vc-settings" type="button" aria-label="设置巡航速度、跟车距离与 AEB">⚙<span>设置</span></button><span class="vc-signal">路面 <b>—</b></span></footer>`;
    document.body.append(this.panel);
    this.nodes = Object.fromEntries([...this.panel.querySelectorAll('[class]')].map(el => [el.classList[0], el]));
    this.launcher = document.createElement('button');
    this.launcher.type = 'button';
    this.launcher.id = 'cockpit-btn';
    this.launcher.className = 'tool-button';
    this.launcher.title = 'VOLT 车机 · U';
    this.launcher.setAttribute('aria-controls', 'vehicle-cockpit');
    this.launcher.innerHTML = `<span class="tool-icon">${ICON.screen}</span><span>车机</span><kbd>U</kbd>`;
    (document.querySelector('.right-tools') ?? document.body).append(this.launcher);
    this.launcher.onclick = () => this.toggle();
    this.nodes['vc-close'].onclick = () => this.close();
    this.nodes['vc-reset'].onclick = () => this.resetPosition();
    this.setupPositioning();
    this.nodes['vc-expand'].onclick = () => {
      this.panel.classList.toggle('vc-expanded');
      const expanded = this.panel.classList.contains('vc-expanded');
      this.nodes['vc-expand'].setAttribute('aria-label', expanded ? '缩小车机' : '展开车机');
      this.nodes['vc-expand'].title = expanded ? '缩小车机' : '展开车机';
      this.resize();
    };
    this.nodes['vc-pilot'].onclick = () => { game.toggleAutopilot(); this.updateHUD(); };
    this.nodes['vc-nav'].onclick = () => game.ui.openPhone('nav');
    this.nodes['vc-settings'].onclick = () => game.ui.openAssistSettings();
    this.nodes['vc-camera'].onclick = () => {
      const panel = document.getElementById('sensor-panel');
      if (!panel) return;
      game.ui.previewSensor = panel.hidden;
      panel.hidden = !panel.hidden;
      this.updateHUD();
    };
    this.observer = new ResizeObserver(() => this.resize());
    this.observer.observe(this.nodes['vc-webgl']);
    let open = innerWidth >= 1100 && innerHeight >= 600;
    try { const pref = localStorage.getItem('neon-coast-cockpit-open'); if (pref !== null) open = pref === 'true'; } catch {}
    this.setOpen(open, false);
  }
  get isOpen() { return this._open; }
  get hasCustomPosition() { return !!this.panelPosition; }
  setupPositioning() {
    this.positionKey = 'neon-coast-cockpit-position';
    this.panelPosition = null;
    try {
      const saved = JSON.parse(localStorage.getItem(this.positionKey));
      if (saved?.version === 1 && Number.isFinite(saved.x) && Number.isFinite(saved.y)) {
        this.panelPosition = {x: clamp(saved.x, 0, 1), y: clamp(saved.y, 0, 1)};
      }
    } catch {}
    // The invisible rectangle resolves CSS safe-area insets to screen pixels.
    this.boundsProbe = document.createElement('div');
    this.boundsProbe.setAttribute('aria-hidden', 'true');
    this.boundsProbe.style.cssText = 'position:fixed;inset:max(8px,env(safe-area-inset-top,0px)) max(8px,env(safe-area-inset-right,0px)) max(8px,env(safe-area-inset-bottom,0px)) max(8px,env(safe-area-inset-left,0px));visibility:hidden;pointer-events:none;z-index:-1';
    document.body.append(this.boundsProbe);
    const header = this.nodes['vc-header'], handle = this.nodes['vc-brand'];
    const finish = e => {
      const drag = this.panelDrag;
      if (!drag || (e?.pointerId !== undefined && e.pointerId !== drag.id)) return;
      this.panelDrag = null;
      this.panel.classList.remove('vc-dragging');
      if (header.hasPointerCapture(drag.id)) header.releasePointerCapture(drag.id);
      if (drag.moved) this.savePosition();
    };
    this.finishDrag = finish;
    header.addEventListener('pointerdown', e => {
      if (!e.isPrimary || e.button !== 0 || e.target.closest('.vc-header-actions')) return;
      e.preventDefault();
      const rect = this.panel.getBoundingClientRect();
      this.panelDrag = {id: e.pointerId, x: e.clientX, y: e.clientY, left: rect.left, top: rect.top, moved: false};
      header.setPointerCapture(e.pointerId);
    });
    header.addEventListener('pointermove', e => {
      const drag = this.panelDrag;
      if (!drag || drag.id !== e.pointerId) return;
      const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
      if (!drag.moved && Math.hypot(dx, dy) < 5) return;
      e.preventDefault();
      drag.moved = true;
      this.panel.classList.add('vc-dragging');
      this.positionAt(drag.left + dx, drag.top + dy);
    });
    for (const event of ['pointerup', 'pointercancel', 'lostpointercapture']) header.addEventListener(event, finish);
    header.addEventListener('dblclick', e => {
      if (!e.target.closest('.vc-header-actions')) this.resetPosition();
    });
    handle.addEventListener('focus', () => this.g.resetControls?.());
    handle.addEventListener('keydown', e => {
      e.stopPropagation();
      const arrows = {ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1]};
      if (e.code === 'Home' || e.code === 'Enter' || e.code === 'Space') {
        e.preventDefault(); this.resetPosition(); return;
      }
      if (!arrows[e.code]) return;
      e.preventDefault();
      const step = e.shiftKey ? 40 : 10, rect = this.panel.getBoundingClientRect();
      this.positionAt(rect.left + arrows[e.code][0] * step, rect.top + arrows[e.code][1] * step);
      this.savePosition();
    });
    handle.addEventListener('keyup', e => { e.stopPropagation(); if (this.g.keys) this.g.keys[e.code] = false; });
    // Keyboard activation of panel buttons must not also drive or jump in-game.
    this.panel.addEventListener('keydown', e => {
      if (['Space', 'Enter', 'Tab', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(e.code)) e.stopPropagation();
    });
    window.addEventListener('blur', () => finish());
    document.addEventListener('visibilitychange', () => { if (document.hidden) finish(); });
    window.addEventListener('resize', () => { finish(); this.resize(); });
  }
  movementBounds() {
    const bounds = this.boundsProbe.getBoundingClientRect();
    const rect = this.panel.getBoundingClientRect();
    return {left: bounds.left, top: bounds.top, width: Math.max(0, bounds.width - rect.width), height: Math.max(0, bounds.height - rect.height)};
  }
  positionAt(left, top) {
    this.panel.classList.add('vc-positioned');
    const b = this.movementBounds();
    left = clamp(left, b.left, b.left + b.width);
    top = clamp(top, b.top, b.top + b.height);
    this.panelPosition = {x: b.width ? (left - b.left) / b.width : 0, y: b.height ? (top - b.top) / b.height : 0};
    this.panel.style.setProperty('--vc-left', `${left}px`);
    this.panel.style.setProperty('--vc-top', `${top}px`);
  }
  restorePosition() {
    if (!this.panelPosition || !this._open) return;
    this.panel.classList.add('vc-positioned');
    const b = this.movementBounds();
    this.panel.style.setProperty('--vc-left', `${b.left + b.width * this.panelPosition.x}px`);
    this.panel.style.setProperty('--vc-top', `${b.top + b.height * this.panelPosition.y}px`);
  }
  savePosition() {
    if (!this.panelPosition) return;
    try { localStorage.setItem(this.positionKey, JSON.stringify({version: 1, ...this.panelPosition})); } catch {}
  }
  resetPosition() {
    this.finishDrag?.();
    this.panelPosition = null;
    this.panel.classList.remove('vc-positioned');
    this.panel.style.removeProperty('--vc-left');
    this.panel.style.removeProperty('--vc-top');
    try { localStorage.removeItem(this.positionKey); } catch {}
    this.resize();
  }
  toggle() { this.setOpen(!this._open); }
  close() { this.setOpen(false); }
  setOpen(open, save = true) {
    if (!open) { this.finishDrag?.(); this.frameElapsed = 0; this.motionElapsed = 0; }
    this._open = !!open;
    this.panel.hidden = !this._open;
    document.body.classList.toggle('cockpit-open', this._open);
    this.launcher.classList.toggle('active', this._open);
    this.launcher.setAttribute('aria-expanded', String(this._open));
    if (save) try { localStorage.setItem('neon-coast-cockpit-open', String(this._open)); } catch {}
    if (this._open) {
      this.initScene();
      this.g.sensorClock = 1;
      this.lastSensorFrame = -1;
      this.updateHUD();
      this.resize();
      this.update(1 / 30);
    }
  }
  own(resource) { this.ownedResources.push(resource); return resource; }
  initScene() {
    if (this.renderer || this.failed) return;
    try {
      this.renderer = new THREE.WebGLRenderer({antialias: true, alpha: false, powerPreference: 'low-power'});
      this.renderer.setPixelRatio(Math.min(devicePixelRatio || 1, this.g.performanceProfile?.pixelRatio??1.5));
      this.renderer.setClearColor(0xf1f3f5);
      this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
      this.renderer.toneMappingExposure = 1.35;
      this.nodes['vc-webgl'].append(this.renderer.domElement);
      this.scene = new THREE.Scene();
      this.scene.environment = createVehicleEnvironment(this.renderer);
      this.scene.environmentIntensity = .75;
      this.scene.background = new THREE.Color(0xf1f3f5);
      this.scene.fog = new THREE.Fog(0xf1f3f5, 45, 100);
      this.camera = new THREE.PerspectiveCamera(38, 2, .1, 140);
      this.camera.position.set(5.5, 11.5, 13);
      this.camera.lookAt(0, 0, -7);
      this.scene.add(new THREE.HemisphereLight(0xffffff, 0xa3aab5, 3.1));
      const light = new THREE.DirectionalLight(0xffffff, 3.3);
      light.position.set(-13, 30, 16);
      this.scene.add(light);
      const fill = new THREE.DirectionalLight(0xdce6ff, 1.6);
      fill.position.set(13, 8, -20);
      this.scene.add(fill);
      this.roadGrid = new THREE.Group(); this.scene.add(this.roadGrid);
      this.roadMaterial = this.own(new THREE.MeshBasicMaterial({color: 0xe3e7ed, toneMapped: false}));
      this.roadGeometry = this.own(new THREE.BoxGeometry(22, .018, 240));
      this.lanes = new THREE.Group(); this.roadGrid.add(this.lanes);
      this.laneMaterial = this.own(new THREE.MeshBasicMaterial({color: 0x8494a6, transparent: true, opacity: .65, toneMapped: false}));
      this.dashGeometry = this.own(new THREE.BoxGeometry(.12, .015, 3.4));
      for (const axis of [0, 1]) for (const coordinate of [-80, 0, 80]) {
        const road = new THREE.Mesh(this.roadGeometry, this.roadMaterial);
        road.rotation.y = axis * Math.PI / 2;
        road.position.set(axis ? 0 : coordinate, -.025, axis ? coordinate : 0);
        this.roadGrid.add(road);
        for (let along = -117; along < 120; along += 6) {
          if (Math.abs(along - Math.round(along / 80) * 80) < 14) continue;
          for (const across of [0, -10, 10]) {
            const dash = new THREE.Mesh(this.dashGeometry, this.laneMaterial);
            dash.rotation.y = axis * Math.PI / 2;
            dash.position.set(axis ? along : coordinate + across, .018, axis ? coordinate + across : along);
            this.lanes.add(dash);
          }
        }
      }
      const laneInstances = new THREE.InstancedMesh(this.dashGeometry, this.laneMaterial, this.lanes.children.length);
      [...this.lanes.children].forEach((dash, i) => { dash.updateMatrix(); laneInstances.setMatrixAt(i, dash.matrix); this.lanes.remove(dash); });
      this.lanes.add(laneInstances);
      this.routeMaterial = this.own(new THREE.MeshBasicMaterial({color: 0x3685ff, transparent: true, opacity: .29, side: THREE.DoubleSide, depthWrite: false}));
      this.ribbonGeometry = this.own(new THREE.BufferGeometry());
      this.ribbonGeometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(49 * 2 * 3), 3).setUsage(THREE.DynamicDrawUsage));
      const indices = [];
      for (let i = 0; i < 48; i++) { const k = i * 2; indices.push(k, k + 1, k + 2, k + 1, k + 3, k + 2); }
      this.ribbonGeometry.setIndex(indices);
      this.ribbon = new THREE.Mesh(this.ribbonGeometry, this.routeMaterial); this.ribbon.frustumCulled = false; this.scene.add(this.ribbon);
      this.edgeGeometry = this.own(new THREE.BufferGeometry());
      this.edgeGeometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(49 * 3), 3).setUsage(THREE.DynamicDrawUsage));
      this.routeEdge = new THREE.Line(this.edgeGeometry, this.own(new THREE.LineBasicMaterial({color: 0x247cff, transparent: true, opacity: .8})));
      this.routeEdge.frustumCulled = false; this.scene.add(this.routeEdge);
      const shadowCanvas = document.createElement('canvas'); shadowCanvas.width = shadowCanvas.height = 128;
      const ctx = shadowCanvas.getContext('2d'), gradient = ctx.createRadialGradient(64, 64, 8, 64, 64, 62);
      gradient.addColorStop(0, '#19253688'); gradient.addColorStop(1, '#19253600'); ctx.fillStyle = gradient; ctx.fillRect(0, 0, 128, 128);
      this.shadowTexture = this.own(new THREE.CanvasTexture(shadowCanvas));
      this.shadowMaterial = this.own(new THREE.MeshBasicMaterial({map: this.shadowTexture, transparent: true, depthWrite: false}));
      this.shadowGeometry = this.own(new THREE.PlaneGeometry(5, 7));
      const egoShadow = new THREE.Mesh(this.shadowGeometry, this.shadowMaterial); egoShadow.rotation.x = -Math.PI / 2; egoShadow.position.y = .02; this.scene.add(egoShadow);
      this.pedMaterial = this.own(new THREE.MeshStandardMaterial({color: 0xdfa44a, roughness: .65}));
      this.pedHeadGeometry = this.own(new THREE.SphereGeometry(.19, 10, 8));
      this.pedBodyGeometry = this.own(new THREE.CapsuleGeometry(.22, .58, 3, 8));
      this.pedLegGeometry = this.own(new THREE.CapsuleGeometry(.085, .5, 3, 6));
      for (let i = 0; i < 18; i++) this.slots.push(this.makeDetectionSlot());
      this.refreshEgo();
    } catch (error) {
      console.warn('Vehicle cockpit WebGL unavailable:', error.message);
      this.failed = true;
      this.nodes['vc-webgl'].textContent = '车机 WebGL 暂不可用';
    }
  }
  refreshEgo() {
    const vehicle = this.g.vehicle;
    if (!this.scene || !vehicle || this.ego?.model.id === vehicle.model.id) return;
    if (this.ego) this.ego.root.visible = false;
    if (!this.models.has(vehicle.model.id)) {
      // createCar caches shared materials/box geometry; retain the vehicle models
      // rather than disposing shared resources used by the main world renderer.
      const model = createCar(vehicle.model.id, false, 0x829bad);
      this.models.set(vehicle.model.id, model); this.scene.add(model.root);
    }
    this.ego = this.models.get(vehicle.model.id);
    this.ego.root.visible = true;
  }
  makeDetectionSlot() {
    const group = new THREE.Group(); group.visible = false;
    const car = createCar('s', true, 0xadb6c2); car.root.visible = false; group.add(car.root);
    const person = new THREE.Group(); person.visible = false;
    const head = new THREE.Mesh(this.pedHeadGeometry, this.pedMaterial); head.position.y = 1.62;
    const body = new THREE.Mesh(this.pedBodyGeometry, this.pedMaterial); body.position.y = 1.06;
    person.add(head, body);
    for (const x of [-.12, .12]) { const leg = new THREE.Mesh(this.pedLegGeometry, this.pedMaterial); leg.position.set(x, .4, 0); person.add(leg); }
    group.add(person);
    const shadow = new THREE.Mesh(this.shadowGeometry, this.shadowMaterial); shadow.rotation.x = -Math.PI / 2; shadow.position.y = .025; group.add(shadow);
    this.scene.add(group);
    return {group, car, person, shadow, key: null, cls: null, target: new THREE.Vector3(), lastSeen: -100, seen: false};
  }
  validDetections() {
    const s = this.g.sensor?.data;
    const time = this.g.time || 0;
    if (!this.g.inCar || !s || !s.frames || time - s.timestamp > 1.2 || time < s.timestamp - .1) return [];
    const source = Array.isArray(s.tracks) ? s.tracks : s.boxes || [];
    return source.map(d => ({...d, cls: d.cls === 'vehicle' ? 3 : d.cls === 'person' || d.cls === 'pedestrian' ? 4 : d.cls}))
      .filter(d => (d.cls === 3 || d.cls === 4) && Number.isFinite(d.distance) && Number.isFinite(d.lateral) && d.distance > 1.5 && d.distance < 85 && Math.abs(d.lateral) < Math.tan(41 * Math.PI / 180) * d.distance + 1.5 && d.visible !== false && (d.age ?? 0) < 1.2 && (d.confidence ?? 1) >= .1)
      .sort((a, b) => a.distance - b.distance).slice(0, 18);
  }
  updateDetections() {
    const s = this.g.sensor?.data, now = this.g.time || 0;
    this.detections = this.validDetections();
    if (!s || !this.detections.length) {
      this.slots.forEach(slot => { slot.group.visible = false; slot.key = null; });
      this.lastSensorFrame = s?.frames ?? -1;
      return;
    }
    if (s.frames === this.lastSensorFrame) return;
    this.lastSensorFrame = s.frames;
    this.slots.forEach(slot => slot.seen = false);
    for (const d of this.detections) {
      const key = d.id === undefined ? null : `${d.cls}:${d.id}`;
      let slot = key === null ? null : this.slots.find(v => v.key === key && !v.seen);
      if (!slot) slot = this.slots.filter(v => !v.seen && v.cls === d.cls && now - v.lastSeen < .6)
        .sort((a, b) => a.target.distanceToSquared(new THREE.Vector3(d.lateral, 0, -d.distance)) - b.target.distanceToSquared(new THREE.Vector3(d.lateral, 0, -d.distance)))[0];
      if (slot && Math.hypot(slot.target.x - d.lateral, slot.target.z + d.distance) > 10) slot = null;
      if (!slot) slot = this.slots.find(v => !v.seen && (!v.group.visible || now - v.lastSeen > .25));
      if (!slot) slot = this.slots.find(v => !v.seen);
      if (!slot) continue;
      const fresh = !slot.group.visible || slot.cls !== d.cls || now - slot.lastSeen > .6;
      slot.target.set(d.lateral, 0, -d.distance);
      if (fresh) slot.group.position.copy(slot.target);
      slot.group.visible = true; slot.key = key; slot.cls = d.cls; slot.seen = true; slot.lastSeen = now;
      slot.car.root.visible = d.cls === 3; slot.person.visible = d.cls === 4;
      slot.shadow.scale.set(d.cls === 4 ? .32 : .9, d.cls === 4 ? .32 : .9, 1);
      slot.car.root.scale.set(clamp((d.width || 1.9) / 1.9, .85, 1.4), 1, clamp((d.length || 4.8) / 4.8, .8, 1.5));
    }
    // Missed/occluded targets disappear after a brief grace period, never inferred
    // from world entities. Every visible target started as real camera pixels.
    this.slots.forEach(slot => { if (!slot.seen && now - slot.lastSeen > .3) { slot.group.visible = false; slot.key = null; } });
  }
  updateRoute() {
    const g = this.g, v = g.vehicle;
    if (!this.ribbon || !v) return;
    const nodes = [new THREE.Vector3(0, .06, 1.2)];
    let distance = 0;
    let last = v.pos;
    const routeView=activeRouteView(g);
    const telemetry=routeView.kind!=='taxi'&&g.autopilot&&g.pilotTelemetry?.path?.length;
    const plannedPath=telemetry?g.pilotTelemetry.path:routeView.points,start=telemetry?0:routeView.index;
    if ((routeView.destination || g.autopilot) && plannedPath.length) for (let i=start;i<plannedPath.length;i++) {
      const p=plannedPath[i];
      const segment = Math.hypot(p.x - last.x, p.z - last.z);
      const t = Math.min(1, Math.max(0, 78 - distance) / Math.max(segment, .001));
      const dx = last.x + (p.x - last.x) * t - v.pos.x, dz = last.z + (p.z - last.z) * t - v.pos.z;
      nodes.push(new THREE.Vector3(dx * Math.cos(v.yaw) - dz * Math.sin(v.yaw), .06, dx * Math.sin(v.yaw) + dz * Math.cos(v.yaw)));
      distance += segment; last = p;
      if (distance >= 78) break;
    }
    const planned = nodes.length > 1;
    this.ribbon.visible = this.routeEdge.visible = planned && g.inCar;
    if (!planned) return;
    const curve = new THREE.CatmullRomCurve3(nodes, false, 'centripetal');
    const positions = this.ribbonGeometry.attributes.position.array, edge = this.edgeGeometry.attributes.position.array;
    for (let i = 0; i <= 48; i++) {
      const p = curve.getPoint(i / 48), tangent = curve.getTangent(i / 48);
      const n = new THREE.Vector3(-tangent.z, 0, tangent.x).normalize().multiplyScalar(1.35);
      positions.set([p.x + n.x, p.y, p.z + n.z, p.x - n.x, p.y, p.z - n.z], i * 6);
      edge.set([p.x, p.y + .005, p.z], i * 3);
    }
    this.ribbonGeometry.attributes.position.needsUpdate = true;
    this.edgeGeometry.attributes.position.needsUpdate = true;
    this.routeMaterial.opacity = g.autopilot ? .34 : .16;
  }
  updateHUD() {
    const g = this.g, v = g.vehicle, n = this.nodes, s = g.sensor?.data;
    if (!v) return;
    n['vc-model'].textContent = v.model.name;
    n['vc-clock'].textContent = g.clockString?.() || '';
    n['vc-speed'].textContent = String(g.inCar ? Math.round(Math.abs(v.speed) * 3.6) : 0);
    const gear = Math.abs(v.speed) < .15 ? 'P' : v.speed < 0 ? 'R' : 'D';
    if (gear !== this.displayGear) {
      n['vc-gear'].innerHTML = ['P', 'R', 'N', 'D'].map(k => `<span${k === gear ? ' class="selected"' : ''}>${k}</span>`).join('');
      this.displayGear = gear;
    }
    n['vc-energy'].querySelector('span').textContent = `${Math.round(v.battery)}%`;
    n['vc-range'].textContent = `${Math.round(v.model.range * v.battery / 100)} km`;
    n['vc-wheel'].classList.toggle('engaged', !!g.autopilot);
    n['vc-wheel'].style.transform = `rotate(${-v.steer * 105}deg)`;
    n['vc-pilot'].classList.toggle('engaged', !!g.autopilot);
    n['vc-pilot'].setAttribute('aria-pressed', String(!!g.autopilot));
    n['vc-camera'].classList.toggle('selected', !document.getElementById('sensor-panel')?.hidden);
    n['vc-camera'].setAttribute('aria-pressed', String(!document.getElementById('sensor-panel')?.hidden));
    const stale = !g.inCar || !s || !s.frames || g.time - s.timestamp > 1.2;
    const detections = this.validDetections();
    const vehicles = detections.filter(d => d.cls === 3).length, people = detections.filter(d => d.cls === 4).length;
    n['vc-count'].textContent = `${vehicles} 辆 · ${people} 人`;
    n['vc-scene-state'].textContent = stale ? (g.inCar ? '等待车载摄像头' : '车辆已停放') : g.paused ? '驾驶画面已暂停' : g.autopilot ? 'Pilot · ' + (g.pilotStatus || '视觉导航') : '摄像头感知 · 实时';
    n['vc-perception-dot'].classList.toggle('live', !stale && !g.paused);
    n['vc-signal'].querySelector('b').textContent = stale ? '—' : `${Math.round(clamp(s.confidence, 0, 1) * 100)}%`;
    const routeView=activeRouteView(g);
    n['vc-destination'].textContent = routeView.kind==='taxi'?routeView.label:g.destination?.name || (g.autopilot?'沿路巡航':'自由驾驶');
    if(routeView.kind==='taxi'){const length=routeView.remaining;n['vc-distance'].textContent=`${length>999?(length/1000).toFixed(1)+' km':Math.round(length)+' m'} · ${g.robotaxi.driver?.reason??'接送路线'}`;}else if (g.destination) {
      let length = 0, p = v.pos;
      for (const point of (g.route || []).slice(g.routeIndex || 0)) { length += Math.hypot(point.x - p.x, point.z - p.z); p = point; }
      if (!length) length = Math.hypot(g.destination.x - v.pos.x, g.destination.z - v.pos.z);
      n['vc-distance'].textContent = `${length > 999 ? (length / 1000).toFixed(1) + ' km' : Math.round(length) + ' m'} · ${g.autopilot && Number.isFinite(g.pilotTelemetry?.targetSpeed) ? '目标 ' + Math.round(g.pilotTelemetry.targetSpeed * 3.6) + ' km/h' : g.autopilot ? '辅助驾驶中' : '路线已规划'}`;
    } else n['vc-distance'].textContent = g.autopilot?'目标 '+Math.round((g.pilotTelemetry?.targetSpeed??0)*3.6)+' / 上限 '+(g.assistSettings?.maxSpeedKmh??100)+' km/h · 跟车 '+(FOLLOW_GAP_PRESETS[g.assistSettings?.followGap]?.label??'中'):'无需导航也可启动巡航';
    updateAssistStatus(n['vc-warning'],g,{cockpit:true});
    n['vc-offline'].hidden = g.inCar;
    this.panel.classList.toggle('vc-parked', !g.inCar);
  }
  update(dt = 1 / 60) {
    if (!this._open) return;
    const step = clamp(dt, 0, .1), interval = 1 / 30;
    this.frameElapsed += step; this.motionElapsed += step; this.hudElapsed += step;
    if (this.hudElapsed >= .12) { this.updateHUD(); this.hudElapsed %= .12; }
    if (!this.renderer || this.failed || this.frameElapsed + .0001 < interval) return;
    // Keep the display cadence across 60/90/120 Hz and rounded RAF timestamps.
    // Animation uses only time since the actual last render, never phase debt.
    const elapsed = this.motionElapsed; this.motionElapsed = 0;
    this.frameElapsed -= interval * Math.max(1, Math.floor((this.frameElapsed + .0001) / interval));
    this.refreshEgo(); this.updateDetections(); this.updateRoute();
    const v = this.g.vehicle, s = this.g.sensor?.data;
    if (this.ego && v) {
      this.ego.root.rotation.y = THREE.MathUtils.damp(this.ego.root.rotation.y, v.steer * .16, 7, elapsed);
      this.ego.wheels.forEach((wheel, i) => {
        wheel.pivot.rotation.y = v.wheels[i]?.pivot.rotation.y || 0;
        wheel.spin.rotation.x = v.wheels[i]?.spin.rotation.x || 0;
      });
      this.ego.doors.forEach((door, i) => { door.pivot.rotation.y = v.doors[i]?.pivot.rotation.y || 0; });
    }
    const fresh = s && s.frames && this.g.time - s.timestamp <= 1.2;
    this.laneMaterial.opacity = fresh ? .28 + clamp(s.confidence || 0, 0, 1) * .48 : .22;
    if (v) {
      // The road network uses 80 m blocks. Rotate map geometry into ego space;
      // only camera detections populate the surrounding cars and pedestrians.
      const dx = Math.round(v.pos.x / 80) * 80 - v.pos.x;
      const dz = Math.round(v.pos.z / 80) * 80 - v.pos.z;
      this.roadGrid.position.set(dx * Math.cos(v.yaw) - dz * Math.sin(v.yaw), 0, dx * Math.sin(v.yaw) + dz * Math.cos(v.yaw));
      this.roadGrid.rotation.y = -v.yaw;
    }
    this.slots.forEach(slot => { if (slot.group.visible) slot.group.position.lerp(slot.target, 1 - Math.exp(-elapsed * 14)); });
    this.renderer.render(this.scene, this.camera);
  }
  resize() {
    this.restorePosition();
    if (!this.renderer || !this._open) return;
    const rect = this.nodes['vc-webgl'].getBoundingClientRect();
    if (rect.width < 1 || rect.height < 1) return;
    this.renderer.setPixelRatio(Math.min(devicePixelRatio || 1, this.g.performanceProfile?.pixelRatio??1.5));
    this.renderer.setSize(Math.round(rect.width), Math.round(rect.height), false);
    this.camera.aspect = rect.width / rect.height;
    this.camera.fov = this.camera.aspect < 1.05 ? 50 : 38;
    this.camera.updateProjectionMatrix();
    this.frameElapsed = 1 / 30;
  }
}
