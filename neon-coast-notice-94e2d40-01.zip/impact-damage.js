// Game tuning over normal collision energy; touching/rubbing is not damage.
export function impactDamage(normalSpeed,mass=1500,otherMass=Infinity){
 if(!Number.isFinite(normalSpeed)||normalSpeed<=1.2)return 0;
 const own=Math.max(300,Math.min(6000,Number(mass)||1500));
 const other=Number.isFinite(otherMass)?Math.max(300,Math.min(6000,otherMass)):Infinity;
 const deltaV=normalSpeed*(Number.isFinite(other)?other/(own+other):1);
 if(deltaV<=1.2)return 0;
 return Math.min(100,.065*(deltaV*deltaV-1.44)*Math.sqrt(own/1500));
}
