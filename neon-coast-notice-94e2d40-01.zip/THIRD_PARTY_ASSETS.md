# Third-party 3D assets

## LUCENT VISION

The LUCENT VISION model is adapted from **Car Concept**, by **Eric Chadwick / Darmstadt Graphics Group GmbH (2024)**, distributed by the Khronos Group under the **Creative Commons Attribution 4.0 International (CC BY 4.0)** license.

- Model source: https://github.com/KhronosGroup/glTF-Sample-Assets/tree/main/Models/CarConcept
- Original GLB: https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Assets/main/Models/CarConcept/glTF-Binary/CarConcept.glb
- License: https://creativecommons.org/licenses/by/4.0/
- Upstream license record: https://github.com/KhronosGroup/glTF-Sample-Assets/blob/main/Models/CarConcept/LICENSE.md
- Original concept design/model: **Unity Fan**, *FREE Concept Car 004 – public domain (CC0)*, https://sketchfab.com/3d-models/free-concept-car-004-public-domain-cc0-4cba124633eb494eadc3bb0c4660ad7e

Changes in this game: the source Khronos/3D Commerce logo and tire-brand textures were replaced by an original fictional LUCENT wordmark and unbranded tire sidewalls; orientation and scale were normalized; posed front-wheel steering was returned to neutral; real door hinges, steering wheel and four independent wheel pivots were connected to the game's animations and driving physics; body-paint colors can be changed, with the original metallic-flake normal strength tuned for a finer finish. The interior dashboard surface now displays live game instruments, the posed steering wheel is centred and connected to steering input, and cabin-view glazing is temporarily cleared for driving visibility. The original geometry, interior, normal maps, ambient occlusion, layered paint and clearcoat are retained. LUCENT is a fictional game brand. The source trademarks are excluded from the model's open license and are not used as this game's branding.

The packaged derivative is `assets/lucent-vision.glb`. Source-license and attribution metadata are retained in `assets/CarConcept-LICENSE.md` and `assets/CarConcept-metadata.json`, and the derivative also embeds attribution in its glTF asset metadata. No endorsement by the original creators is implied.

## Three.js loaders

`vendor/GLTFLoader.js` and `vendor/BufferGeometryUtils.js` are from Three.js r180, copyright © 2010–2025 three.js authors, MIT licensed. Only relative import paths were changed. The license is included as `vendor/three-addons-LICENSE.txt`.

https://github.com/mrdoob/three.js/tree/r180
