// Fictional C800 gameplay event. No claim about a real vehicle or manufacturer.
// Timings are seconds of simulation, never frame counts.
export const C800_BRAKE = Object.freeze({pressure:.86,release:.15,minSpeed:6,hold:.12,fracture:.36,closeup:2.8});
export function createBrakeFault(broken=false,rng=Math.random){
 return {phase:broken?'broken':'healthy',hardTime:0,elapsed:broken?C800_BRAKE.closeup:0,broken:!!broken,justCounted:false,justTriggered:false,justBroke:false,
  eventCount:0,eventThreshold:rng()<.5?2:3,eventLatched:false};
}
function validEventState(saved,broken){
 return (saved?.eventThreshold===2||saved?.eventThreshold===3)
  &&Number.isInteger(saved.eventCount)&&saved.eventCount>=0&&saved.eventCount<=saved.eventThreshold
  &&(broken||saved.eventCount<saved.eventThreshold)
  &&typeof saved.eventLatched==='boolean'
  &&Number.isFinite(saved.hardTime)&&saved.hardTime>=0&&saved.hardTime<C800_BRAKE.hold
  &&(!saved.eventLatched||(saved.eventCount>0&&saved.hardTime===0));
}
export function isValidBrakeFaultSave(saved){
 if(!saved||typeof saved!=='object'||Array.isArray(saved)||typeof saved.broken!=='boolean')return false;
 const fields=['eventCount','eventThreshold','eventLatched','hardTime'];
 // Legacy boolean-only saves remain supported, but partial or corrupt new
 // metadata must not silently reset a lifecycle and grant extra safe presses.
 if(!fields.some(key=>Object.hasOwn(saved,key)))return true;
 return fields.every(key=>Object.hasOwn(saved,key))&&validEventState(saved,saved.broken);
}
export function restoreBrakeFault(saved,rng=Math.random){
 const broken=saved===true||saved?.broken===true||saved?.phase==='bending'||saved?.phase==='broken';
 // A complete saved lifecycle never draws again. Legacy saves start safely at
 // zero events; an old or mid-animation failure remains permanently broken.
 const valid=validEventState(saved,broken),f=createBrakeFault(broken,valid?()=>saved.eventThreshold===2?0:1:rng);
 if(valid){f.eventCount=saved.eventCount;f.eventLatched=saved.eventLatched;f.hardTime=broken?0:saved.hardTime;}
 return f;
}
export function serializeBrakeFault(vehicle){
 if(vehicle.model.id!=='c800')return {broken:false};
 const f=vehicle.brakeFault??=createBrakeFault();
 return {broken:!!(f.broken||f.phase==='bending'||f.phase==='broken'),eventCount:f.eventCount,eventThreshold:f.eventThreshold,eventLatched:f.eventLatched,hardTime:f.hardTime};
}
export function repairBrakeFault(vehicle,rng=Math.random){vehicle.brakeFault=createBrakeFault(false,rng);vehicle.requestedBrakeAmount=0;vehicle.brakeAmount=0;}
export function stepBrakeFault(vehicle,pressure,dt){
 if(vehicle.model.id!=='c800')return pressure;
 const f=vehicle.brakeFault??=createBrakeFault();f.justCounted=false;f.justTriggered=false;f.justBroke=false;
 if(f.phase==='healthy'){
  // Only a meaningful pedal release permits another event. Dipping to gentle
  // pressure or crossing the speed boundary cannot count the same held press.
  if(pressure<=C800_BRAKE.release)f.eventLatched=false;
  if(!f.eventLatched&&pressure>=C800_BRAKE.pressure&&Math.abs(vehicle.speed)>=C800_BRAKE.minSpeed)f.hardTime+=dt;else f.hardTime=0;
  if(f.hardTime+1e-9>=C800_BRAKE.hold){
   const overshoot=Math.max(0,f.hardTime-C800_BRAKE.hold);
   f.hardTime=0;f.eventLatched=true;f.eventCount++;f.justCounted=true;
   if(f.eventCount>=f.eventThreshold){f.phase='bending';f.elapsed=overshoot;f.justTriggered=true;}
  }
 }else f.elapsed=Math.min(C800_BRAKE.closeup,f.elapsed+dt);
 if(f.phase==='bending'&&f.elapsed+1e-9>=C800_BRAKE.fracture){f.phase='broken';f.broken=true;f.justBroke=true;}
 return f.broken?0:pressure;
}
