import {createPassengerJet} from './region-scenery.js';
import {getRegionTravel,airportAt,groundHeight} from './regions.js';
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const smooth=t=>{const x=clamp(t);return x*x*(3-2*x);};
/** Compressed passenger-flight sequence, not a flight simulator. */
export function sampleFlight(origin,destination,time){
 const arrival=time>=6,a=arrival?destination:origin,t=clamp((arrival?time-6:time)/6),r=a.runway;
 const z=arrival?r.z+600-900*t:r.z+500-1050*t;
 const lift=arrival?95*(1-smooth(t/.8)):95*smooth((t-.22)/.75);
 return{position:{x:r.x,y:a.altitude+lift+.3,z},pitch:arrival?-.025:-.06*smooth(t/.35),arrival,done:time>=12,opacity:Math.max(1-smooth(time/.6),1-smooth(Math.abs(time-6)/.5),smooth((time-11.5)/.5)),label:arrival?'正在降落 · '+a.name:'起飞 · '+a.name};
}
export class FlightTravel{
 constructor(game){this.game=game;this.active=false;}
 start(regionId){const g=this.game,origin=airportAt(g.position),target=getRegionTravel(regionId);if(this.active)return{ok:false,reason:'航程正在进行'};if(!origin)return{ok:false,reason:'请先到机场公共道路的航站楼入口'};if(!target||target.airport.id===origin.id)return{ok:false,reason:'请选择另一个地区'};if(g.robotaxi?.active||g.transition)return{ok:false,reason:'请先完成当前乘车行程'};if(g.inCar&&Math.abs(g.vehicle.speed)>.5)return{ok:false,reason:'请先停车后登机'};g.resetControls();g.autopilot=false;g.pilot?.reset();g.sensor?.reset?.();g.assistTelemetry=null;g.vehicle.speed=0;this.active=true;document.body.classList.add('flight-active');this.time=0;this.origin=origin;this.target=target;this.wasInCar=g.inCar;this.plane=createPassengerJet();g.scene.add(this.plane);g.vehicle.root.visible=false;g.person.root.visible=false;g.ui.closePhone();g.ui.closeModal();this.update(0);return{ok:true};}
 update(dt){if(!this.active)return;this.time+=dt;const pose=sampleFlight(this.origin,this.target.airport,this.time);this.pose=pose;this.plane.position.set(pose.position.x,pose.position.y,pose.position.z);this.plane.rotation.x=pose.pitch;this.game.vehicle.root.visible=false;this.game.person.root.visible=false;if(pose.done)this.finish();}
 finish(){if(!this.active)return;const g=this.game,p=this.target.position;g.vehicle.pos.set(p.x,groundHeight(p.x,p.z)+.02,p.z);g.vehicle.yaw=this.target.yaw;g.vehicle.root.rotation.y=g.vehicle.yaw;g.playerPos.set(p.x-3,groundHeight(p.x-3,p.z),p.z);g.playerYaw=g.vehicle.yaw;g.inCar=this.wasInCar;this.dispose();g.resetAfterTravel?.();g.ui.toast('已抵达 '+this.target.region.name+' · 车辆已随行托运');g.save(false);}
 cancel(){if(!this.active)return;this.dispose();this.game.resetAfterTravel?.();}
 dispose(){this.active=false;document.body.classList.remove('flight-active');if(this.plane){const geometries=new Set(),materials=new Set();this.plane.traverse(o=>{if(o.geometry)geometries.add(o.geometry);if(o.material)for(const m of Array.isArray(o.material)?o.material:[o.material])materials.add(m);});this.plane.removeFromParent();geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());this.plane=null;}this.game.vehicle.root.visible=true;this.game.person.root.visible=!this.game.inCar;}
}
