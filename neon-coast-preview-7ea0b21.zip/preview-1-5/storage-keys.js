import {CURRENT_RELEASE,RELEASE_CANDIDATE} from './release-notes.js';

// localStorage is shared by every path on an origin. Candidate builds must use
// their own keys even in an offline ZIP, never migrate or fall back to a shipped
// game's data. The homepage can explicitly copy data into a NEW preview slot;
// neither opening the preview nor selecting a slot ever migrates existing data.
export const FORMAL_STORAGE_KEYS=Object.freeze({
 SAVE_KEY:'neon-coast-save-v1',
 ASSIST_SETTINGS_KEY:'neon-coast-assist-settings',
 QUALITY_PREFERENCE_KEY:'neon-coast-quality',
 RELEASE_READ_KEY:'neon-coast-release-read',
 COCKPIT_OPEN_KEY:'neon-coast-cockpit-open',
 COCKPIT_POSITION_KEY:'neon-coast-cockpit-position',
 INPUT_MODE_KEY:'neon-coast-input-mode',
 MISSION_HIDDEN_KEY:'neon-coast-mission-hidden'
});
// Compatible1.5 preview patches share one isolated save namespace.
export const CANDIDATE_STORAGE_RELEASE='1.5.0';
export function storageKeysForRelease(candidate=RELEASE_CANDIDATE,version=CANDIDATE_STORAGE_RELEASE){
 return Object.freeze(Object.fromEntries(Object.entries(FORMAL_STORAGE_KEYS).map(([name,key])=>[
  name,candidate?`neon-coast-candidate-${version}:${key.slice('neon-coast-'.length)}`:key
 ])));
}
export const PREVIEW_SLOT_INDEX_PREFIX=`neon-coast-candidate-${CANDIDATE_STORAGE_RELEASE}:slot-index:`;
export const isPreviewSlotId=value=>typeof value==='string'&&/^s-[a-z0-9][a-z0-9-]{0,95}$/.test(value);
export class PreviewSlotError extends Error{
 constructor(code,message,options){super(message,options);this.name='PreviewSlotError';this.code=code;}
}
export function previewSlotIndexKey(slot){
 if(!isPreviewSlotId(slot))throw new PreviewSlotError('invalid-slot','测试存档入口无效，请返回首页选择已有存档。');
 return PREVIEW_SLOT_INDEX_PREFIX+slot;
}
export function storageKeysForSlot(slot){
 if(slot===null)return storageKeysForRelease(true);
 previewSlotIndexKey(slot);
 return Object.freeze(Object.fromEntries(Object.entries(FORMAL_STORAGE_KEYS).map(([name,key])=>[
  name,`neon-coast-candidate-${CANDIDATE_STORAGE_RELEASE}:slot-${slot}:${key.slice('neon-coast-'.length)}`
 ])));
}
export function parsePreviewSlotSearch(search=''){
 const values=new URLSearchParams(search).getAll('slot');
 if(!values.length)return null;
 if(values.length!==1||!isPreviewSlotId(values[0]))throw new PreviewSlotError('invalid-slot','测试存档入口无效，请返回首页选择已有存档。');
 return values[0];
}
// A per-slot index record is the transaction's last write. Uncommitted or
// unknown namespaces must not boot and accidentally start overwriting data.
export function readPreviewSlotRecord(storage,slot){
 const key=previewSlotIndexKey(slot);let raw;
 try{raw=storage.getItem(key);}catch(cause){throw new PreviewSlotError('storage-read','无法读取测试存档。请允许此网站使用本地存储后重试。',{cause});}
 if(raw===null)throw new PreviewSlotError('unknown-slot','找不到这个测试存档，请返回首页选择已有存档。');
 let record;try{record=JSON.parse(raw);}catch{}
 if(!record||record.version!==1||record.slot!==slot||!['copy','fresh'].includes(record.mode)||
  typeof record.createdAt!=='string'||!Number.isFinite(Date.parse(record.createdAt))||
  (record.operationToken!==undefined&&(typeof record.operationToken!=='string'||record.operationToken.length>128)))
  throw new PreviewSlotError('invalid-slot-record','这个测试存档的入口记录不完整，请保留现有数据并返回首页。');
 return record;
}
export function resolvePreviewSlot(search='',storage){
 const slot=parsePreviewSlotSearch(search);
 if(slot!==null)readPreviewSlotRecord(storage,slot);
 return slot;
}
function showSlotFailure(error){
 const doc=globalThis.document;if(!doc?.createElement)return;
 const panel=doc.createElement('section');panel.setAttribute('role','alert');panel.setAttribute('aria-live','assertive');
 panel.style.cssText='position:fixed;inset:0;z-index:2147483647;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:18px;padding:32px;background:#08111c;color:#f5f8ff;font:16px/1.7 system-ui;text-align:center';
 const title=doc.createElement('h1');title.textContent='无法打开测试存档';
 const message=doc.createElement('p');message.textContent=error.message+' 游戏尚未启动，原有存档不会被覆盖。';
 const home=doc.createElement('a');home.href=new URL('../',import.meta.url).href;home.textContent='返回正式版首页';home.style.cssText='color:#84e7db;text-decoration:underline;padding:12px';
 panel.append(title,message,home);(doc.body??doc.documentElement).append(panel);
}
function initialPreviewSlot(){
 if(!RELEASE_CANDIDATE)return null;
 // The formal homepage imports the pure launcher helpers from the preview
 // directory. Its explicit staging marker prevents unrelated homepage query
 // parameters from being treated as candidate Game startup instructions.
 if(globalThis.document?.documentElement?.dataset?.neonFormalEntry==='true')return null;
 try{
  // Read the URL once, before any Game/UI persistence module runs. Node and
  // bare preview links retain the original 1.5.0 namespace without a read.
  const search=globalThis.location?.search??'';
  const slot=parsePreviewSlotSearch(search);
  return slot===null?null:resolvePreviewSlot(search,globalThis.localStorage);
 }catch(cause){
  const error=cause instanceof PreviewSlotError?cause:new PreviewSlotError('storage-read','无法读取测试存档。请允许此网站使用本地存储后重试。',{cause});
  showSlotFailure(error);throw error;
 }
}
export const ACTIVE_PREVIEW_SLOT=initialPreviewSlot();
export const STORAGE_KEYS=RELEASE_CANDIDATE?storageKeysForSlot(ACTIVE_PREVIEW_SLOT):storageKeysForRelease(false);
export const {SAVE_KEY,ASSIST_SETTINGS_KEY,QUALITY_PREFERENCE_KEY,RELEASE_READ_KEY,
 COCKPIT_OPEN_KEY,COCKPIT_POSITION_KEY,INPUT_MODE_KEY,MISSION_HIDDEN_KEY}=STORAGE_KEYS;
export const SAVE_SCOPE_LABEL=RELEASE_CANDIDATE?CURRENT_RELEASE+' 候选版独立存档'+(ACTIVE_PREVIEW_SLOT?' · '+ACTIVE_PREVIEW_SLOT:''):'此浏览器的存档';
export const SAVE_SCOPE_NOTE=RELEASE_CANDIDATE
 ?'候选版存档与设置独立保存，不会读取、覆盖或删除正式版进度。同一1.5试玩系列补丁保留已有进度；首次进入试玩从新旅程开始。首页可将正式版进度复制到另一个新的测试存档，或新建测试存档；此前的测试存档仍可从首页继续。也可在正式版导出 JSON，再在此手动导入。导入只写入当前候选版存档。'
 :'';
export const SAVE_EXPORT_PREFIX=RELEASE_CANDIDATE?'neon-coast-'+CURRENT_RELEASE+'-candidate-':'neon-coast-';
