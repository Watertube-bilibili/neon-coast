import {mountainAt,snapMountainRoad,MOUNTAIN,MOUNTAIN_ROADS} from './regions.js';
import {activeRouteView} from './route-view.js';
import {PLACES,GRID,WORLD_LIMIT,WORLD_MIN_X,HIGHWAY,AIRPORTS,REGIONS,roadSpans,roadInfo} from './world.js';
const $=id=>document.getElementById(id);
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const meters=n=>n>=1000?(n/1000).toFixed(n>=10000?0:1)+' km':Math.round(n)+' m';
const viewBounds=(c,w,h,scale)=>({left:c.x-w/2/scale,right:c.x+w/2/scale,top:c.z-h/2/scale,bottom:c.z+h/2/scale});
const inside=(p,b,pad=0)=>p.x>b.left-pad&&p.x<b.right+pad&&p.z>b.top-pad&&p.z<b.bottom+pad;

// Map marks always land on a driveable grid lane, including unvisited districts.
export function snapMapDestination(x,z){
 if(mountainAt({x,z}))return {...snapMountainRoad({x,z}),name:'山地公路标记'};
 // Reserve the final outer road strip for world-edge collision clearance.
 const edge=WORLD_LIMIT-GRID;
 x=clamp(x,-240+4.5,edge);z=clamp(z,-edge,edge);
 const airport=AIRPORTS.find(a=>x>a.bounds.minX&&x<a.bounds.maxX&&z>a.bounds.minZ&&z<a.bounds.maxZ);if(airport)return{x:airport.x,z:airport.z,name:airport.name};
 if(x>3131&&x<3269&&z>HIGHWAY.zMin&&z<HIGHWAY.zMax&&!HIGHWAY.exits.some(e=>Math.abs(z-e)<14))return{x:HIGHWAY.x+4.5,z,name:'H1 高速标记'};
 const nx=clamp(Math.round(x/GRID)*GRID,-240,edge),nz=clamp(Math.round(z/GRID)*GRID,-edge,edge);
 if(Math.abs(x-nx)<Math.abs(z-nz))x=nx+4.5;
 else z=nz-4.5;
 return{x,z,name:'地图标记'};
}

export function drawWorldMap(ui,canvas,full=false){
 if(!canvas)return;
 const ctx=canvas.getContext('2d');if(!ctx)return;
 const g=ui.g,w=full?Math.max(1,Math.round(canvas.clientWidth||700)):canvas.width,h=full?Math.round(w*520/700):canvas.height;
 if(full){const dpr=Math.min(window.devicePixelRatio||1,2);if(canvas.width!==Math.round(w*dpr)||canvas.height!==Math.round(h*dpr)){canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr)}ctx.setTransform(dpr,0,0,dpr,0,0)}
 const c=full?(ui.worldMapView??{x:g.position.x,z:g.position.z,span:1800}):g.position;
 const scale=full?w/c.span:1.75*(g.mapZoom||1),b=viewBounds(c,w,h,scale),px=x=>(x-c.x)*scale+w/2,pz=z=>(z-c.z)*scale+h/2;
 ctx.clearRect(0,0,w,h);ctx.fillStyle='#263c43';ctx.fillRect(0,0,w,h);
 ctx.fillStyle='#346773';ctx.fillRect(0,0,clamp(px(-306),0,w),h);
 ctx.fillStyle='#71806b';ctx.fillRect(px(-306),0,25*scale,h);
 // Only resident buildings are shown; the deterministic road atlas extends beyond them.
 if(scale>.07)for(const q of g.world.colliders){if(!inside(q,b,Math.max(q.w,q.d)))continue;ctx.fillStyle='#41565b';ctx.fillRect(px(q.x-q.w),pz(q.z-q.d),q.w*2*scale,q.d*2*scale)}
 if(full){ctx.fillStyle='#68765a55';ctx.fillRect(px(9600),pz(-16000),6400*scale,11200*scale);ctx.fillStyle='#69795555';ctx.beginPath();ctx.ellipse(px(4700),pz(-11000),2400*scale,2900*scale,0,0,Math.PI*2);ctx.fill()}
 ctx.fillStyle='#38554c';ctx.fillRect(px(-225),pz(-145),55*scale,65*scale);
 let stride=1;while(GRID*stride*scale<7)stride*=2;
 const grid=GRID*stride,xStart=Math.max(-240,Math.ceil(b.left/grid)*grid),xEnd=Math.min(WORLD_LIMIT,b.right);
 ctx.strokeStyle=scale<.15?'#536c70':'#60787c';ctx.lineWidth=Math.max(1,22*scale);
 ctx.beginPath();
 for(let x=xStart;x<=xEnd;x+=grid)for(const [a,z]of roadSpans([[Math.max(-WORLD_LIMIT,b.top),Math.min(WORLD_LIMIT,b.bottom)]],x,true)){ctx.moveTo(px(x),pz(a));ctx.lineTo(px(x),pz(z))}
 for(let z=Math.ceil(Math.max(-WORLD_LIMIT,b.top)/grid)*grid;z<=Math.min(WORLD_LIMIT,b.bottom);z+=grid)for(const [a,x]of roadSpans([[Math.max(WORLD_MIN_X,b.left),Math.min(WORLD_LIMIT,b.right)]],z,false)){ctx.moveTo(px(a),pz(z));ctx.lineTo(px(x),pz(z))}
 ctx.stroke();
 ctx.strokeStyle='#a7c697';ctx.lineWidth=Math.max(2,22*scale);ctx.beginPath();for(const {a,b}of MOUNTAIN_ROADS){ctx.moveTo(px(a.x),pz(a.z));ctx.lineTo(px(b.x),pz(b.z));}ctx.stroke();
 // Physical H1 spine and graded exits stay visible even at atlas scale.
 ctx.strokeStyle='#dfbd73';ctx.lineWidth=Math.max(2.5,34*scale);ctx.beginPath();ctx.moveTo(px(HIGHWAY.x),pz(HIGHWAY.zMin));ctx.lineTo(px(HIGHWAY.x),pz(HIGHWAY.zMax));ctx.stroke();
 ctx.lineWidth=Math.max(1.5,22*scale);ctx.beginPath();for(const z of HIGHWAY.exits){ctx.moveTo(px(HIGHWAY.x-HIGHWAY.approachLength),pz(z));ctx.lineTo(px(HIGHWAY.x+HIGHWAY.approachLength),pz(z))}ctx.stroke();
 for(const a of AIRPORTS){ctx.fillStyle='#84948c';ctx.fillRect(px(a.bounds.minX),pz(a.bounds.minZ),(a.bounds.maxX-a.bounds.minX)*scale,(a.bounds.maxZ-a.bounds.minZ)*scale);ctx.fillStyle='#d5ded4';ctx.fillRect(px(a.runway.x-a.runway.width/2),pz(a.runway.z-a.runway.length/2),Math.max(2,a.runway.width*scale),a.runway.length*scale);if(full&&scale>.009){ctx.fillStyle='#dcebe0';ctx.font='12px sans-serif';ctx.fillText('✈ '+a.code,px(a.x)+8,pz(a.z)-18)}}
 // The coastal road also continues beyond the original downtown blocks.
 ctx.lineWidth=Math.max(1,24*scale);ctx.beginPath();ctx.moveTo(px(-262),pz(Math.max(-WORLD_LIMIT,b.top)));ctx.lineTo(px(-262),pz(Math.min(WORLD_LIMIT,b.bottom)));ctx.stroke();
 if(scale>.5){ctx.strokeStyle='#c5d0b34d';ctx.lineWidth=1;ctx.setLineDash([4,6]);ctx.beginPath();for(let x=xStart;x<=xEnd;x+=grid){ctx.moveTo(px(x),0);ctx.lineTo(px(x),h)}for(let z=Math.ceil(b.top/grid)*grid;z<=b.bottom;z+=grid){ctx.moveTo(Math.max(0,px(WORLD_MIN_X)),pz(z));ctx.lineTo(w,pz(z))}ctx.stroke();ctx.setLineDash([])}
 // Mark the actual edge of this 32 km north/south world rather than drawing endless roads.
 ctx.fillStyle='#111e2888';if(b.right>WORLD_LIMIT)ctx.fillRect(px(WORLD_LIMIT+14),0,w,h);if(b.top< -WORLD_LIMIT)ctx.fillRect(0,0,w,pz(-WORLD_LIMIT-14));if(b.bottom>WORLD_LIMIT)ctx.fillRect(0,pz(WORLD_LIMIT+14),w,h);
 const routeView=activeRouteView(g);if(routeView.points.length){ctx.strokeStyle=routeView.color;ctx.lineWidth=full?3:4;ctx.lineJoin='round';ctx.lineCap='round';ctx.beginPath();ctx.moveTo(px(routeView.origin.x),pz(routeView.origin.z));for(let i=routeView.index;i<routeView.points.length;i++){const p=routeView.points[i];ctx.lineTo(px(p.x),pz(p.z));}ctx.stroke()}
 if(full&&ui.worldMapSelection){const p=ui.worldMapSelection;ctx.strokeStyle='#54dfff';ctx.lineWidth=2;ctx.beginPath();ctx.arc(px(p.x),pz(p.z),11,0,Math.PI*2);ctx.stroke();ctx.beginPath();ctx.moveTo(px(p.x)-16,pz(p.z));ctx.lineTo(px(p.x)+16,pz(p.z));ctx.moveTo(px(p.x),pz(p.z)-16);ctx.lineTo(px(p.x),pz(p.z)+16);ctx.stroke();}
 const labels=[];
 for(const p of PLACES){if(!inside(p,b,20))continue;const x=px(p.x),y=pz(p.z);ctx.fillStyle='#b5c8b4';ctx.beginPath();ctx.arc(x,y,full?4:3,0,Math.PI*2);ctx.fill();if(full){ctx.font='14px sans-serif';const length=ctx.measureText(p.name).width,label={x:clamp(x+9,7,w-length-7),y:clamp(y-8,18,h-48),w:length,h:17};if(!labels.some(q=>Math.abs(q.y-label.y)<19&&q.x<label.x+label.w+8&&q.x+q.w+8>label.x)){labels.push(label);ctx.strokeStyle='#243a40';ctx.lineWidth=4;ctx.strokeText(p.name,label.x,label.y);ctx.fillStyle='#e6eedf';ctx.fillText(p.name,label.x,label.y)}}}
 for(const v of g.traffic??[]){if(!inside(v.pos,b))continue;ctx.fillStyle='#bbc2b9';ctx.fillRect(px(v.pos.x)-1.7,pz(v.pos.z)-1.7,3.4,3.4)}
 for(const v of g.police??[]){if(!inside(v.pos,b))continue;ctx.fillStyle='#ee8383';ctx.beginPath();ctx.arc(px(v.pos.x),pz(v.pos.z),4,0,Math.PI*2);ctx.fill()}
 if(routeView.destination){const destination=routeView.destination,x=px(destination.x),y=pz(destination.z);ctx.strokeStyle=routeView.color;ctx.lineWidth=2;ctx.beginPath();ctx.arc(x,y,full?9:7,0,Math.PI*2);ctx.stroke();ctx.fillStyle=routeView.color;ctx.beginPath();ctx.arc(x,y,3,0,Math.PI*2);ctx.fill();if(!full&&!inside(destination,b)){const dx=x-w/2,dy=y-h/2,t=Math.min((w/2-14)/Math.abs(dx),(h/2-14)/Math.abs(dy));ctx.save();ctx.translate(w/2+dx*t,h/2+dy*t);ctx.rotate(Math.atan2(dy,dx)+Math.PI/2);ctx.beginPath();ctx.moveTo(0,-6);ctx.lineTo(-4,4);ctx.lineTo(4,4);ctx.closePath();ctx.fill();ctx.restore()}}
 if(inside(g.position,b,12)){ctx.save();ctx.translate(px(g.position.x),pz(g.position.z));ctx.rotate(-g.yaw);ctx.shadowColor='#c4f580';ctx.shadowBlur=10;ctx.fillStyle='#e1ffaf';ctx.beginPath();ctx.moveTo(0,-9);ctx.lineTo(-6,7);ctx.lineTo(0,3);ctx.lineTo(6,7);ctx.closePath();ctx.fill();ctx.restore()}
 const span=w*.18/scale,pow=10**Math.floor(Math.log10(span)),ruler=[1,2,5,10].filter(q=>q*pow<=span).pop()*pow;
 ctx.strokeStyle='#cdd8ce';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(14,h-20);ctx.lineTo(14,h-15);ctx.lineTo(14+ruler*scale,h-15);ctx.lineTo(14+ruler*scale,h-20);ctx.stroke();ctx.font=(full?'13':'12')+'px sans-serif';ctx.fillStyle='#e3eddf';ctx.fillText(meters(ruler),14,h-25);
 if(full){ctx.font='600 14px sans-serif';ctx.fillStyle='#c4f580';ctx.fillText('N ↑',w-43,28);ctx.font='11px sans-serif';ctx.textAlign='right';ctx.fillStyle='#afc1bc';if(w>350)ctx.fillText('金色 H1 · 浅绿山路 · 灰白跑道',w-14,h-17);ctx.textAlign='left'}
}

export function openWorldMap(ui){
 const g=ui.g;ui.openModal('霓虹海岸 · 开放世界','EXPLORE / LIVE WORLD');
 ui.worldMapView={x:g.position.x,z:g.position.z,span:1800};ui.worldMapSelection=null;
 $('modal-body').innerHTML=`<div class="world-map-layout"><div class="world-map-main"><div class="world-map-toolbar" aria-label="地图操作"><button id="map-zoom-in" aria-label="放大地图" title="放大地图">＋</button><button id="map-zoom-out" aria-label="缩小地图" title="缩小地图">−</button><button id="map-recenter">我的位置</button><button id="map-overview">全域</button><span id="map-span"></span></div><canvas id="full-map" width="700" height="520" tabindex="0" aria-label="城市地图，拖动平移，点击选择地点，再选择导航或传送，滚轮或加减按钮缩放"></canvas><p class="world-map-hint">拖动探索 · 点击选择地点 · 可导航或传送 · 滚轮缩放</p><div class="world-map-status" id="map-world-status"></div></div><div class="world-map-sidebar"><p class="world-map-section">探索目的地</p><div class="world-map-places">${PLACES.map(p=>`<button data-map-place="${esc(p.id)}"><span>${esc(p.name)}</span><small>${meters(Math.hypot(p.x-g.position.x,p.z-g.position.z))}</small></button>`).join('')}</div><div class="world-map-nav"><p id="map-selection" aria-live="polite"></p><button id="map-set-destination" class="secondary-action">设置目的地</button><button id="map-teleport" class="primary-action">传送到此处</button><p id="map-destination" aria-live="polite"></p><button id="map-drive" class="primary-action">启动辅助驾驶</button><button id="map-clear" class="secondary-action">取消导航</button></div></div></div>`;
 const canvas=$('full-map'),view=ui.worldMapView;
 const redraw=()=>{if(!canvas.isConnected)return;drawWorldMap(ui,canvas,true);$('map-span').textContent=meters(view.span);$('map-zoom-in').disabled=view.span<=240;$('map-zoom-out').disabled=view.span>=48000;$('map-world-status').textContent=`南北 ${Math.round(WORLD_LIMIT*2/1000)} km · H1 实际贯通 28.8 km · 2 个地区 / 2 座机场`;const selection=ui.worldMapSelection;$('map-selection').textContent=selection?'已选择 · '+selection.name+(g.flight?.active?' · 航程结束后可传送':g.job?' · 职业任务结束后可传送':' · 传送会携带当前车辆'):'选择地图地点，再设置目的地或传送';const ride=g.robotaxi?.active;$('map-set-destination').disabled=!selection||ride;$('map-teleport').disabled=!selection||!!g.flight?.active||!!g.job||!!g.teleporting;$('map-destination').textContent=ride?activeRouteView(g).label+' · 更换目的地请先取消接送':g.destination?(g.job?'职业路线 · ':'导航至 · ')+g.destination.name:'尚未设置导航';$('map-clear').disabled=ride||!g.destination;$('map-drive').disabled=ride||(!g.destination&&!g.autopilot);$('map-drive').textContent=g.autopilot?'关闭辅助驾驶':'启动辅助驾驶';for(const button of $('modal-body').querySelectorAll('[data-map-place]'))button.classList.toggle('selected',ui.worldMapSelection?.name===PLACES.find(p=>p.id===button.dataset.mapPlace)?.name)};
 const bound=()=>{view.x=clamp(view.x,WORLD_MIN_X-200,WORLD_LIMIT);view.z=clamp(view.z,-WORLD_LIMIT,WORLD_LIMIT);view.span=clamp(view.span,240,48000)};
 const zoom=(factor,anchor=null)=>{const old=view.span;view.span=clamp(old*factor,240,48000);if(anchor){const ratio=view.span/old;view.x=anchor.x+(view.x-anchor.x)*ratio;view.z=anchor.z+(view.z-anchor.z)*ratio}bound();redraw()};
 const eventWorld=e=>{const r=canvas.getBoundingClientRect();return{x:view.x+(e.clientX-r.left-r.width/2)/r.width*view.span,z:view.z+(e.clientY-r.top-r.height/2)/r.height*(view.span*canvas.height/canvas.width)}};
 const select=target=>{ui.worldMapSelection={...target};redraw()};
 const navigate=target=>{if(g.robotaxi?.active){ui.toast('接送中 · 更换目的地请先取消接送');return}if(g.job){ui.toast('当前正在进行职业任务，请先完成或取消工作');return}g.arrivalShown=false;g.setDestination(target);redraw()};
 $('map-set-destination').onclick=()=>{if(ui.worldMapSelection)navigate(ui.worldMapSelection)};
 $('map-teleport').onclick=()=>{if(!ui.worldMapSelection||g.teleporting)return;const result=g.teleportTo(ui.worldMapSelection);if(!result.ok){ui.toast(result.reason,'error');redraw()}};
 $('map-zoom-in').onclick=()=>zoom(1/1.6);$('map-zoom-out').onclick=()=>zoom(1.6);
 $('map-recenter').onclick=()=>{view.x=g.position.x;view.z=g.position.z;redraw()};
 $('map-overview').onclick=()=>{view.x=(WORLD_MIN_X+WORLD_LIMIT)/2;view.z=0;view.span=Math.max(WORLD_LIMIT-WORLD_MIN_X,WORLD_LIMIT*2*canvas.width/canvas.height)*1.05;redraw()};
 $('map-clear').onclick=()=>{if(g.job){ui.toast('请先取消当前工作');return}g.clearDestination();g.autopilot=false;ui.updateAll();redraw()};
 $('map-drive').onclick=()=>{ui.closeModal();g.toggleAutopilot()};
 for(const button of $('modal-body').querySelectorAll('[data-map-place]'))button.onclick=()=>{const place=PLACES.find(p=>p.id===button.dataset.mapPlace);view.x=place.x;view.z=place.z;view.span=1800;select(place)};
 let drag=null;
 canvas.addEventListener('pointerdown',e=>{if(e.button!==0||drag)return;e.preventDefault();canvas.focus({preventScroll:true});canvas.setPointerCapture(e.pointerId);drag={id:e.pointerId,x:e.clientX,y:e.clientY,startX:e.clientX,startY:e.clientY,moved:false};canvas.classList.add('dragging')});
 canvas.addEventListener('pointermove',e=>{if(!drag||drag.id!==e.pointerId)return;const r=canvas.getBoundingClientRect();if(Math.hypot(e.clientX-drag.startX,e.clientY-drag.startY)>7)drag.moved=true;if(drag.moved){view.x-=(e.clientX-drag.x)/r.width*view.span;view.z-=(e.clientY-drag.y)/r.height*view.span*canvas.height/canvas.width;bound();redraw()}drag.x=e.clientX;drag.y=e.clientY});
 canvas.addEventListener('pointerup',e=>{if(!drag||drag.id!==e.pointerId)return;const shouldSelect=!drag.moved;drag=null;canvas.classList.remove('dragging');if(canvas.hasPointerCapture(e.pointerId))canvas.releasePointerCapture(e.pointerId);if(shouldSelect){const p=eventWorld(e);select(snapMapDestination(p.x,p.z))}});
 const release=()=>{drag=null;canvas.classList.remove('dragging')};canvas.addEventListener('pointercancel',release);canvas.addEventListener('lostpointercapture',release);
 canvas.addEventListener('wheel',e=>{e.preventDefault();zoom(e.deltaY>0?1.18:1/1.18,eventWorld(e))},{passive:false});
 // Screen buttons support touch; keyboard users can also pan and zoom this focused canvas.
 canvas.addEventListener('keydown',e=>{const delta=view.span*.15;if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','+','=','-','Home'].includes(e.key)){e.preventDefault();e.stopPropagation();if(e.key==='ArrowLeft')view.x-=delta;if(e.key==='ArrowRight')view.x+=delta;if(e.key==='ArrowUp')view.z-=delta;if(e.key==='ArrowDown')view.z+=delta;if(e.key==='+'||e.key==='=')return zoom(1/1.6);if(e.key==='-')return zoom(1.6);if(e.key==='Home'){view.x=g.position.x;view.z=g.position.z}bound();redraw()}});
 redraw();
}
