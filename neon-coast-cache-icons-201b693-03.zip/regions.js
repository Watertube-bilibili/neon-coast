/** One game unit is one metre. Terrain and road geometry share this heightfield. */
export const GRID=80;
export const WORLD_LIMIT=16000;
export const WORLD_MIN_X=-276;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const smooth=(a,b,v)=>{const t=clamp((v-a)/(b-a),0,1);return t*t*(3-2*t)};
export const HIGHWAY=Object.freeze({id:'coastal-express',name:'H1 海岸纵贯高速',x:3200,zMin:-14400,zMax:14400,width:34,exitSpacing:1600,approachLength:400,elevation:9,speedLimit:120/3.6,exits:Object.freeze(Array.from({length:19},(_,i)=>(i-9)*1600))});
export const AIRPORTS=Object.freeze([
 {id:'coast-airport',regionId:'coast',name:'霓虹海岸国际机场',code:'NCI',x:6484.5,z:1600,yaw:0,arrival:{x:6484.5,z:1600,yaw:0},terminal:{x:6530,z:1560},runway:{x:6880,z:1600,length:1760,width:46},bounds:{minX:6480,maxX:7280,minZ:640,maxZ:2560},altitude:12},
 {id:'plateau-airport',regionId:'plateau',name:'云岭高原机场',code:'YLP',x:11684.5,z:-9600,yaw:0,arrival:{x:11684.5,z:-9600,yaw:0},terminal:{x:11730,z:-9640},runway:{x:12080,z:-9600,length:1760,width:46},bounds:{minX:11680,maxX:12480,minZ:-10560,maxZ:-8640},altitude:205}
]);
export const REGIONS=Object.freeze([
 {id:'coast',name:'霓虹海岸',description:'海港、城市街区与 H1 纵贯高速',airportId:'coast-airport',arrival:AIRPORTS[0].arrival,center:{x:3200,z:0},bounds:{minX:WORLD_MIN_X,maxX:WORLD_LIMIT,minZ:-WORLD_LIMIT,maxZ:WORLD_LIMIT}},
 {id:'plateau',name:'云岭高原',description:'高原机场、起伏山丘与北境盆地',airportId:'plateau-airport',arrival:AIRPORTS[1].arrival,center:{x:11200,z:-9600},bounds:{minX:9600,maxX:WORLD_LIMIT,minZ:-WORLD_LIMIT,maxZ:-4800}}
]);
export const REGION_PLACES=Object.freeze([
 {id:'highway-south',name:'H1 南湾入口 · 纵贯高速起点',x:3204.5,z:14400,icon:'road'},
 {id:'highway-north',name:'H1 北境出口 · 28.8 km 纵贯',x:3204.5,z:-14400,icon:'road'},
 {id:'highway-mid',name:'H1 中央互通 · 400 m 坡道',x:2804.5,z:0,icon:'road'},
 {id:'plateau',name:'云岭高原观景镇',x:11204.5,z:-10400,icon:'mountain'},
 {id:'basin',name:'北境盆地',x:4804.5,z:-11200,icon:'mountain'},
 ...AIRPORTS.map(a=>({id:a.id,name:a.name+' · '+a.code,x:a.x,z:a.z,icon:'plane',regionId:a.regionId}))
]);
export function regionAt(pos){return pos.x>=9600&&pos.z<=-4800?REGIONS[1]:REGIONS[0]}
export function getRegionTravel(regionId){const region=REGIONS.find(r=>r.id===regionId);if(!region)return null;const airport=AIRPORTS.find(a=>a.id===region.airportId);return{region,airport,position:{...airport.arrival,y:groundHeight(airport.x,airport.z)},yaw:airport.yaw}}
export function airportAt(pos,radius=120){return AIRPORTS.find(a=>Math.hypot(pos.x-a.x,pos.z-a.z)<=radius)??null}
export function inWorld(pos){return Number.isFinite(pos?.x)&&Number.isFinite(pos?.z)&&pos.x>=WORLD_MIN_X&&pos.x<=WORLD_LIMIT-8&&Math.abs(pos.z)<=WORLD_LIMIT-8}
export function clampWorldPosition(pos,fallback={x:4.5,z:80}){return{x:clamp(Number.isFinite(pos?.x)?pos.x:fallback.x,WORLD_MIN_X+3,WORLD_LIMIT-8),z:clamp(Number.isFinite(pos?.z)?pos.z:fallback.z,-WORLD_LIMIT+8,WORLD_LIMIT-8)}}
export function highwayExit(z,margin=14){return HIGHWAY.exits.some(e=>Math.abs(z-e)<=margin)}
export function highwayAt(pos,margin=0){return Math.abs(pos.x-HIGHWAY.x)<=HIGHWAY.width/2+margin&&pos.z>=HIGHWAY.zMin&&pos.z<=HIGHWAY.zMax}
export function airportAirside(pos,margin=0){return AIRPORTS.find(a=>pos.x>a.bounds.minX+14-margin&&pos.x<a.bounds.maxX-14+margin&&pos.z>a.bounds.minZ+14-margin&&pos.z<a.bounds.maxZ-14+margin)??null}
/** Offramps are connected, graded approach roads, not floating scenery. */
export function roadInfo(pos){const dx=Math.abs(pos.x-HIGHWAY.x),within=pos.z>=HIGHWAY.zMin&&pos.z<=HIGHWAY.zMax;const highway=within&&dx<=17,ramp=within&&dx<=HIGHWAY.approachLength&&highwayExit(pos.z,11);return{kind:highway?'highway':ramp?'ramp':'street',speedLimit:highway?HIGHWAY.speedLimit:ramp?14:80/3.6,width:highway?HIGHWAY.width:22,regionId:regionAt(pos).id,elevation:groundHeight(pos.x,pos.z),exit:within&&highwayExit(pos.z,14)}}
export function roadEdgeAllowed(a,b){const m={x:(a.x+b.x)/2,z:(a.z+b.z)/2};if(airportAirside(m))return false;if(a.x!==b.x&&m.x>3120&&m.x<3280&&m.z>HIGHWAY.zMin&&m.z<HIGHWAY.zMax&&!highwayExit(m.z,1))return false;return true}
function terrainRaw(x,z){const inland=smooth(325,2100,x),north=smooth(2600,10000,-z);const plateau=210*smooth(7000,10200,x)*smooth(3800,7500,-z);const hills=32*Math.sin(x/1900)*Math.sin(z/2300)+24*Math.sin((x+z)/2600);const basin=65*Math.exp(-(((x-4700)/2400)**2)-((z+11000)/2900)**2);return inland*(26+north*38+hills-basin)+plateau}
export function terrainHeight(x,z){let y=terrainRaw(x,z);for(const a of AIRPORTS){const b=a.bounds,dx=Math.max(b.minX-x,0,x-b.maxX),dz=Math.max(b.minZ-z,0,z-b.maxZ),blend=1-smooth(0,700,Math.hypot(dx,dz));y+=(a.altitude-y)*blend}return y}
export function groundHeight(x,z){if(!Number.isFinite(x)||!Number.isFinite(z))return 0;const base=terrainHeight(x,z),bank=(1-smooth(22,HIGHWAY.approachLength,Math.abs(x-HIGHWAY.x)))*smooth(HIGHWAY.zMin-400,HIGHWAY.zMin,z)*(1-smooth(HIGHWAY.zMax,HIGHWAY.zMax+400,z));return base+HIGHWAY.elevation*bank}
export function groundNormal(x,z){const dx=(groundHeight(x+1,z)-groundHeight(x-1,z))/2,dz=(groundHeight(x,z+1)-groundHeight(x,z-1))/2,n=Math.hypot(dx,1,dz);return{x:-dx/n,y:1/n,z:-dz/n}}
export function highwayLength(){let distance=0,previous={x:HIGHWAY.x,z:HIGHWAY.zMin,y:groundHeight(HIGHWAY.x,HIGHWAY.zMin)};for(let z=HIGHWAY.zMin+10;z<=HIGHWAY.zMax;z+=10){const p={x:HIGHWAY.x,z,y:groundHeight(HIGHWAY.x,z)};distance+=Math.hypot(p.x-previous.x,p.z-previous.z,p.y-previous.y);previous=p}return distance}
