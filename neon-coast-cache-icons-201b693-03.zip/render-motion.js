// Physics runs at 60 Hz. Rendering may run at 30, 60, 120 Hz or an uneven cadence.
// Interpolate only the displayed pose; collision/Pilot/save state stays authoritative.
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const wrap=n=>Math.atan2(Math.sin(n),Math.cos(n));
export const PHYSICS_STEP=1/60;
export function captureVehiclePose(v){
 v.previousRenderPose??={position:v.pos.clone(),yaw:v.yaw,roll:v.bodyRoll??0};
 const p=v.previousRenderPose;p.position.copy(v.pos);p.yaw=v.yaw;p.roll=v.bodyRoll??0;
}
export function resetVehiclePose(v){delete v.previousRenderPose;}
export function sampleVehiclePose(v,alpha=1){
 const p=v.previousRenderPose,t=clamp(alpha,0,1);
 // Teleports, respawns and replaced cars must never fly through intervening scenery.
 if(!p||p.position.distanceToSquared(v.pos)>400)return{position:v.pos.clone(),yaw:v.yaw,roll:v.bodyRoll??0};
 return{position:p.position.clone().lerp(v.pos,t),yaw:p.yaw+wrap(v.yaw-p.yaw)*t,roll:p.roll+((v.bodyRoll??0)-p.roll)*t};
}
export function applyVehiclePose(v,pose){
 const position=v.root.position.clone(),rotation=v.root.rotation.clone(),roll=v.chassis.rotation.z;
 v.root.position.copy(pose.position);v.root.rotation.set(0,pose.yaw,0);v.chassis.rotation.z=pose.roll;
 return()=>{v.root.position.copy(position);v.root.rotation.copy(rotation);v.chassis.rotation.z=roll;};
}
