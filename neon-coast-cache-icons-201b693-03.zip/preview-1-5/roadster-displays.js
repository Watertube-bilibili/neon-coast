import * as THREE from './vendor/three.module.js';
import {roadsterTrim} from './roadster-controls.js';

const finite=(value,fallback=0)=>Number.isFinite(value)?value:fallback;
const clamp=(value,a,b)=>Math.max(a,Math.min(b,finite(value,a)));
const round=value=>Math.round(finite(value)*10)/10;
const MODES={road:'GROUND',air:'AIRBORNE',landing:'LANDING',recover:'RECOVERY',unpowered:'POWER LOSS'};
const LABELS={auto:'AUTO',raised:'RAISED',stowed:'STOWED'};
export const ROADSTER_DISPLAY_SPECS=Object.freeze([
 Object.freeze({type:'driver',name:'Driver_Display_Surface',width:512,height:192}),
 Object.freeze({type:'center',name:'Center_Display_Surface',width:512,height:352}),
 Object.freeze({type:'aux',name:'Aux_Display_Surface',width:512,height:192})
]);

/** Display data only. No physics, geometry, shared materials or root pose changes. */
export function roadsterDisplayState(car,{autopilot=false}={}){
 const state=car?.roadsterState??{},trim=roadsterTrim(car)??'performance',mode=MODES[state.mode]?state.mode:'road';
 const q=car?.physicsQuaternion??car?.root?.quaternion??{x:0,y:0,z:0,w:1},length=Math.hypot(finite(q.x),finite(q.y),finite(q.z),finite(q.w,1));
 const [x,y,z,w]=length>1e-8?[finite(q.x)/length,finite(q.y)/length,finite(q.z)/length,finite(q.w,1)/length]:[0,0,0,1];
 const forwardX=-2*(x*z+w*y),forwardY=2*(w*x-y*z),forwardZ=-(1-2*(x*x+y*y)),rightY=2*(x*y+w*z),upY=1-2*(x*x+z*z);
 const speed=finite(car?.speed),battery=Math.round(clamp(car?.battery??100,0,100)),condition=Math.round(clamp(car?.condition??100,0,100));
 const air=['air','landing','recover','unpowered'].includes(mode);
 return{trim,mode,air,speed:Math.round(Math.min(999,Math.abs(speed)*3.6)),gear:air?'AIR':Math.abs(speed)<.15?'P':speed<0?'R':'D',battery,range:Math.round(Math.max(0,finite(car?.model?.range,480))*battery/100),autopilot:!!autopilot,
  condition,wing:Math.round(clamp(state.wing??car?.roadsterWingVisual??0,0,1)*100),wingMode:LABELS[car?.roadsterRequest?.wingMode]?car.roadsterRequest.wingMode:'auto',airBrake:finite(state.wingPitch)>.45,
  altitude:round(clamp(state.altitude??0,0,9999)),verticalSpeed:round(clamp(state.verticalSpeed??0,-999,999)),pitch:round(Math.asin(clamp(forwardY,-1,1))*180/Math.PI),roll:round(Math.atan2(-rightY,upY)*180/Math.PI),heading:Math.round((Math.atan2(forwardX,-forwardZ)*180/Math.PI+360)%360)%360,
  warning:condition<=0||battery<=0?'POWER OFF':mode==='unpowered'?'LIFT UNAVAILABLE':mode==='landing'?'CONTROLLED DESCENT':''};
}

const colors={background:'#090e13',line:'#26313c',muted:'#99a8b4',text:'#edf2f5',accent:'#adc1d0',green:'#b4d1c6',amber:'#d1b07c',red:'#c64b49',blue:'#465963',earth:'#3c3432'};
function text(ctx,value,x,y,size=20,color=colors.text,align='left',weight=500){ctx.fillStyle=color;ctx.font=`${weight} ${size}px Arial, sans-serif`;ctx.textAlign=align;ctx.textBaseline='middle';ctx.fillText(String(value),x,y);}
function line(ctx,x,y,width,color=colors.line,height=1){ctx.fillStyle=color;ctx.fillRect(x,y,width,height);}
function bar(ctx,x,y,width,value,color=colors.accent){line(ctx,x,y,width,colors.line,5);line(ctx,x,y,width*clamp(value,0,100)/100,color,5);}
function background(ctx,width,height){ctx.clearRect(0,0,width,height);ctx.fillStyle=colors.background;ctx.fillRect(0,0,width,height);}
const signed=value=>(value>0?'+':'')+value.toFixed(1);

function drawCarDiagram(ctx,s,x,y){
 ctx.save();ctx.translate(x,y);ctx.strokeStyle=s.condition<25?colors.red:'#71818f';ctx.lineWidth=1.6;ctx.fillStyle='#202a33';
 ctx.beginPath();for(const [i,[px,py]]of [[-25,-72],[-39,-51],[-42,48],[-32,70],[32,70],[42,48],[39,-51],[25,-72]].entries())i?ctx.lineTo(px,py):ctx.moveTo(px,py);ctx.closePath();ctx.fill();ctx.stroke();
 ctx.fillStyle='#0d1218';for(const side of [-1,1])for(const axle of[-1,1])ctx.fillRect(side<0?-48:40,axle*43-13,8,26);
 ctx.fillStyle='#44515d';ctx.beginPath();ctx.moveTo(-27,-35);ctx.lineTo(27,-35);ctx.lineTo(32,-8);ctx.lineTo(-32,-8);ctx.closePath();ctx.fill();
 ctx.fillStyle='#18212a';ctx.fillRect(-30,-5,60,45);line(ctx,-28,43,56,'#44515d',12);
 line(ctx,-25,-62,17,colors.text,2);line(ctx,8,-62,17,colors.text,2);line(ctx,-31,62,62,colors.red,2);
 line(ctx,-42-s.wing*.07,74,84+s.wing*.14,s.wing>10?colors.accent:colors.line,3);
 if(s.trim!=='performance'){ctx.fillStyle=colors.red;for(const side of[-1,1]){ctx.beginPath();ctx.moveTo(side*19-4,82);ctx.lineTo(side*19+4,82);ctx.lineTo(side*19,89);ctx.closePath();ctx.fill();}}
 if(s.trim==='rocket'){ctx.strokeStyle=colors.accent;ctx.lineWidth=1;for(const side of[-1,1])for(const z of[-45,42]){ctx.beginPath();ctx.arc(side*53,z,3,0,Math.PI*2);ctx.stroke();}}
 ctx.restore();
}

export function paintRoadsterDisplay(ctx,type,s){
 if(type==='driver'){
  background(ctx,512,192);
  text(ctx,'ROADSTER',20,19,17,colors.muted);text(ctx,s.trim.toUpperCase(),492,19,15,colors.muted,'right');line(ctx,20,34,472);
  text(ctx,s.speed,20,91,84,colors.text,'left',600);text(ctx,'km/h',24,142,19,colors.muted);
  text(ctx,s.gear,308,89,s.air?37:64,s.gear==='R'?colors.amber:colors.accent,'center',600);text(ctx,s.air?'FLIGHT':'GEAR',308,139,15,colors.muted,'center');
  text(ctx,s.battery+'%',492,92,37,s.battery<15?colors.amber:colors.green,'right',600);text(ctx,'BATTERY',492,139,15,colors.muted,'right');
  bar(ctx,20,159,472,s.battery,s.battery<15?colors.amber:colors.green);
  text(ctx,s.autopilot?'PILOT ACTIVE':s.air?MODES[s.mode]:'MANUAL',20,179,14,s.autopilot?colors.accent:colors.muted);text(ctx,s.range+' km',492,179,16,colors.muted,'right');
 }else if(type==='center'){
  background(ctx,512,352);text(ctx,'ROADSTER / '+s.trim.toUpperCase(),22,24,20,colors.accent);line(ctx,22,44,468);
  text(ctx,MODES[s.mode],22,76,30,s.mode==='unpowered'?colors.red:colors.text,'left',600);text(ctx,'GAME SYSTEMS',490,76,13,colors.muted,'right');
  text(ctx,'VEHICLE',22,111,14,colors.muted);drawCarDiagram(ctx,s,96,196);
  const performance=s.trim==='performance';
  const powered=s.condition>0&&s.battery>0;
  text(ctx,performance?'GROUND SUCTION':'PROPULSION',204,119,14,colors.muted);text(ctx,powered?'READY':'OFF',490,119,25,powered?colors.text:colors.amber,'right',600);bar(ctx,204,142,286,powered?100:0);
  text(ctx,'BATTERY',204,173,14,colors.muted);text(ctx,s.battery+'%',490,173,25,s.battery<15?colors.amber:colors.text,'right',600);bar(ctx,204,196,286,s.battery,s.battery<15?colors.amber:colors.muted);
  text(ctx,'WING',204,227,14,colors.muted);text(ctx,s.wing+'%',490,227,25,colors.accent,'right',600);text(ctx,s.airBrake?'AIR BRAKE':s.air?'FLIGHT DEPLOYMENT':LABELS[s.wingMode],204,252,17,colors.muted);
  text(ctx,'AERO '+s.wing+'%',96,297,13,colors.muted,'center');text(ctx,'BODY',204,284,14,colors.muted);text(ctx,s.condition+'%',490,284,21,s.condition<25?colors.red:colors.muted,'right');
  line(ctx,22,312,468);text(ctx,s.warning||'SYSTEM READY',22,332,17,s.warning?colors.amber:colors.green);text(ctx,'SIM',490,332,13,colors.muted,'right');
 }else if(type==='aux'){
  background(ctx,512,192);text(ctx,s.air?'FLIGHT ATTITUDE':'BODY ATTITUDE',20,18,16,colors.muted);line(ctx,20,33,472);
  text(ctx,'ALTITUDE',20,53,14,colors.muted);text(ctx,s.altitude.toFixed(1),20,91,48,colors.text,'left',600);text(ctx,'m AGL',20,128,16,colors.muted);text(ctx,'V/S '+signed(s.verticalSpeed),221,128,18,colors.accent,'right');
  // A small true attitude horizon, clipped to its own screen region.
  ctx.save();ctx.beginPath();ctx.rect(254,43,238,103);ctx.clip();ctx.translate(373,95);ctx.rotate(-s.roll*Math.PI/180);const offset=clamp(s.pitch,-85,85)*.9;
  ctx.fillStyle=colors.blue;ctx.fillRect(-400,-400+offset,800,400);ctx.fillStyle=colors.earth;ctx.fillRect(-400,offset,800,400);line(ctx,-400,offset,800,colors.accent,2);
  ctx.strokeStyle='#b8daed99';ctx.lineWidth=1.5;for(const angle of[-30,-15,15,30]){const y=offset+angle*.9;ctx.beginPath();ctx.moveTo(-28,y);ctx.lineTo(28,y);ctx.stroke();}ctx.restore();
  ctx.strokeStyle=colors.amber;ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(335,95);ctx.lineTo(361,95);ctx.lineTo(373,102);ctx.lineTo(385,95);ctx.lineTo(411,95);ctx.stroke();
  line(ctx,20,157,472);text(ctx,'HDG '+String(s.heading).padStart(3,'0')+'°',20,177,17,colors.muted);text(ctx,'P '+signed(s.pitch)+'°   R '+signed(s.roll)+'°',492,177,17,colors.accent,'right');
 }
}

function signature(type,s){return JSON.stringify(type==='driver'?[s.trim,s.speed,s.gear,s.battery,s.range,s.autopilot,s.mode]:type==='center'?[s.trim,s.mode,s.battery,s.wing,s.wingMode,s.condition,s.airBrake,s.warning]:[s.air,s.altitude,s.verticalSpeed,s.pitch,s.roll,s.heading]);}

export function attachRoadsterDisplays(car){
 if(!roadsterTrim(car)||!car?.root)return null;
 if(car.instruments)return car.instruments.kind==='roadster'?car.instruments:null;
 const surfaces=ROADSTER_DISPLAY_SPECS.map(spec=>car.root.getObjectByName(spec.name));
 if(surfaces.some(surface=>!surface?.isMesh))return null;
 const displays=[];
 try{
  for(let i=0;i<ROADSTER_DISPLAY_SPECS.length;i++){
   const spec=ROADSTER_DISPLAY_SPECS[i],surface=surfaces[i],originalMaterial=surface.material,panel={...spec,surface,originalMaterial,material:null,texture:null,signature:''};displays.push(panel);
   const canvas=document.createElement('canvas');canvas.width=spec.width;canvas.height=spec.height;
   const context=canvas.getContext('2d');if(!context)throw Error('Roadster 2D display context unavailable');
   const texture=panel.texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;texture.flipY=false;texture.minFilter=texture.magFilter=THREE.LinearFilter;texture.generateMipmaps=false;
   const base=Array.isArray(originalMaterial)?originalMaterial[0]:originalMaterial,material=panel.material=base.clone();material.name='Roadster_Live_'+spec.type;material.map=texture;material.toneMapped=false;material.side=THREE.DoubleSide;material.transparent=false;material.opacity=1;material.depthWrite=true;material.alphaTest=0;
   if(material.emissive){material.color.setHex(0x000000);material.emissive.setHex(0xffffff);material.emissiveMap=texture;material.emissiveIntensity=1;material.metalness=0;material.roughness=1;if('transmission'in material)material.transmission=0;if('clearcoat'in material)material.clearcoat=0;}else material.color.setHex(0xffffff);
   surface.material=material;surface.userData.semantic=3;
   Object.assign(panel,{canvas,context});
  }
 }catch(error){for(const panel of displays){panel.surface.material=panel.originalMaterial;panel.texture?.dispose();panel.material?.dispose();}return null;}
 car.instruments={kind:'roadster',displays,lastUpdate:-Infinity,state:null};updateRoadsterDisplays(car,0);return car.instruments;
}

export function updateRoadsterDisplays(car,time=0,options={}){
 const instruments=car?.instruments;if(instruments?.kind!=='roadster')return;
 const now=finite(time);if(now>=instruments.lastUpdate&&now-instruments.lastUpdate<.1)return;
 const state=roadsterDisplayState(car,options);instruments.state=state;instruments.lastUpdate=now;
 for(const panel of instruments.displays){const next=signature(panel.type,state);if(panel.signature===next)continue;paintRoadsterDisplay(panel.context,panel.type,state);panel.signature=next;panel.texture.needsUpdate=true;}
}

export function disposeRoadsterDisplays(car){
 const instruments=car?.instruments;if(instruments?.kind!=='roadster')return false;
 for(const panel of instruments.displays){if(panel.surface.material===panel.material)panel.surface.material=panel.originalMaterial;panel.texture.dispose();panel.material.dispose();}
 delete car.instruments;return true;
}
