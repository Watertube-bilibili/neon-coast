import {createPreviewSlot,listPreviewSlots,resumePreviewSlot} from './preview-1-5/preview-slots.js';

export const PREVIEW_ENTRY_VERSION='1.5.1-preview';
export const PREVIEW_ENTRY_READ_KEY='neon-coast-preview-entry-read';
const escape=value=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function entryDismissed(storage){try{return storage.getItem(PREVIEW_ENTRY_READ_KEY)===PREVIEW_ENTRY_VERSION;}catch{return false;}}
export function dismissEntry(storage){try{storage.setItem(PREVIEW_ENTRY_READ_KEY,PREVIEW_ENTRY_VERSION);return true;}catch{return false;}}

/** Entry UI only. The formal game's models, physics and save keys are untouched. */
export function installPreviewEntry(game,{storage,navigate=url=>globalThis.location.assign(url),schedule=globalThis.setTimeout,document=globalThis.document}={}){
 if(game.previewEntry)return game.previewEntry;
 if(storage===undefined)try{storage=globalThis.localStorage;}catch{}
 const $=id=>document.getElementById(id),ui=game.ui;
 const originalOpen=ui.openModal.bind(ui),originalClose=ui.closeModal.bind(ui),originalSettings=ui.openSettings.bind(ui);
 let active=false,busy=false,leaving=false,proceedButton=null;
 function clearProceed(){proceedButton?.remove();proceedButton=null;}
 function leaveClass(){document.body.classList.remove('preview-entry-open');}
 function noteDismissal(){if(!dismissEntry(storage))ui.toast('浏览器未能记住试玩提示，下次打开可能仍会显示。','error');}
 ui.openModal=(...args)=>{if(active){active=false;clearProceed();leaveClass();}return originalOpen(...args);};
 ui.closeModal=(...args)=>{if(active&&!leaving)noteDismissal();active=false;busy=false;clearProceed();leaveClass();return originalClose(...args);};
 function status(message){$('preview-entry-status').textContent=message;}
 function disable(on){for(const b of $('modal-body').querySelectorAll('[data-preview-action]'))b.disabled=on&&b.dataset.previewAction!=='later';}
 function enter(entry){
  if(leaving)return;
  // All slot data must commit successfully before navigation. If the browser
  // refuses navigation, the committed slot remains visible in recovery below.
  if(!dismissEntry(storage))ui.toast('试玩存档已准备好，但浏览器未能记住提示状态。','error');
  leaving=true;if(proceedButton)proceedButton.disabled=true;status('存档已准备好，正在打开试玩…');
  try{navigate(entry.url);}catch(error){leaving=false;busy=false;clearProceed();disable(false);status('试玩存档已保留，但页面未能跳转。请从“继续之前的试玩”重新打开。');renderRecovery();}
 }
 function run(action){
  if(busy)return;clearProceed();busy=true;disable(true);status('正在检查并准备独立试玩存档…');
  try{
   const entry=action();
   if(entry.warnings?.length){
    status('独立试玩存档已准备好。'+entry.warnings.join('；'));
    const proceed=document.createElement('button');proceedButton=proceed;proceed.id='preview-entry-proceed';proceed.type='button';proceed.className='preview-entry-reopen';proceed.textContent='知道了，进入试玩';proceed.onclick=()=>enter(entry);$('preview-entry-status').after(proceed);proceed.focus();renderRecovery();
   }else enter(entry);
  }catch(error){busy=false;disable(false);status(error?.message||'无法准备试玩存档。正式版和已有试玩进度没有被覆盖。');}
 }
 function renderRecovery(){
  const list=$('preview-entry-slots');list.innerHTML='';
  try{
   const entries=listPreviewSlots(storage);$('preview-entry-history').hidden=entries.length===0&&!entries.warnings?.length;$('preview-entry-history-warning').textContent=(entries.warnings??[]).join('；');
   $('preview-entry-history-label').textContent=`继续之前的试玩（${entries.length}）`;
   list.innerHTML=entries.map((entry,i)=>`<button type="button" data-preview-action="resume" data-preview-resume="${i}"><strong>${escape(entry.label)}</strong><small>${entry.default?'原试玩入口 · 保留原有进度':escape(new Date(entry.createdAt).toLocaleString('zh-CN'))}</small></button>`).join('');
   for(const button of list.querySelectorAll('[data-preview-resume]')){button.disabled=busy;button.onclick=()=>run(()=>resumePreviewSlot(storage,entries[Number(button.dataset.previewResume)].slot));}
  }catch(error){$('preview-entry-history').hidden=false;$('preview-entry-history-label').textContent='之前的试玩';list.textContent=error?.message||'暂时无法读取试玩存档列表。';}
 }
 function open(){
  if(leaving)return;clearProceed();
  globalThis.window?.neonMobileUI?.closeDrawer?.();game.resetControls();
  originalOpen('1.5.1 测试版已发布','当前正式版 1.3.5 · 独立试玩');active=true;busy=false;$('modal').setAttribute('aria-labelledby','modal-title');document.body.classList.add('preview-entry-open');
  $('modal-body').innerHTML=`<div class="preview-entry-content"><p class="preview-entry-intro">新版本加入 Godot 物理、飞机与山路。你想怎么进入试玩？</p><p class="preview-entry-note">正式版进度会保留。每次复制或新开都会建立独立试玩存档位，不覆盖之前的试玩。</p><div class="preview-entry-actions"><button type="button" id="preview-entry-copy" data-preview-action="copy"><strong>复制当前存档试玩</strong><small>带入本浏览器已保存的正式版进度与有效设置</small></button><button type="button" id="preview-entry-fresh" data-preview-action="fresh"><strong>新存档试玩</strong><small>从头开始，已有试玩仍可随时继续</small></button><button type="button" id="preview-entry-later" data-preview-action="later">暂不试玩 · 留在正式版</button></div><p id="preview-entry-status" role="status" aria-live="polite"></p><details id="preview-entry-history"><summary id="preview-entry-history-label">继续之前的试玩</summary><p id="preview-entry-history-warning" class="preview-entry-note"></p><div id="preview-entry-slots"></div></details><p class="preview-entry-footnote">这是测试版，可能仍有问题。以后可从“暂停与设置 → 1.5.1 测试版入口”重新打开；关闭本提示后，刷新不再重复弹出。</p></div>`;
  $('preview-entry-copy').onclick=()=>run(()=>createPreviewSlot(storage,{mode:'copy',validateSave:game.validateSave.bind(game)}));
  $('preview-entry-fresh').onclick=()=>run(()=>createPreviewSlot(storage,{mode:'fresh'}));
  $('preview-entry-later').onclick=()=>ui.closeModal();
  renderRecovery();$('preview-entry-copy').focus();
 }
 ui.openSettings=(...args)=>{originalSettings(...args);const button=document.createElement('button');button.type='button';button.id='settings-preview-entry';button.className='preview-entry-reopen';button.textContent='1.5.1 测试版入口';button.onclick=open;$('modal-body').prepend(button);};
 globalThis.window?.addEventListener?.('pageshow',event=>{
  if(!event.persisted)return;leaving=false;busy=false;clearProceed();game.resetControls();
  if(active){disable(false);status('已回到正式版。之前建立的试玩存档仍保留，可以在下方继续。');renderRecovery();}
 });
 game.previewEntry={open,get active(){return active;}};
 if(!entryDismissed(storage)){
  const wait=()=>{if(entryDismissed(storage)||active)return;if($('modal').open||ui.isPhoneOpen()||game.flight?.active||game.transition){schedule(wait,500);return;}open();};
  schedule(wait,1500);
 }
 return game.previewEntry;
}

// Kept separate from the game import: a failed WebGL startup must not alter any
// storage. The entry becomes available as soon as the existing formal game is ready.
if(typeof window!=='undefined'&&typeof document!=='undefined'){
 const start=()=>{if(window.game?.ui){installPreviewEntry(window.game);return;}setTimeout(start,500);};
 start();
}
