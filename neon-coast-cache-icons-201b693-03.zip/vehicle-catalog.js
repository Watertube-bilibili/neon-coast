// Original fictional vehicle designs. IDs are stable for existing saves.
export const VEHICLE_BRANDS = [
  {id:'volt',name:'VOLT',tagline:'纯电，从容向前',color:'#a6cfca'},
  {id:'mira',name:'MIRA',tagline:'把城市变小',color:'#c6d69f'},
  {id:'terran',name:'TERRAN',tagline:'道路之外，也有方向',color:'#c5b894'},
  {id:'aurelia',name:'AURELIA',tagline:'优雅，自有分寸',color:'#d0a786'},
  {id:'nord',name:'NORD',tagline:'为生活留出空间',color:'#a4bdcf'},
  {id:'ravel',name:'RAVEL',tagline:'空气，成为线条',color:'#e4a58b'},
  {id:'solace',name:'SOLACE',tagline:'每段旅途都有温度',color:'#c5b4d1'},
  {id:'chenjing',name:'CHENJING 宸境',tagline:'从容，另有境界',color:'#d8c8ac'}
];

export const MODELS = [
  {id:'s',brand:'volt',name:'VOLT S',trim:'LONG RANGE',category:'轿车',desc:'纯电快背轿车 · 水滴座舱与矩阵灯组',price:0,power:11,max:47,range:420,color:0x9eabb9},
  {id:'x',brand:'volt',name:'VOLT X',trim:'DUAL MOTOR',category:'SUV',desc:'全能纯电 SUV · 全景车顶与双电机四驱',price:38000,power:13,max:44,range:390,color:0x315857},
  {id:'r',brand:'volt',name:'VOLT R',trim:'PERFORMANCE',category:'跑车',desc:'纯电双门跑车 · 低矮宽体与双弧日行灯',price:72000,power:19,max:65,range:340,color:0xb9392a},
  {id:'cybr',brand:'volt',name:'VOLT CYBR',trim:'ALL TERRAIN',category:'皮卡',desc:'电动探险皮卡 · 缎面银车身与实用货厢',price:58000,power:12,max:40,range:450,color:0xa0a8ad},
  {id:'m',brand:'mira',name:'MIRA M',trim:'CITY EDITION',category:'掀背',desc:'都市五门掀背 · 悬浮车顶与圆角光环灯',price:24000,power:10.5,max:39,range:325,color:0xb5b99b},
  {id:'nomad',brand:'terran',name:'TERRAN NOMAD',trim:'TRAIL AWD',category:'越野',desc:'全地形越野车 · 轮拱护板、行李架与备胎',price:64000,power:14,max:43,range:465,color:0x6b7261},
  {id:'gt',brand:'aurelia',name:'AURELIA GT',trim:'GRAND TOURING',category:'GT',desc:'长头双门 GT · 流线车肩与铜色精工细节',price:98000,power:20,max:64,range:480,color:0x653849},
  {id:'vela',brand:'aurelia',name:'AURELIA VELA',trim:'EXECUTIVE',category:'轿车',desc:'旗舰豪华轿车 · 修长车身与珠光金属漆',price:86000,power:16,max:54,range:520,color:0xb6afa0},
  {id:'estate',brand:'nord',name:'NORD E6',trim:'TOURING AWD',category:'旅行车',desc:'北欧纯电旅行车 · 大空间与立体尾灯',price:56000,power:14,max:48,range:490,color:0x496775},
  {id:'apex',brand:'ravel',name:'RAVEL APEX',trim:'STRADA',category:'超跑',desc:'中置超跑 · 空气通道与锻造分叉轮辐',price:168000,power:24,max:73,range:360,color:0xd37636},
  {id:'aria',brand:'solace',name:'SOLACE ARIA',trim:'GRAND LOUNGE',category:'MPV',desc:'豪华电动 MPV · 宽敞座舱与水晶灯组',price:69000,power:12.5,max:42,range:470,color:0x4e455e},
  {id:'coupe',brand:'solace',name:'SOLACE C2',trim:'HERITAGE',category:'双门',desc:'复古电动双门 · 圆形灯组与溜背车顶',price:48000,power:14,max:52,range:375,color:0xc6c8b5},
  {id:'c800',brand:'chenjing',name:'CHENJING 宸境 C800',trim:'SOVEREIGN · 2+2+2',category:'MPV',desc:'原创旗舰高顶 MPV · 香槟双色车身、三排六座与独立礼宾座椅',price:128000,power:15,max:46,range:560,color:0x23323d}
];
