import {createPreviewSlot,listPreviewSlots} from './preview-1-5/preview-slots.js';
import {FORMAL_STORAGE_KEYS,storageKeysForSlot} from './preview-1-5/storage-keys.js';
import {validateSave,validateStoredSave} from './preview-1-5/save-validation.js';
export const ACTIVE_KEY='neon-coast-candidate-1.5.0:active-save-key';
export const BACKUP_KEY='neon-coast-upgrade-1.5:legacy-backup-v1';
const TOKEN='automatic-full-release-v1';
const fail=message=>{throw Error(message);};
function remember(storage,entry){const key=storageKeysForSlot(entry.slot).SAVE_KEY,value=JSON.stringify({key,emptyAllowed:entry.mode==='fresh'&&storage.getItem(key)===null});storage.setItem(ACTIVE_KEY,value);if(storage.getItem(ACTIVE_KEY)!==value)fail('无法记录当前存档，请检查存储空间后重试');return entry;}
export function resolveLatest(storage,{allowMigration=true,createSlot=createPreviewSlot}={}){
 const entries=listPreviewSlots(storage);if(entries.warnings.length)fail('发现损坏的存档入口，已保留全部数据。请先检查存档');
 const known=new Set(entries.map(e=>storageKeysForSlot(e.slot).SAVE_KEY));
 for(let i=0;i<storage.length;i++){const key=storage.key(i);if(key?.startsWith('neon-coast-candidate-1.5.0:slot-')&&key.endsWith(':save-v1')&&!known.has(key))fail('发现未完成的存档副本，已停止自动进入并保留数据');}
 const saves=entries.map(entry=>{const key=storageKeysForSlot(entry.slot).SAVE_KEY,raw=storage.getItem(key);let save=null;if(raw===null&&entry.mode==='copy')fail('已复制的存档内容缺失，已停止启动并保留备份');if(raw!==null){try{save=validateSave(JSON.parse(raw));}catch{fail('已有1.5存档无法校验，已停止启动，原数据未修改');}}return{entry,key,save};});
 const active=storage.getItem(ACTIVE_KEY);
 if(active!==null){let pointer;try{pointer=JSON.parse(active);}catch{pointer={key:active,emptyAllowed:false};}const selected=saves.find(s=>s.key===pointer?.key);if(!selected||(!selected.save&&!(pointer.emptyAllowed===true&&selected.entry.mode==='fresh')))fail('上次使用的存档内容或入口缺失，已保留数据并停止自动进入');return selected.entry;}
 const progressed=saves.filter(s=>s.save);
 if(progressed.length){
  if(progressed.length>1&&progressed.some(s=>!Number.isFinite(Date.parse(s.save.savedAt))))fail('多个已有存档缺少可靠保存时间，请在存档管理中确认一次');
  progressed.sort((a,b)=>(Date.parse(b.save.savedAt)||0)-(Date.parse(a.save.savedAt)||0)||a.key.localeCompare(b.key));return remember(storage,progressed[0].entry);
 }
 const raw=storage.getItem(FORMAL_STORAGE_KEYS.SAVE_KEY);
 if(raw!==null){
  try{validateSave(JSON.parse(raw));}catch{fail('旧存档无法通过新版校验，原数据未修改；请先导出备份后检查');}
  if(!allowMigration)fail('此浏览器缺少安全的跨标签页迁移能力，请使用支持 Web Locks 的浏览器或手动导入存档');
  const snapshot=JSON.stringify({version:1,values:Object.fromEntries(Object.entries(FORMAL_STORAGE_KEYS).map(([name,key])=>[key,storage.getItem(key)]))});
  const previous=storage.getItem(BACKUP_KEY);
  if(previous!==null&&previous!==snapshot)fail('旧存档与已保留备份不同，已停止重复迁移以保护两个版本');
  if(previous===null){storage.setItem(BACKUP_KEY,snapshot);if(storage.getItem(BACKUP_KEY)!==snapshot)fail('旧存档备份写入失败，未进入游戏');}
  return remember(storage,createSlot(storage,{mode:'copy',validateSave,operationToken:TOKEN}));
 }
 const fresh=saves.find(s=>s.entry.slot!==null);
 if(fresh)return remember(storage,fresh.entry);
 // A truly new browser needs no chooser and no migration transaction.
 return {slot:null,url:new URL('./preview-1-5/',import.meta.url).pathname};
}
export async function installLauncher({document,storage,navigate,locks=globalThis.navigator?.locks,manage=false}){
 const status=document.getElementById('status'),list=document.getElementById('slots');
 try{
  if(manage){for(const entry of listPreviewSlots(storage)){const button=document.createElement('button');button.textContent='继续存档 · '+entry.label;button.onclick=()=>{try{const raw=validateStoredSave(storage,storageKeysForSlot(entry.slot).SAVE_KEY);if(raw===null&&entry.mode!=='fresh')fail('已有存档内容缺失，已停止启动');remember(storage,entry);navigate(entry.url);}catch(e){status.textContent=e.message+'，未进入游戏。';}};list.append(button);}status.textContent='已有存档均保留。选择后将成为默认继续的进度。';return;}
  const run=()=>resolveLatest(storage,{allowMigration:!!locks?.request});
  const entry=locks?.request?await locks.request('neon-coast-automatic-save-upgrade',run):run();
  status.textContent='存档已确认，正在进入最新版…';navigate(entry.url);
 }catch(error){status.textContent=error.message+'。游戏尚未启动，已有存档不会被覆盖。';document.getElementById('recovery').hidden=false;}
}
if(typeof document!=='undefined'){
 try{installLauncher({document,storage:localStorage,navigate:url=>location.replace(url),manage:new URLSearchParams(location.search).get('manage')==='1'});}catch(error){document.getElementById('status').textContent='无法访问本地存储：'+error.message;document.getElementById('recovery').hidden=false;}
}
